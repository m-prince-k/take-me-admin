require("dotenv/config");
const jwt = require("jsonwebtoken");
const Helper = require("../utils/helper.js");
const { User } = require("../../models");

//check only api key
const AuthApiKey = async (req, res, next) => {
    try {
        if (!req.headers["x-api-key"]) {
            const response = {
                status: 200,
                code: 'api_key_12806',
                message: 'Unauthorized x-api-key',
                data: [],
            };
            return await Helper.ErrorResponse(res, 'api_key_12806', 'Unauthorized x-api-key');
        }
        if (!req.headers.hasOwnProperty('x-api-key') || (req.headers.hasOwnProperty('x-api-key') && req.headers['x-api-key'] != Object.freeze(process.env.X_API_KEY))) {
            const body = 'Unauthorized';
            const response = {
                status: 200,
                code: 'api_key_12807',
                message: 'Unauthorized ,Try again',
                data: [],
            };
            return await Helper.ErrorResponse(res, 'api_key_12807', 'Unauthorized ,Try again');
        }
        next();
    } catch (error) {
        console.log("______________________________________error is here", error);
        return res.send({ message: error });
    }
}
//check for login authentication module
const AuthCheck = async (req, res, next) => {
    try {
        // Check if apikey is a part of the headers
        console.log(process.env.JWT_SECRET);
        const token = req.headers["authorization"] ? req.headers["authorization"].split(" ")[1] : '';

        if (!req.headers["x-api-key"]) {
            const response = {
                status: 200,
                code: 'api_key_12806',
                message: 'Unauthorized x-api-key',
            };
            return res.send(response);
        }
        if (!req.headers.hasOwnProperty('x-api-key') || (req.headers.hasOwnProperty('x-api-key') && req.headers['x-api-key'] != Object.freeze(process.env.X_API_KEY))) {
            const body = 'Unauthorized';
            const response = {
                status: 200,
                code: 'unauth_api_key_12085',
                message: 'Unauthorized ,Try again',
                body: [],
            };
            return res.status(200).send(response);
        } else if (!token) {
            const response = {
                status: 200,
                code: 'unauthenticated_12084',
                message: 'Unauthenticated, Try again',
                body: [],
            };
            return res.status(200).send(response);
        } else {
            let decode = await jwt.verify(token, process.env.JWT_SECRET, (err, res) => {
                if (err) {
                    return "token expired"
                }
                return res
            });
            if (decode == "token expired") {
                return await Helper.ErrorResponse(res, 'token_expired_1283', 'Unauthorized , Try again')
            }
            if (decode) {
                let userDetail = await Helper.checkUserExistOrNot(decode?.id);
                if (!userDetail) { return await Helper.ErrorResponse(res, "user_not_found_404", "User not found.") }
                if (+userDetail?.is_block == 1) {
                    return await Helper.ErrorResponse(res, "user_block_302", "user has been blocked by admin")
                    // return await res.json({ status: false, "code": "ERR-UNF001", "message": "User has been blocked by Admin" })
                } else {
                    if (decode && decode.id) {
                        let userDetail = await Helper.checkUserExistOrNot(decode?.id);
                        if (userDetail) {
                            req.AuthUser = userDetail;
                            next();
                        } else {
                            await Helper.ErrorResponseWithStatusCode(res, "user_not_found_404", "User not found", 200);
                        }
                    }
                }
            }

        }
    } catch (error) {
        console.log("______________________________________error is here", error);
    }
}
module.exports = { AuthApiKey, AuthCheck };