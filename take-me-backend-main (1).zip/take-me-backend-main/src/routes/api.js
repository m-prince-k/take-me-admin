const express = require("express");
const routes = express.Router();
const AuthController = require("../controller/AuthController.js");
const UserController = require("../controller/UserController.js");
const PostController = require("../controller/PostController.js");
const { AuthCheck, AuthApiKey } = require("../middleware/AuthCheck.js");
const SettingController = require("../controller/SettingController.js");
const ProductController = require("../controller/ProductController.js");
const NotificationController = require("../controller/NotificationController.js");
const AdminController = require("../controller/AdminController.js");

routes.post("/search", AuthCheck, AuthController.search);

///USER ROUTES START
routes.post("/user/signUp", AuthApiKey, AuthController.signUp);
routes.post("/user/verifyChangeEmailCode", AuthApiKey, AuthController.verifyChangeEmailCode);
routes.post("/user/sentOtp", AuthApiKey,AuthController.sentOtp);
routes.post("/user/profile", AuthCheck, AuthController.getUserAuthProfile);
routes.post("/user/getProfileByUserId", AuthCheck, AuthController.getProfileByUserId);
routes.post("/user/showUserDetail", AuthCheck, AuthController.showUserDetail);
routes.post("/user/chatNotification", AuthCheck, AuthController.chatNotification);
routes.post("/user/update", AuthCheck, AuthController.updateUserDetail);
routes.post("/user/verifyOtp",AuthApiKey, AuthController.verifyOtp);
routes.post("/user/reportUser", AuthCheck, UserController.reportUser);
routes.post("/user/logout", AuthCheck, AuthController.logout);
routes.post("/user/block", AuthCheck, AuthController.block);
routes.post("/user/unBlock", AuthCheck, AuthController.unBlock);
routes.post("/user/refreshToken", AuthApiKey, AuthController.refreshToken);

routes.post("/user/delete", AuthCheck, UserController.deleteUser);
routes.post("/user/fetchProfileCategories", AuthCheck, UserController.fetchProfileCategories);

routes.post("/user/follow", AuthCheck, UserController.followUser);
routes.post("/user/unFollow", AuthCheck, UserController.unFollowUser);
routes.post("/user/checkFollower", AuthCheck, UserController.checkFollower);
routes.post("/user/followingList", AuthCheck, UserController.fetchFollowingList);
routes.post("/user/followerList", AuthCheck, UserController.fetchFollowerList);
routes.post("/user/checkFollowUser", AuthCheck, UserController.checkFollowUser);
routes.post("/user/addDeviceData", AuthCheck, UserController.addDeviceData);

routes.post("/user/checkBlockedByUser", AuthCheck, UserController.checkBlockedByUser);
routes.post("/user/searchUser", AuthCheck,UserController.searchUser);

routes.post("/user/createCallRecord", AuthCheck,UserController.createCallRecord);
routes.post("/user/liveStreamUser", AuthCheck,UserController.liveStreamUser);
routes.post("/user/generateAgoraToken", AuthCheck,UserController.generateAgoraToken);
routes.post("/user/sendLiveStreamPushNotfication", AuthCheck,UserController.sendLiveStreamPushNotfication);
routes.post("/user/fetchUserCallRecord", AuthCheck,UserController.fetchUserCallRecord);
routes.post("/user/updateUserCallStatus", AuthCheck,UserController.updateUserCallStatus);
routes.post("/user/verifyReferralCode", AuthCheck,UserController.verifyReferralCode);
routes.post("/user/addCoinPlan", AuthCheck,UserController.addCoinPlan);
routes.post("/user/fetchCoinPlan", AuthCheck,UserController.fetchCoinPlan);
routes.post("/user/fetchAllUser", AuthCheck,UserController.fetchAllUser);
routes.post("/user/profileCategoryByUser", AuthCheck,UserController.profileCategoryByUser);



// ----------------------------------------------------------Start on user module ------------------------------------------------
routes.post("/user/reportUser", AuthCheck, UserController.reportUser);
routes.post("/user/checkUserNameExistOrNot", AuthApiKey, UserController.checkUserNameExistOrNot);
routes.post("/user/fetchBlockUser", AuthCheck, UserController.fetchBlockUser);
routes.post("/user/checkForPhone", AuthApiKey, UserController.checkForPhone);
routes.post("/user/showTopics", AuthCheck, UserController.showTopics);
routes.post("/user/addPrivacySetting", AuthCheck, UserController.addPrivacySetting);
routes.post("/user/updatePhone", AuthCheck, UserController.updatePhone);
routes.post("/user/showGift", AuthCheck, UserController.showGift);
routes.post("/user/sendGift", AuthCheck, UserController.sendGift);
routes.post("/user/chatList", AuthCheck, UserController.chatList);


///USER ROUTES END


// -------------------------------------------------------- Start on product module --------------------------------------------------------
routes.post("/product/fetchProducts", AuthCheck, ProductController.fetchProducts);
routes.post("/product/fetchProductsByUserId", AuthCheck, ProductController.fetchProductsByUserId);
routes.post("/product/fetchProductById", AuthCheck, ProductController.fetchProductById);
routes.post("/product/createProduct", AuthCheck, ProductController.createProduct);
routes.post("/product/updateProduct", AuthCheck, ProductController.updateProduct);
routes.post("/product/deleteProduct", AuthCheck, ProductController.deleteProduct);

// -------------------------------------------------------- Start on Notification module --------------------------------------------------------
routes.post("/notification/save", AuthCheck, NotificationController.saveNotification);

/// POST ROUTE START

// -------------------------------------------------------- Start on Post Module --------------------------------------------------------
routes.post("/post/uploadPost",AuthCheck,PostController.uploadPost);
routes.post("/post/publishPost",AuthCheck,PostController.publishPost);
routes.post("/post/fetchPost",AuthApiKey,PostController.fetchPost);
routes.post("/post/fetchPost1",AuthApiKey,PostController.fetchPost1);
routes.post("/post/fetchUserPost",AuthCheck,PostController.fetchUserPost);
routes.post("/post/postsByUserId", AuthCheck, PostController.postsByUserId);
routes.post("/post/draftPostsByUserId", AuthCheck, PostController.draftPostsByUserId);
routes.post("/post/fetchPostById", AuthCheck, PostController.fetchPostById);
routes.post("/post/likePost",AuthCheck, PostController.likePost);
routes.post("/post/deletePost",AuthCheck, PostController.deletePost);
routes.post("/post/showUserVideosTrendingAndRecent",AuthCheck, PostController.showUserVideosTrendingAndRecent);


routes.post("/post/fetchUserLikePosts",AuthCheck,PostController.fetchUserLikePosts);
// ------------------------------------------post comment api start here-----------------------------------------
routes.post("/post/createDeleteComment",AuthCheck, PostController.createDeleteComment);
routes.post("/post/fetchPostComment",AuthCheck,PostController.fetchPostComment);
routes.post("/post/likeComment",AuthCheck,PostController.likeComment);
routes.post("/post/postCommentReply",AuthCheck,PostController.postCommentReply);
routes.post("/post/PostCommentReplyLike",AuthCheck,PostController.PostCommentReplyLike);
// -----------------------------------------------end of post comment is here---------------------------------------

routes.post("/post/searchPost", AuthCheck,PostController.searchPost);
routes.post("/post/fetchPostByHashTags",AuthCheck,PostController.fetchPostByHashTags);
routes.post("/post/addHashTagFavourite",AuthCheck,PostController.addHashTagFavourite);
routes.post("/post/fetchFavouriteHashTag",AuthCheck,PostController.fetchFavouriteHashTag);
routes.post("/post/rePost",AuthCheck,PostController.rePost);
routes.post("/post/fetchFollowingPosts",AuthCheck,PostController.fetchFollowingPosts);
routes.post("/post/reportVideo",AuthCheck,PostController.rePortPost);
routes.post("/post/increasePostView",AuthCheck,PostController.increasePostView);
routes.post("/post/deletePostView",AuthCheck,PostController.deletePostView);
routes.post("/post/popularUserPost",AuthCheck,PostController.popularUserPost);
routes.post("/post/downloadVideo",AuthCheck,PostController.downloadVideo);
//

routes.post("/post/favouritePost",AuthCheck,PostController.favouritePost);
routes.post("/post/fetchFavouritePost",AuthCheck,PostController.fetchFavouritePost);
routes.post("/post/fetchFavouritePost1",AuthCheck,PostController.fetchFavouritePost1);

/// POST ROUTE END


// -------------------------------------------------------- Start on Admin module --------------------------------------------------------
routes.post("/admin/login", AuthApiKey, AdminController.signup);
routes.post("/admin/blockUser", AuthCheck, AdminController.blockUser);
routes.post("/admin/unblockUser", AuthCheck, AdminController.unblockUser);
routes.post("/admin/updateUser", AuthCheck, AdminController.updateUser);
routes.post("/admin/verifyUser", AuthCheck, AdminController.verifyUser);

routes.post("/admin/users", AuthCheck, AdminController.users);
routes.post("/admin/viewUserById", AuthCheck, AdminController.viewUserById);

// ---------------------------------------------------------start on setting---------------------------------------------------------------
routes.post("/setting/fetchSetting", AuthApiKey, SettingController.fetchSetting);
routes.post("/setting/changeSetting", AuthCheck, SettingController.changeSetting);
routes.get("/setting/fetchAllReportReason", AuthApiKey, SettingController.fetchAllReportReason);
routes.post("/setting/fetchAllSound",AuthCheck,SettingController.fetchAllSound);
routes.post("/setting/soundFavorite",AuthCheck,SettingController.soundFavorite);
routes.post("/setting/fetchFavoriteSound",AuthCheck,SettingController.fetchFavoriteSound);
routes.post("/setting/updatePushNotificationSettings",AuthCheck,SettingController.updatePushNotificationSettings);
routes.post("/setting/fetchSound",AuthCheck,SettingController.fetchSound);
routes.post("/setting/fetchNotification",AuthCheck,SettingController.fetchNotification);
routes.post("/setting/showVideosAgainstSound",AuthCheck,SettingController.showVideosAgainstSound);
routes.post("/setting/transactionHistory",AuthCheck,SettingController.transactionHistory);
routes.post("/setting/wallet",AuthCheck,SettingController.wallet);
routes.post("/setting/showPromotion",AuthCheck,SettingController.showPromotion);

// ---------------------------------------------------------language select as global---------------------------------------------------
routes.post("/language/fetchLanguage", AuthApiKey, SettingController.fetchLanguage);

// ----------------------------------------------------------fetch category is here ----------------------------------------------------
routes.post("/category/fetchCategory", AuthApiKey, SettingController.fetchCategory);


module.exports = routes;