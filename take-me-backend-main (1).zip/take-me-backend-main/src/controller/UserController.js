require("dotenv").config();
const { Validator } = require("node-input-validator");
const db = require('../../models');
const { User, UserCategory, Setting, Follower,PushNotification, BlockUser, CallRecord, UserRefferal, ReportUser, CoinPlan, Category,UserTopic ,PrivacySetting,
    NotificationMessages,gift,send_gift} = db;
const Cryptr = require("cryptr");
const { STATUSCODE, SUCCESSMESSAGE, CUSTOM_MESSAGE } = require('../utils/constant')
const { where, Op } = require("sequelize");
const Helper = require("../utils/helper");
const moment = require('moment');
const {RtcTokenBuilder, RtcRole, RtmTokenBuilder, RtmRole} = require('agora-token');
const { wallet } = require("./SettingController");
require("dotenv").config();

var UserController = {
    /**
     * Developer => Prince
     * Function to check email exist or not in account
     * 
     */
    fetchBlockUser: async (req, res) => {
        try {
            console.log(req.AuthUser.id);
            let getUser = await BlockUser.findAll({
                where: { user_id: req.AuthUser.id, status: true },
                include: [{
                    model: User,
                    as: 'blocked_user',
                    //attributes:['id','first_name'],
                    required: false,
                }]
            });
            return await Helper.successResponseWithData(res,'200', 'Block list has been fetched successfully', getUser);
        } catch (error) {
            console.log("_________________________________Error is here", error);
        }
    },

    /**
     * Developer => Anshuman
     * Function to check if the person is blocked by a user
     * params : user_id
     */
    checkBlockedByUser: async (req, res) => {
        try {

            let currentUserId = req.AuthUser.id
            let requestUserId = req.body.user_id;

            console.log(req.AuthUser.id);

            if (!requestUserId) {
                return await Helper.ErrorResponse(res, 'user_id_error_101', 'User id is required');
            }

            let blockedDetails = await BlockUser.findOne({
                where: {
                    user_id: requestUserId,
                    block_user_id: currentUserId
                }
            })
            if (!blockedDetails) {
                return await Helper.successResponseWithData(res, 'user_blocked_false', 'Current user is not blocked by requested user', { status: false })
            }
            return await Helper.successResponseWithData(res, 'user_blocked_true', 'Current usesr is blocked by the requested user', blockedDetails);
        } catch (error) {
            console.log("_________________________________Error is here", error);
        }
    },


    /**
     * Developer => Anshuman
     * Function to search a user
     * params : user_id
     */
    searchUser: async (req, res) => {
        try {
            let data = req.body;
            let searchDetails = "";
            if (data.limit || data.offset) {
                let searchValue = data.keyword;
                if (!searchValue) {
                    return await Helper.ErrorResponse(res, 'keyword_error_101', 'keyword is required');
                }
                let searchClause = `SELECT * FROM users WHERE is_block=false and first_name ilike '%${searchValue}%' OR username ilike '%${searchValue}%' OR email ilike '%${searchValue}%' OR phone ilike '%${searchValue}%' offset ${data.offset} limit ${data.limit}`;
                searchDetails = await db.sequelize.query(searchClause, {
                    model: User,
                    mapToModel: true // pass true here if you have any mapped fields
                });
            } else {
                let searchValue = data.keyword;
                if (!searchValue) {
                    return await Helper.ErrorResponse(res, 'keyword_error_101', 'keyword is required');
                }
                let searchClause = `SELECT * FROM users WHERE is_block=false and first_name ilike '%${searchValue}%' OR username ilike '%${searchValue}%' OR email ilike '%${searchValue}%' OR phone ilike '%${searchValue}%' limit ${10}`;
                searchDetails = await db.sequelize.query(searchClause, {
                    model: User,
                    mapToModel: true // pass true here if you have any mapped fields
                });
            }

            // if (!searchDetails) {
            //     return await Helper.ErrorResponse(res, 'user_not_found', 'user is not found')
            // }
            return await Helper.successResponseWithData(res, 'user_found', 'Users list', searchDetails);
        } catch (error) {
            console.log("_________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },

    /**
     * Developer => Prince
     * Function to check email exist or not in account
     * 
     */
    checkUserNameExistOrNot: async (req, res) => {
        try {
            let data = req.body;
            if (!data.email) { return await Helper.ErrorResponse(res, 'email_required', 'email is required'); }
            let checkEmailExists = await User.findOne({ where: { email: data.email } });
            // let generateotp = Math.floor(1000 + Math.random() * 9000);
            //         let obj = {
            //             otp: generateotp,
            //             email: data.email,
            //             expired_at: moment().format('YYYY-MM-DD HH:mm:ss'),
            //             // updated_at: new Date()
            //         }

            // let content = `<b>Hey there! </b><br> Please enter this code in your Take-me-backend app to complete the verification process. Do not share this code with anyone else.<br><b> otp :  ${obj.otp}  </b> <br><br> If you did not initiate this request, you may disregard this message. <br><br> Thank you<br> Reel Star Team'`;

            // let format = await Helper.emailBody(data.email, 'New Registration', content)

            // let mail = await Helper.sendMail(format)

            if (checkEmailExists == null) {
                return await Helper.ErrorResponse(res, 'email_not_found', 'email not found');
                // } else if (!checkEmailExists?.phone && checkEmailExists?.phone == null) {
                //     return await Helper.ErrorResponse(res, 'phone_not_found', 'phone not found'); 
            }
            else {
                return await Helper.successResponseWithData(res, 'email_found', 'User fetched detail by email', checkEmailExists);
            }
        } catch (error) {
            console.log("error", error)
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },
    /**
     * Developer => Prince
     * Function to check email exist or not in account
     * 
     */
    reportUser: async (req, res) => {
        try {
            let data = req.body;
            if (!data.report_reason_title) { return await Helper.ErrorResponse(res, 'reason_title_req', "report_reason_title required"); }
            if (!data.report_user_id) { return await Helper.ErrorResponse(res, 'report_user_req', "report_user_id is required"); }
            // if(!data.report_reason_id){return await Helper.ErrorResponse(res,'report_reason_req',"report_reason_id is required");}

            //let checkOwnRestrict=await User.findOne({where:{id}})
            // let checkReportedUserExists=await User.findOne({where:{id:data.report_user_id}});
            // if(!checkReportedUserExists){return await Helper.ErrorResponse(res,"to_report_user","To report user not found");}

            if (data.report_user_id == req.AuthUser.id) {
                return await Helper.ErrorResponse(res, "auth_not_matched", "You should choose the different report_user_id, not choose yourself");
            }
            let obj = {};
            obj = {
                user_id: req.AuthUser.id,
                report_reason_title: data.report_reason_title,
                description: data.description,
                report_user_id: data.report_user_id,
            }
            if (data?.report_reason_id) {
                obj.report_reason_id = data.report_reason_id
            }

            let makeReport = await ReportUser.create(obj);
            if (makeReport) {
                return await Helper.SuccessResponse(res, "make_report", "Report has been created successfully");
            }
        } catch (error) {
            console.log("___________________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },

    showTopics: async (req, res) => {
        try {
            let data = req.body;
            if (!data.user_id) { return await Helper.ErrorResponse(res, 'user id required', "user id required"); }

            let checkPhoneExists = await User.findOne({ where: { id: data.user_id } });

            if (!checkPhoneExists && checkPhoneExists != "") {
                return await Helper.ErrorResponse(res, 'user_not_found', 'User not found')
            }
            
            let existingTopic = await UserTopic.findOne({ where: { user_id: data.user_id } });

            if (!existingTopic) {
                // If topic not found, create a new one
                let obj = {
                    user_id: data.user_id,
                    title: "title",
                    image: 'https://takemeapp.s3.ap-southeast-1.amazonaws.com/uploads/1707465528.jpg'
                };
    
                let newTopic = await UserTopic.create(obj);
    
                return await Helper.successResponseWithData(res, 'New Topic Created', 'New topic created successfully', [newTopic]);
            }
    
            return await Helper.successResponseWithData(res, 'Topic', 'Topic fetched', [existingTopic]);
        } catch (error) {
            console.log("___________________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },

    addPrivacySetting: async (req, res) => {
        try {
            const data = req.body;

            const { user_id } = data;
            const setting = {};

            if (data.user_id !== undefined) {
                setting.user_id = data.user_id;
            }

            if (data.videos_download !== undefined) {
                setting.videos_download = data.videos_download;
            }

            if (data.direct_message !== undefined) {
                setting.direct_message = data.direct_message;
            }

            if (data.duet !== undefined) {
                setting.duet = data.duet;
            }

            if (data.liked_videos !== undefined) {
                setting.liked_videos = data.liked_videos;
            }

            if (data.direct_messages !== undefined) {
                setting.direct_messages = data.direct_messages;
            }

            if (data.video_comment !== undefined) {
                setting.video_comment = data.video_comment;
            }


            const details = await PrivacySetting.findOne({
                where: {
                    user_id: user_id
                }
            });
            console.log("check details---",details)

            let userDetails;
            if (details) {

                const updatedDetails = await PrivacySetting.update({
                    videos_download: data.videos_download,
                    direct_message: data.direct_message,
                    duet: data.duet,
                    liked_videos: data.liked_videos,
                    direct_messages: data.direct_messages,
                    video_comment: data.video_comment
                },
                    {
                    where: {
                        user_id: user_id
                    }
                });

                 await User.update({
                    videos_download: data.videos_download,
                    direct_message: data.direct_message,
                    duet: data.duet,
                    liked_videos: data.liked_videos,
                    direct_messages: data.direct_messages,
                    video_comment: data.video_comment
                },
                    {
                    where: {
                        id: user_id
                    }
                });
        
        
                if (updatedDetails > 0) {
                    // Fetch the updated details after the update operation
                     userDetails = await PrivacySetting.findOne({
                        where: {
                            user_id: user_id
                        }
                    });
                }

                return await Helper.successResponseWithData(res, 'user_details', 'User has been updated Successfully',userDetails);
            } else {
                

                let newDetils = await PrivacySetting.create(setting);

                return await Helper.successResponseWithData(res, 'user_details', 'User has been fetched Successfully',newDetils);
            }
        } catch (error) {
            console.log("____________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },

    updatePhone: async (req, res) => {
        try {
            let data = req.body;
            let phone = data.phone_number;
            
            // Check if phone_number field exists in the request body
            if (!phone) {
                return await Helper.ErrorResponse(res, 'phone_missing', 'Phone number is missing');
            }
            
            // Check if phone number is not a number
            if (isNaN(phone)) {
                return await Helper.ErrorResponse(res, 'phone_not_number', 'Phone number should be a number');
            }
    
            // Check if phone number length exceeds 10 characters
            if (phone.length > 10) {
                return await Helper.ErrorResponse(res, 'phone_length_exceeded', 'Phone number should not exceed 10 digits');
            }
    
            // Check if phone number exists in the database
            let existingUser = await User.findOne({ where: { phone: phone } });
            if (!existingUser) {
                // Update the phone number for the user with the specified id
                let updatedUser = await User.update({ phone: phone }, { where: { id: data.user_id } });
                // return res.json({ success: true, message: 'Phone number updated successfully' });
                return await Helper.successResponseWithData(res, 'update_phone', 'Phone number updated successfully');
            } else {
                return await Helper.ErrorResponse(res, 'phone_already_exists', 'Phone number already exists');
            }
        } catch (error) {
            console.log("____________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message || "Internal Server Error");
        }
    }
,    

    checkForPhone: async (req, res) => {
        try {
            let data = req.body;
            let phone = data.phone_number;
            //if(phone.length >= 10) { return await Helper.ErrorResponse(res,'phone_in_length','Phone number should not be grater then 10 number')}
            if (isNaN(phone)) {
                return await Helper.ErrorResponse(res, 'phone_in_number', 'Phone number should be in number')
            } else {
                let checkPhoneExists = await User.findOne({ where: { phone: data.phone_number } });

                if (!checkPhoneExists && checkPhoneExists != "") {
                    return await Helper.ErrorResponse(res, 'phone_not_found', 'Phone number not found')
                } else { return await Helper.ErrorResponse(res, 'phone_already_exists', 'phone number already exist') }
            }
        } catch (error) {
            console.log("____________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },
    /**
    * Developer => Prince
    * Function to check email exist or not in account
    * 
    */
    deleteUser: async (req, res) => {
        try {
            let data = req.body;
            let id = req.body.user_id;
            if (!data.user_id) {
                return await Helper.ErrorResponse(res, 'validation_error', 'Id field is required');
            }
            let userDetails = await User.findOne({ where: { id: data?.user_id } });
            if (userDetails) {
                userDetails.set({ is_deleted: true, is_notification: false });
                

                const notification = {};
                notification.likes = 0;
                notification.comments = 0;
                notification.new_followers = 0;
                notification.mentions = 0;
                notification.direct_messages = 0;
                notification.video_updated =0;

                const details = await PushNotification.findOne({where:{id:data?.user_id}})
                // console.log("check push notification-delete--",details)
        
                if (!!details) {
                    await PushNotification.update(notification,{where:{id:data?.user_id}})
                    let updatedDetails = await PushNotification.findOne({where:{id:data?.user_id}})
        
                } else {
                    notification.id = data?.user_id;
                    const newDetails = await PushNotification.create(notification);
                    console.log("else part")
        
                }

                if (await userDetails.save()) {
                    return await Helper.successResponseWithData(res, 'user_deleted', 'User has been deleted Successfully');
                }
            }
        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    
    /**
     * Delete user api to fetchProfileCategories of a particular user
     * Developer : Anshuman
     * @param {*} req 
     * @param {*} res 
     */
    fetchProfileCategories: async (req, res) => {
        try {
            let id = req.body.id;
            if (!id) {
                return await Helper.ErrorResponse(res, 'validation_error', 'Id field is required');
            }
            let userDetails = await User.findOne({ wherer: { id: id } });

            return await Helper.successResponseWithData(res, 'profile_categories', 'Profile category recieved');

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    /**
     * Delete user api to follow a particular user
     * Developer : Anshuman
     * @param {*} req 
     * @param {*} res 
     */
    followUser: async (req, res) => {
        try {

            let data = req.body;

            let sender_id = req.AuthUser.id;
            // let receiver_id = req.body.id;
            let checkProfile = await User.findOne({where:{id:sender_id}})
            // console.log("=-=-=-=-",checkProfile.profile_pic)

            if (!data.receiver_id) {
                return await Helper.ErrorResponse(res, 'id_not_found', 'Followed Person\'ns id is required')
            }
            if (data.receiver_id == req.AuthUser.id) {
                return await Helper.ErrorResponse(res, 'following_self', 'Can\'t follow yourself')
            }

            let isUserReportedOrBlocked = await Helper.isUserReportedOrBlocked(req.AuthUser.id, data.receiver_id);
            let isUserReportedOrBlockedBy = await Helper.isUserReportedOrBlockedBy( req.AuthUser.id, data.receiver_id);
            console.log('===============isUserReportedOrBlocked=======',isUserReportedOrBlocked)
            console.log('===============isUserReportedOrBlockedBy=======',isUserReportedOrBlockedBy)
            if(isUserReportedOrBlocked == 'YOU_BLOCKED_USER' ){
                return await Helper.ErrorResponse(res, 'block_user_error', "You have blocked this user.")
            } 
            if(isUserReportedOrBlockedBy == 'BLOCKED_USER_BY'){
                return await Helper.ErrorResponse(res, 'blocked_by_user_error', "You are blocked by this user.")
            }

            let insertObject = {};
            insertObject = {
                sender_id: sender_id,
                receiver_id: data?.receiver_id
            }
            if (data.promotion_id) {
                insertObject.promotion_id = data.promotion_id
            }

            // check if user is already followed
            let checkIfUserFollowed = await Follower.findOne({
                where: {
                    sender_id: sender_id,
                    receiver_id: data.receiver_id
                }
            })
            let recfollowers = await Follower.findAll({where:{receiver_id:data?.receiver_id}})
            let recfollowing = await Follower.findAll({where:{sender_id:data?.receiver_id}})
            let followers = await Follower.findAll({where:{receiver_id:req.AuthUser.id}})
            let following = await Follower.findAll({where:{sender_id:req.AuthUser.id}})
            console.log('checkkckckckkc====================',checkIfUserFollowed)
            // receiver_follower_count, receiver_following
            // if user is unfollowed then follow them back
            if (checkIfUserFollowed != null && Object.keys(checkIfUserFollowed)?.length > 0 && checkIfUserFollowed?.status) {
                checkIfUserFollowed.dataValues.follower_count  = followers?.length || 0
                checkIfUserFollowed.dataValues.following_count = following?.length  || 0
                checkIfUserFollowed.dataValues.receiver_follower_count  = recfollowers?.length || 0
                checkIfUserFollowed.dataValues.receiver_following_count = recfollowing?.length  || 0

                checkIfUserFollowed.dataValues.user_pic = checkProfile.profile_pic
                checkIfUserFollowed.dataValues.type = 'follow'
                return await Helper.successResponseWithData(res, 'user_followed', "User followed successfully", checkIfUserFollowed)
            }

            // update user to follow if it was unfollowed before
            if (checkIfUserFollowed != null && Object.keys(checkIfUserFollowed)?.length > 0 && !checkIfUserFollowed?.status) {

                checkIfUserFollowed.set({
                    status: true
                });
                
                let followedUserUpdate = await checkIfUserFollowed.save();
                followedUserUpdate.dataValues.follower_count  = followers?.length || 0
                followedUserUpdate.dataValues.following_count = following?.length  || 0
                followedUserUpdate.dataValues.receiver_follower_count  = recfollowers?.length || 0
                followedUserUpdate.dataValues.receiver_following_count = recfollowing?.length  || 0
                
                let pushNotfSettingDetail = await PushNotification.findOne({
                    where: {
                        id: data.receiver_id
                    }
                });
               
                if (pushNotfSettingDetail && pushNotfSettingDetail.new_followers == 1){
                    // send notification to the followed user
                    if(data.receiver_id != req.AuthUser?.id){
                        var message = `${req.AuthUser?.username} has followed you`;
                        let payload = {
                            unique_id: req.AuthUser?.unique_id,
                            username: req.AuthUser?.username,
                            user_id: req.AuthUser.id,
                            sender_id: req.AuthUser.id,
                            receiver_id: data.receiver_id,
                            video_id: '',
                            image: req.AuthUser?.profile_pic,
                            title: message,
                            type: 'newFollower',
                            checkIfUserFollowed: checkIfUserFollowed
                        }
                        await Helper.sendPushNotification2(req, data.receiver_id, process.env.APP_NAME, message, payload);
                        // await Helper.sendPushNotification2(req, data.receiver_id, 'you have a new follower', `One user has followed you.`,checkIfUserFollowed)
                        await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:data.receiver_id,message: `${req.AuthUser.username} has followed you.`,type:"Follow_User"})
                    }
                }
                return await Helper.successResponseWithData(res, 'user_followed', "User followed successfully..", followedUserUpdate)
            }

            let followedUser = await Follower.create(insertObject);
            
            if (followedUser) {
                console.log("check folloer user",followedUser)
                
                followedUser.dataValues.follower_count  = followers?.length || 0
                followedUser.dataValues.following_count = following?.length +1 || 0
                followedUser.dataValues.receiver_follower_count  = recfollowers?.length || 0
                followedUser.dataValues.receiver_following_count = recfollowing?.length +1 || 0

                let pushNotfSettingDetail = await PushNotification.findOne({
                    where: {
                        id: data.receiver_id
                    }
                });
               
                if (pushNotfSettingDetail && pushNotfSettingDetail.new_followers == 1){
                    if(data.receiver_id != req.AuthUser?.id){
                        var message = `${req.AuthUser?.username} has followed you`;
                        let payload = {
                            unique_id: req.AuthUser?.unique_id,
                            username: req.AuthUser?.username,
                            user_id: req.AuthUser.id,
                            sender_id: req.AuthUser.id,
                            receiver_id: data.receiver_id,
                            video_id: '',
                            image: req.AuthUser?.profile_pic,
                            title: message,
                            type: 'newFollower',
                            checkIfUserFollowed: checkIfUserFollowed
                        }
                        await Helper.sendPushNotification2(req, data.receiver_id, process.env.APP_NAME, message, payload);
                        
                        // await Helper.sendPushNotification2(req, data.receiver_id, 'you have a new follower', `One user has followed you.`,checkIfUserFollowed)
                        await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:data.receiver_id,message: `${req.AuthUser.username} has followed you.`,type:"Follow_User"})
                    }
                }
                    return await Helper.successResponseWithData(res, 'user_followed', 'User folowed successfully', followedUser);
                // send notification to the followed user
            } else {
                return await Helper.ErrorResponse(res, 'follow_user_error', "Could not follow user")

            }
        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },


    /**
       * Delete user api to follow a particular user
     * Developer : Anshuman
       * @param {*} req 
       * @param {*} res 
       */
    unFollowUser: async (req, res) => {
        try {
            let data = req.body;

            let sender_id = req.AuthUser.id;
            let receiver_id = data.receiver_id;

            if (!receiver_id) {
                return await Helper.ErrorResponse(res, 'UnFollowed Person\'ns id is required')
            }
            if (data.receiver_id == req.AuthUser.id) {
                return await Helper.ErrorResponse(res, 'unfollow_self', 'Can\'t unfollow yourself')
            }

            // check if user is followed or not
            let checkIfUserFollowed = await Follower.findOne({
                where: {
                    sender_id: sender_id,
                    receiver_id: receiver_id
                }
            })
            let followers = await Follower.findAll({where:{receiver_id:req.AuthUser.id}})
            let following = await Follower.findAll({where:{sender_id:req.AuthUser.id}})
            let recfollowers = await Follower.findAll({where:{receiver_id:data?.receiver_id}})
            let recfollowing = await Follower.findAll({where:{sender_id:data?.receiver_id}})

            

            // if user is followed
            if (checkIfUserFollowed != null && Object.keys(checkIfUserFollowed)?.length > 0 && checkIfUserFollowed?.status) {
                checkIfUserFollowed.set({
                    status: false
                })
                let unFollowedUser = await checkIfUserFollowed.save();
                checkIfUserFollowed.dataValues.follower_count = followers?.length || 0
                checkIfUserFollowed.dataValues.following_count = following?.length -1 || 0
                checkIfUserFollowed.dataValues.receiver_follower_count = recfollowers?.length || 0
                checkIfUserFollowed.dataValues.receiver_following_count = recfollowing?.length -1 || 0

                if (!unFollowedUser) {
                    return await Helper.ErrorResponse(res, 'unfollow_user_error', "Could not unfollow user")
                }
                return await Helper.successResponseWithData(res, 'user_unfollowed', "User unfollowed successfully.", checkIfUserFollowed)
            }

            await Follower.destroy({ where: { sender_id: sender_id,receiver_id:receiver_id } });
            // if user was not followed
            if (checkIfUserFollowed != null && Object.keys(checkIfUserFollowed)?.length > 0 && !checkIfUserFollowed?.status) {
                checkIfUserFollowed.dataValues.follower_count = followers?.length || 0
                checkIfUserFollowed.dataValues.following_count = following?.length -1 || 0
                checkIfUserFollowed.dataValues.receiver_follower_count = recfollowers?.length || 0
                checkIfUserFollowed.dataValues.receiver_following_count = recfollowing?.length -1 || 0
                
                return await Helper.successResponseWithData(res, 'user_unfollowed', "User unfollowed successfully.", checkIfUserFollowed)

            }

            // if record does not exist 
            if (checkIfUserFollowed == null) {
                return await Helper.ErrorResponse(res, 'follow_user_error', "Can\'t unfollow. This user was not followed.")

            }
            // res.end('')

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    checkFollower: async (req, res) => {
        try {
            let data = req.body;

            let sender_id = req.AuthUser.id;
            let receiver_id = data.user_id;
            let checkFollowing,checkFollowers

            if (!receiver_id) {
                return await Helper.ErrorResponse(res, 'receiver Person\'ns id is required')
            }
            if (!sender_id) {
                return await Helper.ErrorResponse(res, 'UnFollowed Person\'ns id is required')
            }
            if (!sender_id) {
                return await Helper.ErrorResponse(res, 'sender Person\'ns id is required')
            }

            // check if user is followed or not 
            if (data.type === "follower") {
                checkFollowers = await Follower.findOne({
                    where: {
                        sender_id: sender_id,
                        receiver_id: receiver_id
                    }
                })
               
                // return await Helper.successResponseWithData(res, 'user_follow', "User follower.", {isFollow:checkFollowers ? true :false})
                return await res.send({
                    "status": true,
                    "code": "user_follow",
                    "message": "User follower.",
                    isFollow:checkFollowers ? true :false
                })
              
            }
            if (data.type === "following") {
                checkFollowing = await Follower.findOne({
                    where: {
                        sender_id: receiver_id,
                        receiver_id: sender_id
                    }
                })
                // return await Helper.successResponseWithData(res, 'user_following', "User following.",  {isFollowing:checkFollowers ? true :false})
                return await res.send({
                    "status": true,
                    "code": "user_following",
                    "message": "User following..",
                    isFollow:checkFollowers ? true :false
                })
            }
            

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },


    /**
       * Delete user api to fetch-following-list of a particular user
    * Developer : Anshuman
       * @param {*} req 
       * @param {*} res 
       */
    fetchFollowingList: async (req, res) => {
        try {
            let data = req.body;
            if(!data.user_id){return await Helper.ErrorResponse(res,'user_id_req','user_id is required')}
            //following fetched by following=> sender_id and follower =>receiver_id fetched by receiver
            let currentUserId = data.user_id;
            let responsePayload = {};

            // check total followings
            let checkIfUserFollowed = await Follower.findAll({
                attributes: ['sender_id', 'receiver_id', 'status'],
                where: {
                    
                    sender_id: currentUserId
                },
                include: [{
                    model: User,
                    as: 'receiverDetail',
                    required: false,
                    attributes: ['username', 'first_name', 'last_name', 'email', 'status', 'phone', 'profile_pic']
                }],
                order: [['createdAt', 'DESC']],
                limit: data?.limit || 10,
                offset: data?.offset || 0,
                subQuery: false
            });
           
            if (checkIfUserFollowed && checkIfUserFollowed?.length > 0) {
                for(let i =0; i< checkIfUserFollowed.length; i++){

                    let checkFollow = await Follower.findAll({
                        attributes: ['sender_id', 'receiver_id', 'status'],
                        where: {
                            receiver_id: checkIfUserFollowed[i].receiver_id,
                            sender_id: req.AuthUser.id ,
                        }});

                    if(checkFollow.length>0){
                        checkIfUserFollowed[i].receiverDetail.dataValues.button = "Unfollow"
                    }
                    else {
                        checkIfUserFollowed[i].receiverDetail.dataValues.button = "Follow"
                    }
                }
                return await Helper.successResponseWithData(res, 'user_follwings', "Following list.", checkIfUserFollowed)

            } else {

                return await Helper.successResponseWithData(res, 'user_follwings', "Following list", checkIfUserFollowed)

            }


        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },


    /**
       * Delete user api to fetch-follower-list of a particular user
     * Developer : Anshuman
       * @param {*} req 
       * @param {*} res 
       */
    fetchFollowerList: async (req, res) => {
        try {
            let data = req.body;
            if(!data.user_id){return await Helper.ErrorResponse(res,'user_id_req','user_id is required')}
            let currentUserId = data.user_id;
            let responsePayload = {};

            // check total followings
            let checkIfUserFollowed = await Follower.findAll({

                attributes: ['sender_id', 'receiver_id', 'status'],
                where: {
                    receiver_id: data.user_id,
    
                },
                include: [{
                    model: User,
                    as: 'senderDetail',
                    required: false,
                    attributes: ['username', 'first_name', 'last_name', 'email', 'status', 'phone', 'profile_pic']
                }],
               
                order: [['createdAt', 'DESC']],
                limit: data?.limit || 10,
                offset: data?.offset || 0,
                subQuery: false
            })


           
            let  receiver_id;
            let checkFollow = await Follower.findAll({where:{sender_id:req.AuthUser.id}})
            
           let blockUser;

            if (checkIfUserFollowed && checkIfUserFollowed?.length > 0) {
               

                let modifiedArr = await Promise.all(checkIfUserFollowed.map(async (items) => {

                    blockUser = await BlockUser.findOne({
                        where: {
                            user_id: req.AuthUser.id,
                            block_user_id: items.sender_id,
                            status: true // Filter by status true
                        }
                    });
                  
                //    if(!blockUser){
                    let isFollowed = checkFollow.some(obj => obj.receiver_id === items.sender_id);
                    

                    if (isFollowed) {
                        items.senderDetail.dataValues.button = "Unfollow";
                    } else {
                        items.senderDetail.dataValues.button = "Follow";
                    }
                    if (items.sender_id === req.AuthUser.id) {
                        items.senderDetail.dataValues.button = ""
                    }
                // }++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //    return items
                    
                }))
                

                return await Helper.successResponseWithData(res, 'followers', "Followers list.", checkIfUserFollowed)

            } else {

                return await Helper.successResponseWithData(res, 'followers', "Followers list", checkIfUserFollowed)

            }

            // let modifiedArr = await Promise.all(checkIfUserFollowed.map(async (items) => {
            //     blockUser = await BlockUser.findAll({
            //         where: {
            //             user_id: req.AuthUser.id,
            //             block_user_id: items.sender_id,
            //             status: true // Filter by status true
            //         }
            //     });
            
            //     // Check if blockUser is empty, meaning the user is not blocked with status true
            //     if (blockUser.length === 0) {
            //         let isFollowed = checkFollow.some(obj => obj.receiver_id === items.sender_id);
            
            //         if (isFollowed) {
            //             items.senderDetail.dataValues.button = "Unfollow";
            //         } else {
            //             items.senderDetail.dataValues.button = "Follow";
            //         }
            //         if (items.sender_id === req.AuthUser.id) {
            //             items.senderDetail.dataValues.button = "";
            //         }
            //         return items;
            //     }
            // }));
            
            // // Filter out null values (i.e., where users exist in BlockUser with status true)
            // modifiedArr = modifiedArr.filter(item => item !== null);
            
            // return await Helper.successResponseWithData(res, 'followers', "Followers list.", modifiedArr);


        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    /**
       * check if user follow a particular user
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    checkFollowUser: async (req, res) => {
        try {

            // let currentUserId = req.AuthUser.id;
            let data = req.body



            if (!data.user_id) {
                return await Helper.ErrorResponse(res, 'validation_error', "Following user id is required");
            }

            // check total followings
            let checkIfUserFollowed = await Follower.findOne({
                where: {
                    receiver_id: data.user_id,
                    status: true
                }
            })

            if (checkIfUserFollowed != null && Object.keys(checkIfUserFollowed)?.length > 0) {

                return await Helper.successResponseWithData(res, 'user_followed', "The current user is following this user ", checkIfUserFollowed)
            } else {

                return await Helper.ErrorResponse(res, 'user_not_followed', "The current user is not following this user")

            }

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    /**
       * check if user follow a particular user
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    addDeviceData: async (req, res) => {
        try {

            let data = req.body;
            let updateObj = {};

            let user_id;
            if (!data.user_id) {
                user_id = req.AuthUser.id
            } else {
                user_id = data.user_id
            }

            if (!data.device_token) {
                return await Helper.ErrorResponse(res, 'device_token_error', "Device token is required");

            }
            if (!data.device) {
                return await Helper.ErrorResponse(res, 'device_error', "please provide a valid device_name");

            }

            let userDetails = await User.findOne({ where: { id: user_id } });

            if (userDetails != null && Object.keys(userDetails)?.length > 0) {

                updateObj = {
                    device_token: data.device_token,
                    device: data.device.toLowerCase()
                }
                if (data.ip) updateObj.ip = data.ip
                if (data.version) updateObj.version = data.version

                userDetails.set(updateObj);

                if (await userDetails.save()) {
                    return await Helper.successResponseWithData(res, 'device_data_added', "Device data for the current user has been added", userDetails)
                } else {
                    return await Helper.ErrorResponse(res, 'device_data_error', "Unable to add device data");
                }
            }

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    /**
       * Function to add call records
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    createCallRecord: async (req, res) => {
        try {

            let data = req.body;
            let updateObj = {};

            if (!data.from_user_id) {
                return await Helper.ErrorResponse(res, 'from_user_id_req', "From user id is required");

            }
            if (!data.to_user_id) {
                return await Helper.ErrorResponse(res, 'to_user_id_req', "To user id is required");

            }
            if (!data.type) {
                return await Helper.ErrorResponse(res, 'type_req', " type is required");

            }
            let checkFromUser = await Helper.checkUserExistOrNot(data.from_user_id)
            let checkToUser = await Helper.checkUserExistOrNot(data.to_user_id)
            if (!checkFromUser) {
                return await Helper.ErrorResponse(res, 'from_user_id_error', 'From user does not exist');
            }
            if (!checkToUser) {
                return await Helper.ErrorResponse(res, 'from_user_id_error', 'To user does not exist');
            }

            let insertObject = {
                from_user_id: data.from_user_id,
                to_user_id: data.to_user_id,
                type: data.type,
            }
            data.action ? insertObject.action = data.action : null;
            data.duration ? insertObject.duration = data.duration : null;

            let callRecords = await CallRecord.create(insertObject);

            if (!callRecords) {
                return await Helper.ErrorResponse(res, 'call_save_error', "Call could not be saved");
            }
            return await Helper.successResponseWithData(res, 'call_save_success', 'call saved successfully', callRecords);

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },


    /**
       * Function to send notification to livestream user
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    liveStreamUser: async (req, res) => {
        try {

            let live_user_id = req.body.user_id;
            let notificationResponse = [];

            if (!live_user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', "User id is required");
            }

            let checkUserExist = await User.findOne({ where: { id: live_user_id } })

            if (checkUserExist && Object.keys(checkUserExist)?.length < 1) {
                return await Helper.ErrorResponse(res, 'user_not_found', "User not found")
            }

            // get all followers of the user
            let checkFollowers = await Follower.findAll({ where: { receiver_id: live_user_id } })

            console.log("checkFollowers", checkFollowers?.length)
            if (checkFollowers?.length > 0) {

                let result = await checkFollowers?.map(async (user, index) => {
                    if(user.receiver_id != checkUserExist?.id){
                        if(user.receiver_id != checkUserExist?.id){
                            var message = `${checkUserExist?.first_name} has started live streaming.`;
                            let payload = {
                                unique_id: checkUserExist?.unique_id,
                                username: checkUserExist?.username,
                                user_id: checkUserExist?.id,
                                sender_id: checkUserExist?.id,
                                receiver_id: user.receiver_id,
                                video_id: '',
                                image: checkUserExist?.profile_pic,
                                title: message,
                                type: 'liveStreaming',
                            }
                            await Helper.sendPushNotification2(req, user.receiver_id, process.env.APP_NAME, message, payload);

                            // let sendNotification = await Helper.sendPushNotification2(req, user.receiver_id, `${checkUserExist?.first_name} is live`, `${checkUserExist?.first_name} + ${checkUserExist?.last_name} has started live streaming.`
                            // )
                            await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:user.receiver_id,message: `${checkUserExist?.username} is live`,type:"Live_User"})
                        }
                    }


                    if (index == checkFollowers?.length - 1) {
                        return await Helper.successResponseWithData(res, 'notification_sent', "notification fired successfully")
                    }

                });
                // return await Helper.successResponseWithData(res, 'notification_sent', 'Notifications has been sent to followers', notificationResponse);

            } else {
                return await Helper.ErrorResponse(res, 'no_followers_found', "No followers found")
            }

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },


     /**
       * Function GENERATE RANDOM AGORA TOKEN
     * Developer : KESHAV
       * @param {*id} req 
       * @param {*} res 
       */
     generateAgoraToken: async (req, res) => {
        try {
            const APP_ID = process.env.AGORA_APP_ID;
            const APP_CERTIFICATE = process.env.AGORA_APP_CERT;
             // set response header
             res.header('Access-Control-Allow-Origin', '*');
            // get channel name
            const channelName = req.body.channel;
            if (!channelName) {
                return res.status(400).json({ 'error': 'channel is required' });
            }
            // get uid
            let uid = req.body.uid;
            if(!uid || uid === '') {
                return res.status(400).json({ 'error': 'uid is required' });
            }
            // get role
            let role;
            if (req.body.role === 'publisher') {
                role = RtcRole.PUBLISHER;
            } else if (req.body.role === 'audience') {
                role = RtcRole.SUBSCRIBER
            } else {
               // return res.status(400).json({ 'error': 'role is incorrect' });
                return await Helper.ErrorResponse(res, 'error', "role is incorrect");

            }
            // get the expire time
            let expireTime = req.body.expiry;
            if (!expireTime || expireTime === '') {
                expireTime = 3600;
            } else {
                expireTime = parseInt(expireTime, 10);
            }
            // calculate privilege expire time
            const currentTime = Math.floor(Date.now() / 1000);
            const privilegeExpireTime = currentTime + expireTime;
            // build the token
            const rtcToken = RtcTokenBuilder.buildTokenWithUid(APP_ID, APP_CERTIFICATE, channelName, 0, role, privilegeExpireTime);
            const rtmToken = RtmTokenBuilder.buildToken(APP_ID, APP_CERTIFICATE, 0, role, privilegeExpireTime);
            // return the token
            let data ={};
            data = { 'rtcToken': rtcToken, 'rtmToken': rtmToken };

             // get all followers of the user
             let checkUserExist = await User.findOne({ where: { id: req.AuthUser.id } })
             
             let checkFollowers = await Follower.findAll({ where: { receiver_id: req.AuthUser.id } })

             console.log("checkFollowers", checkFollowers.length,)
             if (checkFollowers?.length > 0) {
 
                 let result = await checkFollowers?.map(async (user, index) => {
                    console.log("chck user",user.receiver_id)
                    if(user.receiver_id != checkUserExist?.id){
                        var message = `${checkUserExist?.first_name} has started live streaming.`;
                        let payload = {
                            unique_id: checkUserExist?.unique_id,
                            username: checkUserExist?.username,
                            user_id: checkUserExist?.id,
                            sender_id: checkUserExist?.id,
                            receiver_id: user.receiver_id,
                            video_id: '',
                            image: checkUserExist?.profile_pic,
                            title: message,
                            type: 'liveStreaming',
                        }
                        await Helper.sendPushNotification2(req, user.receiver_id, process.env.APP_NAME, message, payload);
    
                        //  let sendNotification = await Helper.sendPushNotification2(req, user.receiver_id, `${checkUserExist?.first_name} is live`, `${checkUserExist?.first_name} + ${checkUserExist?.last_name} has started live streaming.`)
                        await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:user.receiver_id,message: `${checkUserExist?.username} is live`,type:"token"})
                    }
                     if (index == checkFollowers?.length - 1) {
                        console.log("notification send")
                        //  return await Helper.successResponseWithData(res, 'notification_sent', "notification fired successfully")
                     }
 
                 });
 
             } 
            return await Helper.successResponseWithData(res, 'token_fetch_success', 'Token fetched successfully', data);

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },


    sendLiveStreamPushNotfication: async (req, res) => {
        try {

            let live_user_id = req.body.user_id;
            let notificationResponse = [];
            console.log("=-=-=-",live_user_id)

            if (!live_user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', "User id is required");
            }

            let checkUserExist = await User.findOne({ where: { id: live_user_id } })

            if (checkUserExist && Object.keys(checkUserExist)?.length < 1) {
                return await Helper.ErrorResponse(res, 'user_not_found', "User not found")
            }

            // get all followers of the user
            let checkFollowers = await Follower.findAll({ where: { receiver_id: live_user_id } })
            let checkFollowing = await Follower.findAll({ where: { sender_id: live_user_id } })

            // console.log("checkFollowers", checkFollowing)
            // checkFollowing.receiver_id == checkFollowers.sender_id
            if (checkFollowers?.length > 0 || checkFollowing?.length > 0) {

                const followersIDs = checkFollowers.map(user => user.sender_id);
                const followingIDs = checkFollowing.map(user => user.receiver_id);
                const uniqueUserIDs = [...new Set([...followersIDs, ...followingIDs])];
                // console.log("=-=-=-=-=-=",followersIDs,followingIDs,uniqueUserIDs)

                // await checkFollowers?.map(async (user, index) => {
                    
                //     let sendNotification = await Helper.sendPushNotification2(req, user.sender_id, `${checkUserExist?.first_name} is live`, `${checkUserExist?.first_name} + ${checkUserExist?.last_name} has started live streaming.`
                //     )
                // });

                // await checkFollowing?.map(async (user, index) => {
                    
                //     let sendNotification = await Helper.sendPushNotification2(req, user.receiver_id, `${checkUserExist?.first_name} is live`, `${checkUserExist?.first_name} + ${checkUserExist?.last_name} has started live streaming.`
                //     )
                // });

                for (const userID of uniqueUserIDs) {
                    if(userID != checkUserExist?.id){
                        var message = `${checkUserExist?.first_name} has started live streaming.`;
                        let payload = {
                            unique_id: checkUserExist?.unique_id,
                            username: checkUserExist?.username,
                            user_id: checkUserExist?.id,
                            sender_id: checkUserExist?.id,
                            receiver_id: userID,
                            video_id: '',
                            image: checkUserExist?.profile_pic,
                            title: message,
                            type: 'liveStreaming',
                        }
                        await Helper.sendPushNotification2(req, userID, process.env.APP_NAME, message, payload);



                        // await Helper.sendPushNotification2(
                        //     req,
                        //     userID,
                        //     `${checkUserExist?.first_name} is live`,
                        //     `${checkUserExist?.first_name} ${checkUserExist?.last_name} has started live streaming.`
                        // );
                        await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:userID,message: `${checkUserExist?.username} is live`,type:"User_Live"})
                    }
                }
                
                // if (index == checkFollowers?.length - 1) {
                    return await Helper.successResponseWithData(res, 'notification_sent', "notification fired successfully")
                // }
               

            } else {
                return await Helper.ErrorResponse(res, 'no_followers_found', "No followers found")
            }

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    /**
       * Function to send notification to livestream user
     * Developer : Anshuman
       * @param {*id,} req 
       * @param {*} res 
       */
    fetchUserCallRecord: async (req, res) => {
        try {
            let user_id = req.AuthUser.id;
            let data = {};

            let incoming = await CallRecord.findAll({ where: { from_user_id: user_id }, order: [['createdAt', 'DESC']] });

            let outgoing = await CallRecord.findAll({ where: { to_user_id: user_id }, order: [['createdAt', 'DESC']] });

            data.incoming = incoming;
            data.outgoing = outgoing;

            return await Helper.successResponseWithData(res, 'call_fetch_success', 'Call fetched successfully', data);


        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    /**
       * Function to send notification to verifyRefferalCode
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    verifyReferralCode: async (req, res) => {
        try {
            let current_user_id = req.AuthUser.id;
            let referral_code = req.body.referral_code;

            if (!referral_code) {
                return await Helper.ErrorResponse(res, 'referral_code_req', 'Referral code is required')
            }
            let checkReferralCode = UserRefferal.findOne({
                where: { user_id: current_user_id, referral_code },
                order: [['createdAt', 'DESC']]
            });
            if (checkReferralCode && Object.keys(checkReferralCode)?.length > 0) {
                return await Helper.successResponseWithData(res, 'referral_code_valid', 'Referral code is valid', checkReferralCode);
            } else {
                return await Helper.ErrorResponse(res, 'invalid_referral_code', 'Referral code is invalid');
            }

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    /**
       * Function to send notification to updateUserCallStatus
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    updateUserCallStatus: async (req, res) => {
        try {
            let data = req.body;
            if (!data.to_user_id) {
                return await Helper.ErrorResponse(res, 'to_user_id_req', "To user id is required")
            }
            let userCall = await CallRecord.findOne({ where: { to_user_id: data.to_user_id }, order: [['createdAt', 'DESC']] })

            if (!userCall) {
                return await Helper.ErrorResponse(res, 'user_call_unavailable', "user_call not found")
            }
            userCall.set({
                status: data.status || false
            })
            if (await userCall.save()) {
                return await Helper.successResponseWithData(res, 'call_status_updated', "Call status updated successfully", userCall)
            }

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    /**
       * Function to send notification to updateUserCallStatus
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    addCoinPlan: async (req, res) => {
        try {
            let data = req.body;
            if (!data.user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', "User id is required")
            }
            // let userCoins = await CoinPlan.findOne({ where: { user_id: data.user_id }, order: [['createdAt', 'DESC']] })

            // if (userCoins && Object.keys(userCoins).length == 0) {

            let insertObject = {
                user_id: data.user_id
            }
            data.appstore_product_id ? insertObject.appstore_product_id = data.appstore_product_id : null;
            data.coin_amount ? insertObject.coin_amount = parseFloat(data.coin_amount) : null;
            data.playstore_product_id ? insertObject.playstore_product_id = data.playstore_product_id : null;
            data.price ? insertObject.price = parseFloat(data.price) : null;

            let coinResult = await CoinPlan.create(insertObject);
            if (coinResult) {
                return await Helper.successResponseWithData(res, 'user_coin_added', "user coin added successfully", coinResult)
            } else {
                return await Helper.ErrorResponse(res, 'user_coin_added', "user coin added successfully")
            }
            // }else{

            //     let updateObj = {

            //     }
            //     userCoins.set({
            //         status: data.status || false
            //     })
            // }

            // if (await userCoins.save()) {
            //     return await Helper.successResponseWithData(res, 'call_status_updated', "Call status updated successfully", userCoins)
            // }

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },


    /**
       * Function to send notification to updateUserCallStatus
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    fetchCoinPlan: async (req, res) => {
        try {
            let data = req.body;
            // if (!data.user_id) {
            //     return await Helper.ErrorResponse(res, 'user_id_req', "User id is required")
            // }

            let whereCondition = {}
            data.appstore_product_id ? where.appstore_product_id = data.appstore_product_id : null
            data.playstore_product_id ? where.playstore_product_id = data.appstore_product_id : null


            let plan = await CoinPlan.findAll({
                where: whereCondition,
                order: [['createdAt', 'DESC']],
                include: [{
                    model: User,
                    as: 'userCoins',
                    required: false,
                    attributes: ['first_name', 'last_name', 'email', 'status', 'phone', 'profile_pic','username']
                }],

                limit: data?.limit || 10,
                offset: data?.offset || 0,
                subQuery: false
            });
            let coinValue = await Setting.findOne({ attributes: ['value'] });

            await plan?.map(items => {
                if (items.coin_amount != null) {
                    items.price = (parseFloat(items.coin_amount) * parseFloat(coinValue.value || 0.001)).toFixed(2)
                }
            })


            return await Helper.successResponseWithData(res, 'user_coin_retrieved', "user coin retrieved successfully", plan)

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },
    /**
       * Function to fetch all user detail
     * Developer : Prince
       * @param {*id} req 
       * @param {*} res 
       */
    fetchAllUser: async (req, res) => {
        try {
            let data = req.body;
            //get the following
            let followingUser = await Follower.findAll({ attributes: ['receiver_id'], where: { sender_id: req.AuthUser.id } });
            // console.log("=-=-=",followingUser)
         
            let user = "";
            if (followingUser.length > 0) {
                // for (let i = 0; i < followingUser.length; i++) {
                //     if (followingUser[i]?.receiver_id != null) {
                //         user = await User.findAll({
                //             where: { id: { [Op.notIn]: [followingUser[i]?.receiver_id] } },
                //             attributes: ['id', 'first_name', 'username', 'email', 'status', 'createdAt', 'updatedAt', 'profile_pic'],
                //             order: [['createdAt', 'DESC']],
                //             limit: data.limit || 10,
                //             offset: data.offset || 0
                //         });
                        
                //     }
                // }
                let followedIds = followingUser.map(follow => follow.receiver_id);
                user = await User.findAll({
                    where: { id: { [Op.notIn]: followedIds } },
                    attributes: ['id', 'first_name', 'last_name', 'username', 'email', 'status', 'createdAt', 'updatedAt', 'profile_pic'],
                    order: [['createdAt', 'DESC']],
                    limit: data.limit || 10,
                    offset: data.offset || 0
                });
            } else {

                user = await User.findAll({
                    limit: data.limit || 10,
                    offset: data.offset || 0,
                    order: [['createdAt', 'DESC']]
                });
            }
          
            let filterUser = await user.filter(val => val.id != req.AuthUser.id);

            filterUser.forEach((item)=>{
                if(item){
                    item.dataValues.button = 'Follow'
                }
                else if(item.id === req.AuthUser.id){
                    item.dataValues.button = ''
                }
                else{
                    item.dataValues.button = 'Unfollow'
                }
            })
            

            return await Helper.successResponseWithData(res, 'user_fetched', "User has been fetched successfully", filterUser);
        } catch (error) {
            console.log("_________________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'server_error', error.message)
        }
    },
    /**
       * Function to send notification to updateUserCallStatus
     * Developer : Anshuman
       * @param {*id} req 
       * @param {*} res 
       */
    profileCategoryByUser: async (req, res) => {
        try {
            let data = req.body;
            if (!data.user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', "User id is required")
            }

            let categoryResult = await UserCategory.findAll({ where: { user_id: data.user_id } });
            return await Helper.successResponseWithData(res, 'user_category_retrieved', "user category retrieved successfully", categoryResult)

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    showGift: async (req, res) => {
        try {
            let data = req.body;
            // await gift.create({
            //     title: "gitar", 
            //     image: "https://upload.wikimedia.org/wikipedia/commons/archive/e/ea/20230626033311%21Test.gif ", 
            //     coin: "2", 
            //     type: "gift",
            //     sound: "gift", 
            //     icon: "", 
            //     position: "", 
            //     featured: "", 
                
            // })
            let giftData = await gift.findAll()
            let balance = await User.findOne({where:{id:req.AuthUser.id}}) 

            let checkSendGift = await send_gift.findAll({where:{sender_id:req.AuthUser.id}})
            let sum = 0 
            // Extract coin values and sum them up
            if(checkSendGift.length >0){
            sum = checkSendGift.reduce((accumulator, currentGift) => {
                return accumulator + parseInt(currentGift.coin);
            }, 0);
        }


            res.send({
                status: true,
                code: "gift_retrieved",
                message: "gift retrieved successfully",
                balance:balance.like_points + balance.comments_points + balance.uploadPost_points +balance.referral_points -sum,
                data:giftData
            })
           

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    sendGift: async (req, res) => {
        try {

            // Parse request body
            const { sender_id, receiver_id, gift_id, gift_count } = req.body;

            // Fetch gift details
            const gift_details = await gift.findOne({where:{id:gift_id}})

            if (!gift_details) {
                return await Helper.ErrorResponse(res, 'gift_id_req', "Invalid gift ID")
            }

            
            // Calculate gift data
            const gift_data = {
                image: gift_details.image,
                coin: gift_details.coin * gift_count,
                gift_id: gift_details.id,
                title: gift_details.title,
                sender_id,
                receiver_id
            };

            // Fetch sender and receiver details
            const sender_details = await User.findOne({where:{id:sender_id}})
            const receiver_details = await User.findOne({where:{id:receiver_id}})

            if (!sender_details || !receiver_details) {
                return await Helper.ErrorResponse(res, 'id_req', "Invalid sender or receiver ID")
            }

            // Check sender's total coins
            
            if (sender_details.like_points + sender_details.comments_points + sender_details.uploadPost_points < gift_details.coin ) {
                // return res.status(400).json({ code: 400, msg: 'You do not have enough coins to send gift' });
                return await Helper.ErrorResponse(res, 'low_bal', "You do not have enough coins to send gift")
            }

            // Save gift data
            let finalData = await send_gift.create(gift_data);

            // Send push notification to receiver
            // await Helper.sendPushNotification2(req, receiver_id, process.env.APP_NAME, 'You have received a gift');
            // const sendPushNotification2 = {
            //     to: receiver_details.device_token,
            //     notification: {
            //         title: 'You have received a gift',
            //         body: `${gift_details.title} worth ${gift_data.coin} coins`,
            //         user_id: sender_details.id,
            //         image: sender_details.profile_pic,
            //         name: sender_details.username,
            //         badge: '1',
            //         sound: 'default',
            //         icon: '',
            //         type: 'gift'
            //     },
            //     data: {
            //         title: 'You have received a gift',
            //         name: sender_details.username,
            //         body: `${gift_details.title} worth ${gift_data.coin} coins`,
            //         icon: '',
            //         badge: '1',
            //         sound: 'default',
            //         type: 'gift',
            //         user_id: sender_details.id,
            //         image: sender_details.profile_pic
            //     }
            // };


            // Update sender's wallet
            sender_details.wallet =  sender_details.like_points + sender_details.comments_points + sender_details.uploadPost_points -gift_details.coin
            

            return await Helper.successResponseWithData(res, 'user_category_retrieved', "user category retrieved successfully",{user:sender_details})

        } catch (error) {
            console.log(error)
            return await Helper.ErrorResponse(res, 'server_error', "Internal server error")
        }
    },

    chatList: async (req, res) => {
        try {
            let data = req.body;
            let chatList
            let filteredUsers = [];

            for (let i = 0; i < data.users.length; i++) {
                
                // let blockedUser = await BlockUser.findOne({
                //     where: {
                //         user_id: req.AuthUser.id,
                //         block_user_id: data.users[i].id,
                //         status: false
                //     }
                // });

                // if (!blockedUser) {
                //     filteredUsers.push(data.users[i]);
                // }
                console.log("--------------",req.AuthUser.id)

                const blockedByCurrentUser = await BlockUser.findOne({
                    where: {
                        user_id: data.users[i].id,
                        block_user_id: req.AuthUser.id,
                        status: false
                    }
                });
            
                // Check if the current user has blocked the user in the loop
                const blockedByLoopUser = await BlockUser.findOne({
                    where: {
                        user_id: req.AuthUser.id,
                        block_user_id: data.users[i].id,
                        status: false
                    }
                });
            
                // If neither user has blocked each other, add to filteredUsers
                if (!blockedByCurrentUser && !blockedByLoopUser) {
                    filteredUsers.push(data.users[i]);
                }
            }
            
            return await Helper.successResponseWithData(res, 'chat_users', "chat_users list fetched successfully",filteredUsers)



        } catch (error) {
            console.log("_______________________Error is here", error)
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },




}
module.exports = UserController;
