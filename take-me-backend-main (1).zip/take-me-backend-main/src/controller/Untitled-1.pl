
for singup api :

* login_type : 1  //google login

    requestPayload :{
        email : required,
        social_id: required
    }

* login_type : 2  //apple login

    requestPayload :{
        email : required,
        social_id: required
    }

* login_type : 3  //facebook login

    requestPayload :{
        email : required,
        social_id: required
    }

* login_type : 4  //phone login

    requestPayload :{
        phone : required,
        social_id: required
    }

* login_type : 5  //manual login

    requestPayload :{
        email : required,
    }

other common parameters
    {
        gender: required,
        dob: required,
        firstname: required,
        last_name: required,
        phone: required,
    }



