const { Validator } = require("node-input-validator");
const db = require('../../models');
const { Product, Notification } = db;
const Cryptr = require("cryptr");
const { STATUSCODE, SUCCESSMESSAGE, CUSTOM_MESSAGE } = require('../utils/constant')
const Helper = require("../utils/helper");
const moment = require('moment');

require("dotenv").config();

var NotificationController = {
    saveNotification: async (req, res) => {
        try {
            let data = req.body;
            let user_id = req.AuthUser.id
            let insertObject = {};

            if (!data.sender_id) {
                return await Helper.ErrorResponse(res, 'sender_id_error', 'Sender id is required.')
            }
            if (!data.receiver_id) {
                return await Helper.ErrorResponse(res, 'receiver_id_error', 'Receiver id is required.')
            }
            if (!data.string) {
                return await Helper.ErrorResponse(res, 'notification_title_error', 'Notification title is required.')
            }

            insertObject = {
                title: data.title,
                sender_id: user_id,
                receiver_id: data.title,
            }
            data.type ? insertObject.type = data.type : null;
            data.video_id ? insertObject.video_id = data.video_id : null;
            data.live_streaming_id ? insertObject.live_streaming_id = data.live_streaming_id : null;
            data.room_id ? insertObject.room_id = data.room_id : null;
            data.read ? insertObject.read = data.read : null;

            let noftications = await Notification.create(insertObject);
            if (!noftications) {
                return await Helper.ErrorResponse(res, 'notification_add_error', 'Notification could not be added');
            }

            return await Helper.successResponseWithData(res, 'notification_add_success', 'Notification added successfully', noftications);

        } catch (error) {

            return await Helper.ErrorResponse(res, 'internal_server_error', error.message)
        }
    }
}


module.exports = NotificationController;



