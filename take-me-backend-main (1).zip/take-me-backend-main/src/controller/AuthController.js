require("dotenv").config();
const { Validator } = require("node-input-validator");
const db = require('../../models');
const { User, UserLang, UserVerification,PostFavourite, UserCategory, Category, PostComment,Language, ReportUser, BlockUser, Follower, PostLike, Post,Sound, 
    HashTag, UserRefferal,PushNotification ,HashTagPost,NotificationMessages,SoundFavourite,send_gift} = db;
const Cryptr = require("cryptr");
const { STATUSCODE, SUCCESSMESSAGE, CUSTOM_MESSAGE } = require('../utils/constant')
const Helper = require("../utils/helper");
const moment = require('moment');
const { where, Op } = require("sequelize");
const { followUser } = require("./UserController");

var AuthController = {

    /**
   * Developer => Anshuman
   * Function to sentOtp to the user from the system
   * 
   */
    sentOtp: async (req, res) => {
        try {
            let data = req.body;
            if (!data.email) { return await Helper.ErrorResponse(res, "email_req", "Please enter the email") }
            if (data.email.length < 20 && typeof data.email != 'string') { return await Helper.ErrorResponse(res, "email_valid", "Please enter the valid email") }
            // let checkUser = await User.findOne({
            //     attributes: ['id', 'is_block', 'email', 'is_deleted', 'role'],
            //     where: { email: data.email?.toLowerCase() }
            // });
            // if (checkUser?.is_block) { return await Helper.ErrorResponse(res, 'user_block', 'user is blocked By Admin') }
            // if (checkUser?.role !== 1) { return await Helper.ErrorResponse(res, 'user_not_found', 'user not found') }
            //soft delete case would be run

            // let checkEmail = User.findOne({ where: { email: data.email } })

            // if (checkEmail && Object.keys(checkEmail)?.length < 1) {
            //     return await Helper.ErrorResponse(res, 'user_not_exist', 'This user is not registered')
            // }
            //generate otp process is here
            // let cryptr = new Cryptr(process.env.CRYPTR_SECRET);
            // const encryptedOtp = cryptr.encrypt(otp);
            let generateotp = Math.floor(1000 + Math.random() * 9000);
            let obj = {
                //otp: await Helper.createRandom(),
                otp: generateotp,
                email: data.email,
                expired_at: moment().format('YYYY-MM-DD HH:mm:ss'),
                // updated_at: new Date()
            }


            let content = `<b>Dear, </b><br>Thank you for choosing Take Me App. We're excited to have you onboard!.</b><br> To complete your registration/authentication process, please use the following One-Time Password (OTP):  ${obj.otp}  </b> <br><br> If you haven't requested this OTP, please ignore this email.
            <br><br> Thank you for your cooperation.<br> Best regards,'`;

            let format = await Helper.emailBody(data.email, 'OTP Verification for Take Me App', content)

            let mail = await Helper.sendMail(format)

            
            // let keyStack = { id : checkUser?.id };
            let checkIfOtpExists = await UserVerification.findOne({
                where: { email: data.email },
                order: [
                    ['createdAt', 'DESC']]
            })

            if (checkIfOtpExists != null && Object.keys(checkIfOtpExists)?.length > 0) {
                checkIfOtpExists.set(obj);
                if (await checkIfOtpExists.save()) {
                    return await Helper.SuccessResponse(res, 'otp_sent', 'Otp sent. It will be valid for 10 mins');
                }
            } else {
                let userV = await UserVerification.create(obj);
                return await Helper.SuccessResponse(res, 'otp_sent', 'Otp sent. It will be valid for 10 mins');
            }


        } catch (error) {
            console.log("_______________________Error is here", error)
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },
    /**
    * Developer => Anshuman
    * Function to auto login user in the system
    * 
    */
    signUp: async (req, res) => {
        /**
         * Login api
         *  1 => socialite google,
         *  2 => socialite apple,
         *  3 => facebook login, 
         *  4 => manual login
         * if  device_type = 1 => android, 2 => ios
         */
        try {
            let user;
            let schema;
            let validationMessages;
            let data = req.body;
            
            if (data.login_type == 1) {

                if (!data?.social_id && !data?.social) {
                    return await Helper.ErrorResponse(res, 'social_error_101', 'Please enter social type and social_id for google')
                }

                // check if user exist with the given social id
                let checkSocialId = await User.findOne({ where: { social_id: data?.social_id, social: "1", role: 1 } });
                if (checkSocialId) {
                    let token = await Helper.generateToken({ email: req.body.email, id: checkSocialId.id }, process.env.JWT_SECRET, { expiresIn: '30d' })




                    let fetchUserByGoogle = await User.findOne({
                        attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],

                        // include: [{
                        //     model: UserCategory,
                        //     as: 'usercategories',
                        //     required: false,
                        //     raw: true,
                        //     where: { user_id: checkSocialId.id },
                        //     include: [{
                        //         model: Category,
                        //         as: 'userCategories',
                        //         required: false,
                        //     }]
                        // }, {
                        //     model: UserLang,
                        //     as: 'userlangs',
                        //     required: false,
                        //     where: { user_id: checkSocialId.id },
                        //     include: [{
                        //         model: Language,
                        //         as: 'languages',
                        //         required: false,
                        //     }]
                        // }],
                        where: {
                            id: checkSocialId.id,
                            social: "1"
                        },
                    });



                    fetchUserByGoogle.dataValues.accessToken = token;
                    return await Helper.successResponseWithData(res, 'social_login_success', 'google login has been successfully', fetchUserByGoogle)
                    // return res.json({ status: true, user: checkSocialId, message: '' })
                } else {
                    let googleobj = {
                        social: "1",//req.body.social?.toLowerCase(),
                        social_id: req.body.social_id?.toLowerCase(),
                        role: 1
                    }
                    if (req.body.email) {
                        googleobj.email = req.body.email?.toLowerCase()
                    }
                    // creating new user
                    let newUser = await User.create(googleobj);

                    let lang_user_id = newUser.id;

                    if (data.language) {

                        //check language is availabe or not
                        let checkLanguageExists = await Language.findAll({
                            where: { id: { [Op.in]: await data.language.map(val => { return val.language_id }) } }
                        });
                        if (!checkLanguageExists.length > 0) {
                            return await Helper.ErrorResponse(res, 'lang_not_found', 'language not found')
                        }
                        //end of initimat for language


                        if (req.body.language?.length > 0) {
                            // insert language into table user_lang
                            await data.language?.forEach(async (lang) => {
                                await UserLang.create({ user_id: lang_user_id, language_id: lang?.language_id });
                            });
                        }
                    }

                    if (data?.category) {

                        //check category is availabe or not
                        let checkCategoryExists = await Category.findAll({
                            where: { id: { [Op.in]: await data.category.map(val => { return val.category_id }) } }
                        });
                        if (!checkCategoryExists.length > 0) {
                            return await Helper.ErrorResponse(res, 'category_not_found', 'category not found')
                        }
                        //end of initimat for category

                        if (data?.category?.length > 0) {

                            // insert language into table user_lang
                            await data.category?.forEach(async (cat) => {
                                await UserCategory.create({ user_id: lang_user_id, category_id: cat.category_id });
                            });


                        }
                    }

                    if (newUser) {

                        await User.findOne({
                            attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],
                            where: { id: newUser.id }
                        });
                        let token = await Helper.generateToken({ email: req.body.email, id: newUser.id }, process.env.JWT_SECRET, { expiresIn: '30d' })


                        newUser.dataValues.accessToken = token;
                    }




                    return await Helper.successResponseWithData(res, 'google_login_success', 'google has been registered successfully', newUser)
                }


            }
            else if (data.login_type == 2) {


                if (!data.social_id && !data.social) {
                    return await Helper.ErrorResponse(res, 'social_error_101', 'Please enter social type and social_id for apple')
                }

                let checkSocialId = await User.findOne({
                    attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],
                    where: {
                        social_id: data.social_id,
                        social: "2",
                        role: 1
                    }
                });
                if (checkSocialId) {
                    let token = await Helper.generateToken({ email: data.email, id: checkSocialId.id }, process.env.JWT_SECRET, { expiresIn: '30d' })

                    checkSocialId.dataValues.accessToken = token;

                    return await Helper.successResponseWithData(res, 'apple_login_success', 'apple has been registered successfully', checkSocialId)

                } else {
                    let appleObject = {
                        social: "2",// data.social?.toLowerCase(),
                        social_id: data.social_id?.toLowerCase(),
                        role: 1
                    }
                    // if email exit
                    if (data.email) {
                        appleObject.email = data.email?.toLowerCase()
                    }

                    let newUser = await User.create(appleObject);


                    let lang_user_id = newUser.id;

                    if (data.language) {

                        //check language is availabe or not
                        let checkLanguageExists = await Language.findAll({
                            where: { id: { [Op.in]: await data.language.map(val => { return val.language_id }) } }
                        });
                        if (!checkLanguageExists.length > 0) {
                            return await Helper.ErrorResponse(res, 'lang_not_found', 'language not found')
                        }
                        //end of initimat for language


                        if (data.language?.length > 0) {
                            // insert language into table user_lang
                            await data.language?.forEach(async (lang) => {
                                await UserLang.create({ user_id: lang_user_id, language_id: lang?.language_id });
                            });


                        }
                    }

                    if (data?.category) {

                        //check category is availabe or not
                        let checkCategoryExists = await Category.findAll({
                            where: { id: { [Op.in]: await data.category.map(val => { return val.category_id }) } }
                        });
                        if (!checkCategoryExists.length > 0) {
                            return await Helper.ErrorResponse(res, 'category_not_found', 'category not found')
                        }
                        //end of initimat for category

                        if (data?.category?.length > 0) {

                            // insert language into table user_lang
                            await data.category?.forEach(async (cat) => {
                                await UserCategory.create({ user_id: lang_user_id, category_id: cat.category_id });
                            });


                        }
                    }

                    if (newUser) {

                        newUser = await User.findOne({
                            attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],
                            where: { id: newUser.id }
                        });
                        let token = await Helper.generateToken({ email: data.email, id: newUser.id }, process.env.JWT_SECRET, { expiresIn: '30d' })

                        newUser.dataValues.accessToken = token;
                    }

                    return await Helper.successResponseWithData(res, 'apple_register_success', 'apple has been registered successfully', newUser)


                }
                // return res.json({ status: true, message: "login type apple", data: data })
            }
            else if (data.login_type == 3) {


                if (!data.social_id && !data.social) {
                    return await Helper.ErrorResponse(res, 'social_error_101', 'Please enter social type and social_id for facebook')
                }

                let checkSocialId = await User.findOne({

                    attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],
                    where: {
                        social_id: data.social_id,
                        social: "3",
                        role: 1
                    }

                });
                if (checkSocialId) {
                    let token = await Helper.generateToken({ email: data.email, id: checkSocialId.id }, process.env.JWT_SECRET, { expiresIn: '30d' })

                    checkSocialId.dataValues.accessToken = token;

                    return await Helper.successResponseWithData(res, 'facebook_login_success', 'facebook login  has been successfully', checkSocialId)

                } else {
                    let facebookObject = {
                        social: "3",//data.social?.toLowerCase(),
                        social_id: data.social_id?.toLowerCase(),
                        role: 1
                    }
                    // if email exit
                    if (data.email) {
                        facebookObject.email = data.email?.toLowerCase()
                    }

                    let newUser = await User.create(facebookObject);

                    let lang_user_id = newUser.id;

                    if (data.language) {

                        //check language is availabe or not
                        let checkLanguageExists = await Language.findAll({
                            where: { id: { [Op.in]: await data.language.map(val => { return val.language_id }) } }
                        });
                        if (!checkLanguageExists.length > 0) {
                            return await Helper.ErrorResponse(res, 'lang_not_found', 'language not found')
                        }
                        //end of initimat for language


                        if (data.language?.length > 0) {
                            // insert language into table user_lang
                            await data.language?.forEach(async (lang) => {
                                await UserLang.create({ user_id: lang_user_id, language_id: lang?.language_id });
                            });


                        }
                    }

                    if (data?.category) {

                        //check category is availabe or not
                        let checkCategoryExists = await Category.findAll({
                            where: { id: { [Op.in]: await data.category.map(val => { return val.category_id }) } }
                        });
                        if (!checkCategoryExists.length > 0) {
                            return await Helper.ErrorResponse(res, 'category_not_found', 'category not found')
                        }
                        //end of initimat for category

                        if (data?.category?.length > 0) {

                            // insert language into table user_lang
                            await data.category?.forEach(async (cat) => {
                                await UserCategory.create({ user_id: lang_user_id, category_id: cat.category_id });
                            });


                        }
                    }

                    if (newUser) {
                        newUser = await User.findOne({
                            attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],
                            where: { id: newUser.id }
                        });

                        let token = await Helper.generateToken({ email: data.email, id: newUser.id }, process.env.JWT_SECRET, { expiresIn: '30d' })

                        newUser.dataValues.accessToken = token;
                    }

                    return res.json({ status: true, user: newUser, message: 'facebook has been registered successfully' })
                }
                // return res.json({ status: true, message: "login type apple", data: data })
            }

            else if (data.login_type == 4) {


                if (!data.phone) {
                    return await Helper.ErrorResponse(res, 'phone_error_101', 'Please enter a valid phone number')
                }

                let checkSocialId = await User.findOne({
                    attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],
                    where: { phone: data.phone, role: 1 }
                });
                if (checkSocialId) {
                    let token = await Helper.generateToken({ phone: data.phone, id: checkSocialId.id }, process.env.JWT_SECRET, { expiresIn: '30d' })

                    checkSocialId.dataValues.accessToken = token;

                    return await Helper.successResponseWithData(res, 'phone_login_success', 'Phone number login  successful', checkSocialId)

                } else {
                    let phoneObject = {
                        phone: data.phone,
                        role: 1
                    }
                    // if email exit
                    if (data.email) {
                        phoneObject.email = data.email?.toLowerCase()
                    }

                    let existUnique = await User.findAll({ where: { phone: data.phone } });
                    if (existUnique.length > 0) {
                        return await Helper.ErrorResponse(res, 'phone_unique_error_103', 'Phone number should be unique. Please try again with another Phone');
                    }


                    let newUser = await User.create(phoneObject);

                    let lang_user_id = newUser.id;

                    if (data.language.length > 0) {

                        //check language is availabe or not
                        let checkLanguageExists = await Language.findAll({
                            where: { id: { [Op.in]: await data.language.map(val => { return val.language_id }) } }
                        });
                        if (!checkLanguageExists.length > 0) {
                            return await Helper.ErrorResponse(res, 'lang_not_found', 'language not found')
                        }
                        //end of initimat for language

                        if (data.language?.length > 0) {
                            // insert language into table user_lang
                            await data.language?.forEach(async (lang) => {
                                await UserLang.create({ user_id: lang_user_id, language_id: lang?.language_id });
                            });


                        }
                    }

                    if (data?.category) {

                        //check category is availabe or not
                        let checkCategoryExists = await Category.findAll({
                            where: { id: { [Op.in]: await data.category.map(val => { return val.category_id }) } }
                        });
                        if (!checkCategoryExists.length > 0) {
                            return await Helper.ErrorResponse(res, 'category_not_found', 'category not found')
                        }
                        //end of initimat for category

                        if (data?.category?.length > 0) {

                            // insert language into table user_lang
                            await data.category?.forEach(async (cat) => {
                                await UserCategory.create({ user_id: lang_user_id, category_id: cat.category_id });
                            });


                        }
                    }


                    if (newUser) {

                        newUser = await User.findOne({
                            attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],
                            where: { id: newUser.id }
                        })
                        let token = await Helper.generateToken({ phone: data.phone, id: newUser.id }, process.env.JWT_SECRET, { expiresIn: '30d' })

                        newUser.dataValues.accessToken = token;
                    }

                    return await Helper.successResponseWithData(res, 'phone_register_success', 'Phone has been registered successfully', newUser)
                }
                // return res.json({ status: true, message: "login type apple", data: data })
            }

            else if (data.login_type == 5) {

                if (!data.email && !data.firstname && !data.gender) {
                    return await Helper.ErrorResponse(res, 'login_error_102', 'Please enter the Email, firstname, and gender')
                }
                let { referral_code, firstname, lastname, username, email, device_token, device_type, mobile_no, gender } = data;

                
                
                let checkUser = await User.findOne({ where: { email: data.email?.toLowerCase() ,is_deleted:false} });
                console.log("check user",checkUser)
               if(checkUser !=null){
                let updateObj = {
                    device_token: data.device_token
                }

                checkUser.set(updateObj)
                checkUser.save()
            }


                if (checkUser && checkUser?.email && checkUser != "") {
                    let token = await Helper.generateToken({ email: checkUser?.email, id: checkUser.id }, process.env.JWT_SECRET, { expiresIn: '30d' })


                    let userWithLangAndCat = await User.findOne({
                        attributes: ['profile_pic', 'username', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code','referral_code','unique_id','refferer_id','device_token'],

                        // include: [{
                        //     model: UserCategory,
                        //     as: 'usercategories',
                        //     required: false,
                        //     where: { user_id: checkUser.id },
                        //     include: [{
                        //         model: Category,
                        //         as: 'userCategories',
                        //         required: false,
                        //     }]
                        // }, {
                        //     model: UserLang,
                        //     as: 'userlangs',
                        //     required: false,
                        //     where: { user_id: checkUser.id },
                        //     include: [{
                        //         model: Language,
                        //         as: 'languages',
                        //         required: false,
                        //     }]
                        // }],
                        where: {
                            id: checkUser.id
                        },
                    });

                    userWithLangAndCat.dataValues.accessToken = token;
    
                    let generateotp = Math.floor(1000 + Math.random() * 9000);
                    let obj = {
                        otp: generateotp,
                        email: data.email,
                        expired_at: moment().format('YYYY-MM-DD HH:mm:ss'),
                        // updated_at: new Date()
                    }
                   

                    // let content = `<b>Hey there! </b><br> Please enter this code in your Reel Star app to complete the verification process. Do not share this code with anyone else.<br><b> otp :  ${obj.otp}  </b> <br><br> If you did not initiate this request, you may disregard this message. <br><br> Thank you<br> Reel Star Team'`;

                    // let format = await Helper.emailBody(data.email, 'New Registration', content)

                    // let mail = await Helper.sendMail(format)

                    let checkIfOtpExists = await UserVerification.findOne({
                        where: { email: data.email },
                        order: [
                            ['createdAt', 'DESC']]
                    })
                    let otpResponse = "";
                    if (checkIfOtpExists != null && Object.keys(checkIfOtpExists)?.length > 0) {
                        checkIfOtpExists.set(obj);
                        if (await checkIfOtpExists.save()) {
                            otpResponse = 1;
                        }
                    } else {
                        let userV = await UserVerification.create(obj);
                        otpResponse = 1;
                    }
                    
console.log("login response-------------------------------",userWithLangAndCat)
                    return await Helper.successResponseWithData(res, "login_success", "Login has been successfully", userWithLangAndCat);

                } else {

                    let existUnique = await User.findAll({ where: { email: data.email } });
                    if (existUnique.length > 0) {
                        return await Helper.ErrorResponse(res, 'email_unique_103', 'Email should be unique. Please try again with another email');
                    }
console.log("chek data during signupp",data)

                    //send otp hit the api
                    //let data = req.body;
                    if (!data.email) { return await Helper.ErrorResponse(res, "email_req", "Please enter the email") }
                    if (data.email.length < 20 && typeof data.email != 'string') { return await Helper.ErrorResponse(res, "email_valid", "Please enter the valid email") }
                    // let checkUser = await User.findOne({
                    //     attributes: ['id', 'is_block', 'email', 'is_deleted', 'role'],
                    //     where: { email: data.email?.toLowerCase() }
                    // });
                    // if (checkUser?.is_block) { return await Helper.ErrorResponse(res, 'user_block', 'user is blocked By Admin') }
                    // if (checkUser?.role !== 1) { return await Helper.ErrorResponse(res, 'user_not_found', 'user not found') }
                    //soft delete case would be run

                    // let checkEmail = User.findOne({ where: { email: data.email } })

                    // if (checkEmail && Object.keys(checkEmail)?.length < 1) {
                    //     return await Helper.ErrorResponse(res, 'user_not_exist', 'This user is not registered')
                    // }
                    //generate otp process is here
                    // let cryptr = new Cryptr(process.env.CRYPTR_SECRET);
                    // const encryptedOtp = cryptr.encrypt(otp);
                    let generateotp = Math.floor(1000 + Math.random() * 9000);
                    let obj = {
                        otp: generateotp,
                        email: data.email,
                        expired_at: moment().format('YYYY-MM-DD HH:mm:ss'),
                        // updated_at: new Date()
                    }
                   

                    // let content = `<b>Hey there! </b><br> Please enter this code in your Reel Star app to complete the verification process. Do not share this code with anyone else.<br><b> otp :  ${obj.otp}  </b> <br><br> If you did not initiate this request, you may disregard this message. <br><br> Thank you<br> Reel Star Team'`;

                    // let format = await Helper.emailBody(data.email, 'New Registration', content)

                    // let mail = await Helper.sendMail(format)


                    // let keyStack = { id : checkUser?.id };
                    let checkIfOtpExists = await UserVerification.findOne({
                        where: { email: data.email },
                        order: [
                            ['createdAt', 'DESC']]
                    })
                    let otpResponse = "";
                    if (checkIfOtpExists != null && Object.keys(checkIfOtpExists)?.length > 0) {
                        checkIfOtpExists.set(obj);
                        if (await checkIfOtpExists.save()) {
                            otpResponse = 1;
                        }
                    } else {
                        let userV = await UserVerification.create(obj);
                        otpResponse = 1;
                    }

                    let userWithReferralCode;
                    if(referral_code){
                         userWithReferralCode = await User.findOne({
                            where: { referral_code: String(referral_code) }
                        });
                    
                        // update referral_id
                        if (userWithReferralCode) {
                            data.refferer_id = userWithReferralCode.dataValues.id
                         
                        } else {
                            return await Helper.ErrorResponse(res, 'Incorrect Referral_code', 'Invalid referral code');
                            // Throw an error or handle the situation appropriately
                        }
                    }

                    // Creating user if email is new
                    if (otpResponse == 1) {
                        let obj = {
                            email: data.email?.toLowerCase(),
                            gender: data.gender?.toLowerCase(),
                            dob: moment(data?.dob).format('YYYY-MM-DD'),
                            firstname: data.firstname?.toLowerCase(),
                            last_name: data.last_name?.toLowerCase(),
                            role: 1,
                            phone: data.phone,
                            refferer_id :data.refferer_id 

                        }
                       let Datee = new Date().getTime();
                       let randUser  = await Helper.createRandom('', 5);
                       data.email ? obj.username = data?.email?.toLowerCase().split("@")[0] + randUser : randUser;
                        // data.email ? obj.username = data?.email?.toLowerCase().split("@")[0] + Datee : null;

                        let checkUsername = await User.findOne({ where: { username: obj.username?.toLowerCase() ,is_deleted:false} });
                        // console.log('checkUsername==========',checkUsername)
                        if(checkUsername != null){
                            let randUser  = await Helper.createRandom('', 5);
                            data.email ? obj.username = data?.email?.toLowerCase().split("@")[0] + randUser : randUser;
                        }

                        data.device_token ? obj.device_token = data.device_token : null;
                        data.device_type ? obj.device = data.device_type : null;
                        data.profile_pic ? obj.profile_pic = data.profile_pic?.toLowerCase() : null;
                        data.refferer_id ? obj.refferer_id = data.refferer_id : null;

                        let user = await User.create(obj);
                        console.log("check user--------------------------------------",user)
                        let user_id = user.id;
                        if (user) {
                            user = await User.findOne({
                                attributes: ['profile_pic','username', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code','referral_code','refferer_id','unique_id'],
                                where: { id: user.id }
                            });

                            // generating token
                            let token = await Helper.generateToken({ email: data.email, id: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' })
                            user.dataValues.accessToken = token;



                            // First, we start a transaction from your connection and save it into a variable

                            let lang_user_id = user.id;


                            if (data.language) {
                                if (data.language?.length > 0) {

                                    //check language is availabe or not
                                    let checkLanguageExists = await Language.findAll({
                                        where: { id: { [Op.in]: await JSON.parse(data.language).map(val => { return val.language_id }) } }
                                    });
                                    if (!checkLanguageExists.length > 0) {
                                        return await Helper.ErrorResponse(res, 'lang_not_found', 'language not found')
                                    }
                                    //end of initimat for language


                                    // const t = await db.sequelize.transaction();
                                    // try {

                                    // insert language into table user_lang
                                    await JSON.parse(data.language).forEach(async (lang) => {
                                        await UserLang.create({ user_id: lang_user_id, language_id: lang?.language_id });
                                    });

                                    // We commit the transaction.
                                    //     await t.commit();

                                    // } catch (error) {

                                    //     // We rollback the transaction.
                                    //     await t.rollback();
                                    //     return Helper.ErrorResponse(res, 'could not save save the languages')

                                    // }
                                }
                            }

                            if (data?.category.length > 0) {

                                //check category is availabe or not
                                let checkCategoryExists = await Category.findAll({
                                    where: { id: { [Op.in]: await JSON.parse(data.category).map(val => { return val.category_id }) } }
                                });
                                if (!checkCategoryExists.length > 0) {
                                    return await Helper.ErrorResponse(res, 'category_not_found', 'category not found')
                                }
                                //end of initimat for category

                                if (data.category.length > 0) {
                                    //check category is availabe or not
                                    let checkCategoryExists = await Category.findAll({
                                        where: { id: { [Op.in]: await JSON.parse(data.category).map(val => { return val.category_id }) } }
                                    });
                                    if (!checkCategoryExists.length > 0) {
                                        return await Helper.ErrorResponse(res, 'category_not_found', 'category not found')
                                    }
                                    //end of initimat for category

                                    // const s = await db.sequelize.transaction();
                                    // try {

                                    // insert language into table user_lang
                                    await JSON.parse(data.category).forEach(async (cat) => {
                                        await UserCategory.create({ user_id: lang_user_id, category_id: cat.category_id });
                                    });

                                    // We commit the transaction.
                                    //     await s.commit();

                                    // } catch (error) {

                                    //     // We rollback the transaction.
                                    //     await s.rollback();
                                    //     return Helper.ErrorResponse(res, 'could not save save the category')

                                    // }
                                }
                            }
                            // let userWithLangAndCat = await User.findOne({
                            //     include:[
                            //         {
                            //             model:Language,
                            //             as:'languages',
                            //             required: false,
                            //             seperate:true
                            //         },
                            //         {
                            //             model:Category,
                            //             as:'category',
                            //             required: false,
                            //         },
                            //     ],
                            //     where:{
                            //         id:user.id
                            //     },
                            // });

                           
console.log("Signup reposne------------------------------------------------------------",user)

                            return await Helper.successResponseWithData(res, "user_registered", 'registerd has been successfully', user);
                        }
                    }
                    return res.json({ status: true, data: { id: user?.id }, message: SUCCESSMESSAGE.REGISTRATION_SUCCESS })
                }
            
            } else {
                return await Helper.ErrorResponse(res, "type_not_acceptable", "login type not acceptable")
            }

        } catch (error) {
            console.log("_______________________Error is here", error);
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },

    verifyChangeEmailCode: async (req, res) => {
        try {
            let data = req.body
            if(!data.new_email){return await Helper.ErrorResponse(res, 'email_req', 'Email is required.')}
            if(!data.user_id){return await Helper.ErrorResponse(res, 'user_id_req', 'User Id is required.')}
            if(!data.verify){return await Helper.ErrorResponse(res, 'verify_req', 'Verify is required.')}

            let verificationData = await UserVerification.findOne({
                where: { email: data.new_email },
                order: [
                    ['createdAt', 'DESC']
                ]
            })
            
            if (verificationData) {
                let vDate = moment().diff(moment(verificationData.expired_at), 'minutes');

                if (vDate > 10) {
                    return await Helper.ErrorResponse(res, 'otp_expired', 'Otp has been expired.')
                }
                else if (verificationData.otp == data.verify ) {
                    await User.update({email:data.new_email},{where:{id:data.user_id}})
                    let userDetail = await User.findOne({where:{id:data.user_id}})
                    return await Helper.successResponseWithData(res, 200, 'User details has been fetched successfully', userDetail)
                }
                else {
                    return await Helper.ErrorResponse(res, 'wrong_otp', 'Wrong otp provided')
                }
            } else {
                return await Helper.ErrorResponse(res, 'otp_not_found', 'Otp not found')
            }

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)

        }
        // res.send("Get user profile")
    },


    /**
    * Developer => Anshuman
    * Function to logout user from the system
    * 
    */
    getUserAuthProfile: async (req, res) => {
        try {
            let user_id = req.AuthUser.id;

            let userDetails = await User.findOne({ where: { id: user_id } });
            let private = false

            let checkSendGift = await send_gift.findAll({where:{sender_id:req.AuthUser.id}})
            // Extract coin values and sum them up
            const sum = checkSendGift.reduce((accumulator, currentGift) => {
                return accumulator + parseInt(currentGift.coin);
            }, 0);

            let checkReceiveGift = await send_gift.findAll({where:{receiver_id:req.AuthUser.id}})
            // Extract coin values and sum them up
            const receive = checkReceiveGift.reduce((accumulator, currentGift) => {
                return accumulator + parseInt(currentGift.coin);
            }, 0);

            let followers = await Follower.findAll({ where: { receiver_id: user_id } });
            let followings = await Follower.findAll({ where: { sender_id: user_id } });
            let posts = await Post.findAll({ where: { user_id: user_id,status:true } });
            let likes = await PostLike.findAll({ where: { user_id: user_id } });
            let unique_id = await User.findOne({attributes: ['unique_id'],where:{id :user_id}})
            userDetails.dataValues.unique_id = unique_id.dataValues.unique_id
            userDetails.dataValues.private = private ? '1' : '0'
            
            userDetails.dataValues.wallet = userDetails.like_points + userDetails.comments_points +userDetails.uploadPost_points +userDetails.referral_points + receive - sum || 0
        
            for(let key in userDetails.dataValues){
                if(userDetails.dataValues[key] ===null){
                    userDetails.dataValues[key]=""
                }
            }

            let reponsePayload = {
                followers_count: followers?.length,
                following_count: followings?.length,
                likes_count: likes?.length,
                video_count: posts?.length,
                userDetails: userDetails
            }
            if (userDetails) {
                return await Helper.successResponseWithData(res, 'data_retrieved', 'Auth details has been fetched successfully', reponsePayload)
            } else {
                return await Helper.ErrorResponse(res, 'data_retrieved', 'User not found')
            }
        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)

        }
        // res.send("Get user profile")
    },
    /**
    * Developer => Anshuman
    * Function to get Profile By UserId
    * 
    */
    getProfileByUserId: async (req, res) => {
        try {
            let user_id = req.body.user_id;
            if (!user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User Id is required.');
            }

            let checkIfUserExist = await User.findOne({ where: { id: user_id } });
            
            if (!checkIfUserExist) {
                return await Helper.ErrorResponse(res, 'user_not_found', 'User is not found.');
            }

            let followers = await Follower.findAll({ where: { receiver_id: user_id } });
            let followings = await Follower.findAll({ where: { sender_id: user_id } });
            let posts = await Post.findAll({ where: { user_id: user_id } });
            let likes = await PostLike.findAll({ where: { user_id: user_id } });

            let checkFollow = await Follower.findAll({ where: { sender_id: req.AuthUser.id,receiver_id :user_id } });

            if(checkFollow.length!==0){
                 checkIfUserExist.dataValues.button = 'following'
            }
            else{
                checkIfUserExist.dataValues.button = 'follow'
            }

            let reponsePayload = {
                followers_count: followers?.length,
                following_count: followings?.length,
                likes_count: likes?.length,
                video_count: posts?.length,
                userDetails: checkIfUserExist
            }
            if (checkIfUserExist) {
                return await Helper.successResponseWithData(res, 'data_retrieved', 'User details has been fetched successfully', reponsePayload)
            } else {
                return await Helper.ErrorResponse(res, 'data_retrieved', 'User not found')
            }
        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)

        }
        // res.send("Get user profile")
    },

    showUserDetail: async (req, res) => {
        try {
            let user_id = req.body.user_id;
            if (!user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User Id is required.');
            }

            let checkIfUserExist = await User.findOne({ where: { id: user_id } });
            
            for (let key in checkIfUserExist.dataValues) {
                if (checkIfUserExist.dataValues[key] === null) {
                    checkIfUserExist.dataValues[key] = '';
                }
            }
            
            if (!checkIfUserExist) {
                return await Helper.ErrorResponse(res, 'user_not_found', 'User is not found.');
            }
            
            let totalLikesCount = 0;
            let followers = await Follower.findAll({ where: { receiver_id: user_id } });
            let followings = await Follower.findAll({ where: { sender_id: user_id } });
            let posts = await Post.findAll({ where: { user_id: user_id ,status:true} });
            for(let i=0; i<posts.length; i++){
                let likes = await PostLike.findAll({ where: {post_id: posts[i].dataValues.id } });
                totalLikesCount += likes?.length;
            }
           
           let checkuserButton = await Follower.findAll({ where: { sender_id:req.AuthUser.id,receiver_id: user_id} });
           let authButton = await Follower.findAll({ where: { sender_id:user_id,receiver_id: req.AuthUser.id } });
           let checkBlockUser =  await BlockUser.findOne({where: {user_id: req.AuthUser.id,block_user_id:user_id}});
           console.log("=-=-=-=",checkBlockUser)
           let status ; 
           if(checkBlockUser != null){
            status = checkBlockUser.status
           }

            
            if(checkuserButton.length >0){
                 checkIfUserExist.dataValues.button = 'following'
            }
            else{
                checkIfUserExist.dataValues.button = 'follow'
            }

            if(authButton.length> 0){
                checkIfUserExist.dataValues.authButton = 'following'
            }
            else{
                checkIfUserExist.dataValues.authButton = 'follow'
            }

            checkIfUserExist.dataValues.followers_count =followers?.length
            checkIfUserExist.dataValues.following_count =followings?.length
            checkIfUserExist.dataValues.likes_count=totalLikesCount
            checkIfUserExist.dataValues.video_count =posts?.length
            checkIfUserExist.dataValues.profile_pic_small =""
            checkIfUserExist.dataValues.profile_gif = ""
            checkIfUserExist.dataValues.profile_video = ""
            checkIfUserExist.dataValues.token = ""
            checkIfUserExist.dataValues.state = ""
            checkIfUserExist.dataValues.region = ""
            checkIfUserExist.dataValues.location_string = ""
            checkIfUserExist.dataValues.country_id = "0"
            checkIfUserExist.dataValues.paypal = ""
            checkIfUserExist.dataValues.paypal = "0"
            checkIfUserExist.dataValues.profile_view = "1"
            checkIfUserExist.dataValues.reset_wallet_datetime = "0000-00-00 00:00:00"
            checkIfUserExist.dataValues.total_all_time_coins = 0
            checkIfUserExist.dataValues.profile_visit_count = 0
            checkIfUserExist.dataValues.unread_notification = 0
            checkIfUserExist.dataValues.story = []
            checkIfUserExist.dataValues.is_block = status == true ? 1 : 0

            let notifObj = {
                id: user_id,
                "likes": "1",
                "comments": "1",
                "new_followers": "1",
                "mentions": "1",
                "direct_messages": "1",
                "video_updates": "1"
            }
            // let pushNotification = await PushNotification.create(notifObj)

            let reponsePayload = {
                userDetails: checkIfUserExist,
                // PushNotification: {
                //     "id": "1",
                //     "likes": "1",
                //     "comments": "1",
                //     "new_followers": "1",
                //     "mentions": "1",
                //     "direct_messages": "1",
                //     "video_updates": "1"
                // },
                PushNotification:notifObj,
                PrivacySetting: {
                    "id": "1",
                    "videos_download": "1",
                    "direct_message": "everyone",
                    "duet": "everyone",
                    "liked_videos": "me",
                    "video_comment": "everyone"
                },
                Playlist: []
            }
            if (checkIfUserExist) {
                return await Helper.successResponseWithData(res, '200', 'User details has been fetched successfully', reponsePayload)
            } else {
                return await Helper.ErrorResponse(res, 'data_retrieved', 'User not found')
            }
        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)

        }
        // res.send("Get user profile")
    },

    chatNotification: async (req, res) => {
        try {
            let user_id = req.body.user_id;
            let msg = req.body.msg
           
            if (!user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User Id is required.');
            }

            let checkIfUserExist = await User.findOne({ where: { id: user_id } });
            
            if (!checkIfUserExist) {
                return await Helper.ErrorResponse(res, 'user_not_found', 'User is not found.');
            }
            
         
            let authUser = await User.findOne({where:{id:req.AuthUser.id}})
           console.log("authUser",authUser.dataValues.profile_pic)
           let name;
            
           if(authUser.dataValues.first_name){
               name = authUser.dataValues.first_name
           }
           else{
               name = authUser.dataValues.email
           }
            
            let reponsePayload = {
                user_id:req.AuthUser.id,
                user_pic:authUser.dataValues.profile_pic ? authUser.dataValues.profile_pic : "",
                type:"message",
                user_name: authUser.dataValues.first_name ? authUser.dataValues.first_name : authUser.dataValues.email,
                sender_id:req.AuthUser.id,
                receiver_id:user_id
            }

            if(checkIfUserExist){
                let pushNotfSettingDetail = await PushNotification.findOne({
                    where: {
                        id: user_id
                    }
                });
               
                if (pushNotfSettingDetail && pushNotfSettingDetail.direct_messages == 1){
                    var message = msg;
                    let payload = {
                        unique_id: req.AuthUser?.unique_id,
                        username: req.AuthUser.username,
                        user_id: req.AuthUser.id,
                        sender_id: req.AuthUser.id,
                        receiver_id: user_id,
                        video_id: '',
                        image: req.authUser?.profile_pic,
                        title: message,
                        type: 'chat_Notif',
                    }
                    await Helper.sendPushNotification2(req, user_id, process.env.APP_NAME, message, payload);
                    // await Helper.sendPushNotification2(req, user_id, ` ${name}`,msg,reponsePayload)
                    await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:user_id,message:msg,type:"chat_Notif"})
                }
                return await Helper.successResponseWithData(res, 'Chat Notification', 'Notification send successfully.')
            }
            else{
                return await Helper.ErrorResponse(res, 'data_retrieved', 'User not found')
            }

          
            // if (checkIfUserExist) {
            //     return await Helper.successResponseWithData(res, 'Chat Notification', 'Notification send successfully.')
            // } else {
            //     return await Helper.ErrorResponse(res, 'data_retrieved', 'User not found')
            // }
        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)

        }
        // res.send("Get user profile")
    },

    /**
    * Developer => Anshuman
    * Function to logout user from the system
    * 
    */
    updateUserDetail: async (req, res) => {
        try {
            let data = req.body;
            let user_id = req.AuthUser.id;

            /** Explicitely checking if user id is present in the request payload
             * This may be removed if validation is approved.
             *  */

            if (!user_id) {
                return await Helper.ErrorResponse(res, STATUSCODE.HTTP_SUCCESS, 'Validation error', 'Id is required to update the user');
            }
            /** */  // let data = await User.findAll();
            let v = await new Validator(data, {
                // id: "required",
                // first_name: "required",
                // last_name: "required",
                // gender: "required",
                // bio: "required",
                // dob: "required",
                // phone: "required",
                // phone_code: "required",

            }, { /** "first_name.required": customMessage.validationRule.FIRST_NAME, **/ }
            );

            let checks = await v.check();
            if (!checks) {
                // return await Helper.ErrorResponse(res, '', 'Validation error', [email, password, first_name, last_name, mobile_no])
                return await Helper.ErrorResponse(res, STATUSCODE.HTTP_SUCCESS, 'Validation error', v.errors)

            } else {

                let checkUserExistORNot = await User.findOne({

                    include: [{
                        model: UserCategory,
                        as: 'usercategories',
                        required: false,
                        where: { user_id: user_id },
                        include: [{
                            model: Category,
                            as: 'userCategories',
                            required: false,
                        }]
                    }, {
                        model: UserLang,
                        as: 'userlangs',
                        required: false,
                        where: { user_id: user_id },
                        include: [{
                            model: Language,
                            as: 'languages',
                            required: false,
                        }]
                    }],
                    where: {
                        id: user_id
                    }
                });

                if (!checkUserExistORNot?.id) {
                    return await Helper.ErrorResponse(res, STATUSCODE.HTTP_SUCCESS, CUSTOM_MESSAGE.USER_NOT_EXISTS)
                } else {

                    let updateObj = {
                        first_name: data.first_name,
                    }

                    if (data.last_name) {
                        updateObj.last_name = data.last_name
                    }
                    if (data.gender) {
                        updateObj.gender = data.gender
                    }
                    if (data.bio) {
                        updateObj.bio = data.bio
                    }
                    if (data.dob) {
                        updateObj.dob = data.dob
                    }
                    if (data.phone) {
                        updateObj.phone = data.phone
                    }
                    if (data.phone_code) {
                        updateObj.phone_code = data.phone_code
                    }
                    if (data.profile_pic) {
                        updateObj.profile_pic = data.profile_pic
                    }
                    if (data.website) {
                        updateObj.website = data.website
                    }

                    // Creating user if email is new
                    checkUserExistORNot.set(updateObj)
                   
                    if (await checkUserExistORNot.save()) {


                        let followers = await Follower.findAll({ where: { receiver_id: user_id } });

                        let followings = await Follower.findAll({ where: { sender_id: user_id } });

                        if(data.profile_pic){
                            console.log("check ",followers.length)
                            followers.map(async(id)=> {
                                var message = `${req.AuthUser.username} has updated his profile`;
                                let payload = {
                                    unique_id: req.AuthUser?.unique_id,
                                    username: req.AuthUser.username,
                                    user_id: req.AuthUser.id,
                                    sender_id: req.AuthUser.id,
                                    receiver_id: id.sender_id,
                                    video_id: '',
                                    image: req.authUser?.profile_pic,
                                    title: message,
                                    type: 'profileUpdate',
                                }
                                await Helper.sendPushNotification2(req, id.sender_id, process.env.APP_NAME, message, payload);
                                // await Helper.sendPushNotification2(req, id.sender_id, process.env.APP_NAME, `${req.AuthUser.username} has updated his profile pic`);
                                await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:id.sender_id,message:`${req.AuthUser.username} has updated his profile pic`,type:"Profile"})
                            })
                            
                        }


                        let likes = await PostLike.findAll({ where: { user_id: user_id } });

                        let reponsePayload = {
                            followers_count: followers?.length,
                            following_count: followings?.length,
                            likes_count: likes?.length,
                            video_count: 0,
                            userDetails: checkUserExistORNot
                        }

                        return Helper.successResponseWithData(res, 'user_updated', SUCCESSMESSAGE.USER_UPDATE_SUCCESS, reponsePayload)
                    }
                    // .then((res) => {
                    //     // res.json({ status: true, data: { id: user }, message: SUCCESSMESSAGE.REGISTRATION_SUCCESS })
                    //     res.json({ status: true, data: { userDetails: user, accessToken: token }, message: SUCCESSMESSAGE.USER_UPDATE_SUCCESS })
                    // }
                    // )
                    // .catch((error) => {
                    //     res.json({ status: false, data: { errors: err }, message: SUCCESSMESSAGE.USER_UPDATE_FAILED })
                    // })


                }
            }
            // return res.json({ status: true, data: { id: user?.id }, message: SUCCESSMESSAGE.REGISTRATION_SUCCESS })
        } catch (error) {
            console.log("_______________________Error is here", error);
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },



    /**
    * Developer => Anshuman
    * Function to verifyOtp from the user 
    * 
    */
    verifyOtp: async (req, res) => {
        try {

            let email = req.body.email;
            let otp = req.body.otp;
            let sentOtp

            if (!otp || !email) {
                return await Helper.ErrorResponse(res, 'validation_error', 'A valid otp and email are required.')
            }

            // let user = await User.findOne({
            //     where: { email: email },
            //     order: [['createdAt', 'DESC']]
            // });

            // if (user && !user.is_block && !user.is_deleted) {

            let verificationData = await UserVerification.findOne({
                where: { email: email },
                order: [
                    ['createdAt', 'DESC']
                ]
            })

            if (verificationData) {
                let vDate = moment().diff(moment(verificationData.expired_at), 'minutes');

                if (vDate > 10) {
                    return await Helper.ErrorResponse(res, 'otp_expired', 'Otp has been expired.')
                }
                else if (verificationData.otp == otp ) {
                    return await Helper.SuccessResponse(res, 'otp_validated', 'Otp validated successfully')
                }
                else {
                    return await Helper.ErrorResponse(res, 'wrong_otp', 'Wrong otp provided')
                }
            } else {
                return await Helper.ErrorResponse(res, 'otp_not_found', 'Otp not found')
            }

            // } 
            // else {
            //     return await Helper.ErrorResponse(res, 'inactive_user', 'User is not active')
            // }

        } catch (error) {

            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)
        }
    },

    /**
     * Developer => Anshuman
     * Function to logout user from the system
     * 
     */
    logout: async (req, res) => {
        try {
            let checkUsereExists = await User.findOne({ where: { id: req.AuthUser?.id } });
            if (checkUsereExists) {
                checkUsereExists.device_token = null;
                if (checkUsereExists.save()) { return await Helper.successResponseWithData(res, 'user_logout', 'User logout has been successfully', checkUsereExists); }
            } else { return await Helper.ErrorResponse(res, 'user_not_found', 'User not found'); }
        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)
        }
    },

    /**
     * Developer => Anshuman
     * Function to block user from the system
     * 
     */
    block: async (req, res) => {

        try {
            let currentUserId = req.AuthUser.id;
            let blockUserId = req.body.block_user_id;

            if (!blockUserId) {
                return await Helper.ErrorResponse(res, 'blocked_id_unavailable', 'Block user id is required');
            }
            if (currentUserId == blockUserId) {
                return await Helper.ErrorResponse(res, 'self_blocking', 'Self blocking is not allowed');
            }

            let checkUserBlocked = await BlockUser.findOne({
                where: {
                    user_id: currentUserId,
                    block_user_id: blockUserId
                },
                order: [['createdAt', 'DESC']]
            });

            if (checkUserBlocked == null) {
                let requestObject = {
                    user_id: currentUserId,
                    block_user_id: blockUserId,
                    status: true
                }

                let blockResult = await BlockUser.create(requestObject);
                // remove from followers following 
                let follower = await  Follower.destroy({where:{sender_id:req.AuthUser.id,receiver_id:blockUserId}})
                let following = await  Follower.destroy({where:{receiver_id:req.AuthUser.id,sender_id:blockUserId}})
                if (blockResult) {
                    return await Helper.successResponseWithData(res, 'user_blocked', 'User blocked Successfully', blockResult)
                } else {
                    return await Helper.ErrorResponse(res, 'user_block_failed', 'Could not block user');

                }
            } else {
                if (checkUserBlocked.status == false) {
                    let updateObj = {
                        user_id: currentUserId,
                        block_user_id: blockUserId,
                        status: true
                    }
                    checkUserBlocked.set(updateObj);
                   
                     // remove from followers following 
                     let follower = await  Follower.destroy({where:{sender_id:req.AuthUser.id,receiver_id:blockUserId}})
                     let following = await  Follower.destroy({where:{receiver_id:req.AuthUser.id,sender_id:blockUserId}})

                    if (await checkUserBlocked.save()) {
                        return await Helper.successResponseWithData(res, 'user_blocked', 'User blocked Successfully', checkUserBlocked)
                    } else {
                        return await Helper.ErrorResponse(res, 'user_block_failed', 'Could not block user');

                    }
                } else {
                    return await Helper.successResponseWithData(res, 'user_blocked', 'User blocked Successfully2', checkUserBlocked)
                }
            }

        } catch (error) {

        }
    },

    /**
    * Developer => Anshuman
    * Function to unBlock user from the system
    * 
    */
    unBlock: async (req, res) => {

        try {
            let currentUserId = req.AuthUser.id;
            let blockUserId = req.body.block_user_id;
            console.log("currentUserID", currentUserId, "\n block user_id :", blockUserId)

            if (!blockUserId) {
                return await Helper.ErrorResponse(res, 'blocked_id_unavailable', 'UnBlock user id is required');
            }
            if (currentUserId == blockUserId) {
                return await Helper.ErrorResponse(res, 'self_unblocking', 'Self unblocking is not allowed');
            }

            let checkUserBlocked = await BlockUser.findOne({
                where: {
                    user_id: currentUserId,
                    block_user_id: blockUserId
                },
                order: [['createdAt', 'DESC']]
            });

            if (checkUserBlocked && checkUserBlocked?.status) {
                let requestObject = {
                    user_id: currentUserId,
                    block_user_id: blockUserId,
                    status: false
                }

                checkUserBlocked.set(requestObject)

                if (await checkUserBlocked.save()) {
                    return await Helper.successResponseWithData(res, 'user_unblocked', 'User Unblocked Successfully', checkUserBlocked)
                } else {
                    return await Helper.ErrorResponse(res, 'user_unblock_failed', 'Could not unblock user');

                }
            } else {
                return await Helper.ErrorResponse(res, 'user_not_blocked', 'User is not blocked');

            }


        } catch (error) {

        }
    },

    /**
   * Developer => Anshuman
   * Function to unBlock user from the system
   * 
   */
    refreshToken: async (req, res) => {
        try {

            let data = req.body;

            if (!data.email) {
                return await Helper.ErrorResponse(res, 'email_req', 'Email is required');
            }

            let checkUserExist = await User.findOne({
                attributes: ['profile_pic', 'id', 'first_name', 'last_name', 'email', 'gender', 'dob', 'phone', 'phone_code'],
                where: { email: data.email }
            });
            if (checkUserExist != null && Object.keys(checkUserExist)?.length > 0) {

                let token = await Helper.generateToken({ email: checkUserExist?.email, id: checkUserExist.id }, process.env.JWT_SECRET_REF, { expiresIn: '30d' });

                checkUserExist.dataValues.accessToken = token;

                return await Helper.successResponseWithData(res, 'ref_token', 'reference token generated successfully', checkUserExist);
            } else {
                return await Helper.ErrorResponse(res, 'user_not_found', 'user not found');

            }
        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);

        }

    },

    refreshToken2: async (req, res) => {

        if (req && req.body && req.body.identity && req.headers["refresh_token"]) {

            let userDetailObj = await commonModel.getRow('user_id, identity, auth_token', process.env.KEYSPACE_ASTRA + '.user_auth', 'identity', "'" + req.body.identity + "'");
            if (userDetailObj && userDetailObj.identity && userDetailObj.identity != '' && userDetailObj.auth_token != '') {
                const refreshToken = req.headers["refresh_token"] ? req.headers["refresh_token"].split(" ")[1] : '';

                if (userDetailObj.auth_token == refreshToken) {
                    let response = await middle.authenticateRefreshToken(req, res);
                    if (response == true) {
                        // if(userDetailObj.user_id == '0e3b6d25-b616-478a-9cd2-c36f520c52a8'){
                        // 	userDetailObj.access_token  = await helper.generateToken( { u_uuid: userDetailObj.user_id, identity: userDetailObj.identity }, process.env.JWT_SECRET, { expiresIn: '1m' });   
                        // } else{
                        userDetailObj.access_token = await helper.generateToken({ u_uuid: userDetailObj.user_id, identity: userDetailObj.identity }, process.env.JWT_SECRET, { expiresIn: '30d' });
                        // }
                        let obj = {
                            message: SUCCESS_MESSAGE.DATA_FETCHED,
                            payload: userDetailObj
                        };
                        helper.successResponse(res, obj);
                    }
                } else {
                    helper.errorResponse(res, {
                        code: ERROR_CODE.INVALID_REFRESH_TOKEN,
                        message: VALIDATION.INVALID_REFRESH_TOKEN
                    }, 200);
                }
            } else {
                helper.errorResponse(res);
            }
        } else {
            let obj = {
                code: ERROR_CODE.ALL_FIELDS_REQ,
                message: VALIDATION.ALL_FIELDS_REQ,
            };
            helper.errorResponse(res, obj, 200);
        }
    },

    
     /**
     * Developer => Keshav
     * Function to search a user
     * params : keyword,type,starting_point
     */
     search: async (req, res) => {
        try {
            let data = req.body;
            let searchDetails = "";
            let searchValue = data.keyword;
            let type = data.type;
            if (!searchValue) {
                return await Helper.ErrorResponse(res, 'keyword_error_101', 'keyword is required');
            }
            if (type == 'user') {

                searchDetails=await User.findAll({
                    where:{
                        [Op.or]:[
                            {first_name: { [Op.iLike]: `%${searchValue}%` }},
                            {username: { [Op.iLike]: `%${searchValue}%` }},
                            {last_name: { [Op.iLike]: `%${searchValue}%` }},
                        ],
                        is_block:false,
                    },
                    limit:data.limit || 10,
                    offset:data.offset || 0,
                    order:[['createdAt','DESC']]
                })
               
                if(searchDetails.length >0){
                    for(let i=0;i<searchDetails.length;i++){
                        
                        let post_count = await Post.findAll({ where: { user_id: searchDetails[i].dataValues.id, status: true } });
                        let followers_count = await Follower.findAll({ where: { receiver_id: searchDetails[i].dataValues.id } });
                        let following_count = await Follower.findAll({ where: { sender_id: searchDetails[i].dataValues.id } })
                       
                        searchDetails[i].dataValues.post_count = post_count?.length || 0;
                        searchDetails[i].dataValues.followers_count = followers_count?.length || 0;
                        searchDetails[i].dataValues.following_count = following_count?.length || 0;
                       
                       
                    }
                }
            } else if(type == 'video') {
                let usersOfPost = await User.findAll({
                    where:{
                        [Op.or]:[
                            {first_name: { [Op.iLike]: `%${searchValue}%` }},
                            {username: { [Op.iLike]: `%${searchValue}%` }},
                            {last_name: { [Op.iLike]: `%${searchValue}%` }},
                        ],
                        is_block:false,
                    },
                    limit:data.limit || 10,
                    offset:data.offset || 0,
                    order:[['createdAt','DESC']]
                });
                    let arrayofUserId = [];
                    for(let i=0; i<usersOfPost.length; i++){
                        arrayofUserId.push(usersOfPost[i].id);
                    }
               
                searchDetails=await Post.findAll({
                    where:{
                        [Op.or]:[
                            {description: { [Op.iLike]: `%${searchValue}%` }},
                            {user_id : arrayofUserId}
                        ],
                        block:0,
                    },
                    include: [
                        {
                            model: HashTagPost,
                            as: 'hashTags',
                            required: false,
                            separate: true, // Fetch comments separately
                            include: [
                                {
                                    model: HashTag,
                                    as: 'hashtag',
                                    required: false
                                }
                            ]
                        }, 
                        {
                            model: PostLike,
                            as: 'likePost',
                            required: false,
                            separate: true, // Fetch likes separately
                            include: [
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'email']
                                }
                            ]
                        }, 
                        {
                            model: PostComment,
                            as: 'comment',
                            required: false,
                            separate: true, // Fetch comments separately
                            include: [
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'email', 'device', 'device_token']
                                }
                            ]
                        },
                        {
                            model: Sound,
                            as: 'sound',
                            required: false,
                            // separate: true, // Fetch comments separately
                        },
                        {
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id', 'first_name', 'device', 'device_token','username','profile_pic']
                        }
                    ],
                    limit:data.limit || 10,
                    offset:data.offset || 0,
                    order:[['createdAt','DESC']]
                })
                    
                  
                   
                
                
                if(searchDetails.length>0){
                    for(let i=0;i<searchDetails.length;i++){
                        if (searchDetails[i].id != null) {
                            let totalPostcomment = await PostComment.findAll({ where: { post_id: searchDetails[i].id } });
                            let totalLikePost = await PostLike.findAll({ where: { post_id: searchDetails[i].id } })
                            let favouritePost = await PostFavourite.findAll({ where: { post_id: searchDetails[i].id } })
                            let is_liked = await PostLike.findAll({ where: {post_id:searchDetails[i].id,user_id:req.AuthUser.id} });
                            let soundCount;
                            let soundFav;
                            
                            if(searchDetails[i] && searchDetails[i].dataValues.sound && searchDetails[i].dataValues.sound.id ){
                                soundFav = await SoundFavourite.findAll({ where: { sound_id: searchDetails[i].dataValues.sound.id, user_id: req.AuthUser.id } });
                            }
                            if(searchDetails[i] && searchDetails[i].sound && searchDetails[i].sound.id ){
                                soundCount =await Post.findAll({ where: { sound_id: searchDetails[i].sound.id } });
                            }
                            // let soundFav = await SoundFavourite.findAll({ where: { sound_id: searchDetails[i].dataValues.sound.id, user_id: req.AuthUser.id } })
                            // let soundCount = await Post.findAll({ where: { sound_id: searchDetails[i].sound.id } })

                            let followers = await Follower.findAll({ where: { receiver_id: searchDetails[i].user_id } });
                            let followings = await Follower.findAll({ where: { sender_id: searchDetails[i].user_id } });
                            let _posts = await Post.findAll({ where: { user_id: searchDetails[i].user_id } });
                            let likes = await PostLike.findAll({ where: { user_id: searchDetails[i].user_id } });
                            checkFollow = await Follower.findAll({ where: { receiver_id: searchDetails[i].user_id, sender_id: req.AuthUser.id } });



                            searchDetails[i].dataValues.video_comment_count = totalPostcomment?.length || 0;
                            searchDetails[i].dataValues.like_count = totalLikePost?.length || 0;
                            searchDetails[i].dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0;
                            searchDetails[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                            searchDetails[i].dataValues.favourite_count = favouritePost?.length > 0 ? favouritePost?.length : 0

                            if(searchDetails[i].dataValues.sound != null){
                                searchDetails[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                                searchDetails[i].dataValues.sound.dataValues.video_count = soundCount?.length || 0
                            } else {
                                searchDetails[i].dataValues.sound={};
                            }
                           

                            searchDetails[i].user.dataValues.followers = followers?.length || 0
                            searchDetails[i].user.dataValues.followings = followings?.length || 0
                            searchDetails[i].user.dataValues.totalPost = _posts?.length || 0
                            searchDetails[i].user.dataValues.totalLikes = likes?.length || 0
                            searchDetails[i].user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
                        }

                    }
                }
            }
            else if(type == 'sound') {
               
                // let searchClause = `SELECT * FROM sounds WHERE publish=1 and description ilike '%${searchValue}%' OR name ilike '%${searchValue}%' offset ${data.offset} limit ${data.limit}`;
                // searchDetails = await db.sequelize.query(searchClause, {
                //     model: Sound,
                //     mapToModel: true // pass true here if you have any mapped fields
                // });

                searchDetails=await Sound.findAll({
                    where:{
                        [Op.or]:[
                            {description: { [Op.iLike]: `%${searchValue}%` }},
                            {name: { [Op.iLike]: `%${searchValue}%` }},
                        ],
                        // publish:1,
                    },
                    limit: data.limit || 10,
                    offset:data.offset || 0,
                    order:[['createdAt','DESC']]
                })
                
            }
            else if(type == 'hashtag') {
               
                // let searchClause = `SELECT * FROM hashtags WHERE name ilike '%${searchValue}%' offset ${data.offset} limit ${data.limit}`;
                // searchDetails = await db.sequelize.query(searchClause, {
                //     model: HashTag,
                //     mapToModel: true // pass true here if you have any mapped fields
                // });


                searchDetails=await HashTag.findAll({
                    where: { name: { [Op.iLike]: `%${searchValue}%` }, },
                    limit:data.limit || 10,
                    offset:data.offset || 0,
                    order:[['createdAt','DESC']]
                })
                if (searchDetails.length > 0) {
                    for (let i = 0; i < searchDetails.length; i++) {
                        let hashCount = await HashTagPost.findAll({ where: { hashtag_id:searchDetails[i].dataValues.id} })
                        searchDetails[i].dataValues.videos_count = hashCount?.length || 0;
                    }
                }

            }

            if (!searchDetails) {
                return await Helper.ErrorResponse(res, 'search_not_found', 'search is not found')
            }
            return await Helper.successResponseWithData(res, 'search_found', 'Search list', searchDetails);
        } catch (error) {
            console.log("_________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error)
        }
    },

}
module.exports = AuthController;
