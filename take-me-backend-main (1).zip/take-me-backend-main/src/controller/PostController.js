require("dotenv").config();
const { Validator } = require("node-input-validator");
const { Post, Sound, HashTag, HashTagPost, User, PostLike, Notification, Follower, PostComment, Repost, PostFavourite, sequelize, BlockUser,
ReportPost, ReportReason, PostCommentLike, PostCommentReply, PostCommentReplyLike, HashTagFavourite,SavedVideo ,PostView,
PushNotification,NotificationMessages,SoundFavourite,TransactionHistory,promotion, PrivacySetting} = require('../../models');
const Cryptr = require("cryptr");
const db = require('../../models');
const { STATUSCODE, SUCCESSMESSAGE, CUSTOM_MESSAGE } = require('../utils/constant')
const Helper = require("../utils/helper");
const moment = require('moment');
const { where, Op, Sequelize } = require("sequelize");
const { response } = require("express");
const jwt = require("jsonwebtoken");
const { crossOriginOpenerPolicy } = require("helmet");
const awsService = require('../../config/awsSerive')


var PostController = {
    /**
     * Developer => Prince
     * Date:25/12/2023
     * Function upload the post for the app
     * 
     */

    uploadPost: async (req, res) => {
        try {

            let data = req.body;


            let v = await new Validator(req.body, {
                // description: "required",
                video: "required",
                thumbnail: "required",
                video_id: "required",
            }, {
                // "description.required": "Please enter the description",
                "video.required": "Please enter the video",
                "thumbnail.required": "Please enter the thumbnail",
            }
            );
            let checks = await v.check();
            if (!checks) {
                let description = v.errors.description ? v.errors.description : '';
                let video = v.errors.video ? v.errors.video : '';
                let thumbnail = v.errors.thumbnail ? v.errors.thumbnail : '';
               
                return await Helper.ErrorResponseWithStatusCode(res, [description, video, thumbnail]);
            } else {
                if(isNaN(data.allow_duet)){
                    return await Helper.ErrorResponse(res,'type_format',`Please type the correct format for allow duet`)
                } else if(isNaN(data.product)){
                    return await Helper.ErrorResponse(res,'type_format',`Please type the correct format for product`)
                }
                let obj = {};
                obj.user_id = req.AuthUser.id,
                    obj.video = data.video,
                    obj.thumbnail = data.thumbnail,
                    obj.allow_comments = data.allow_comment,
                    obj.allow_duet = data.allow_duet,
                    obj.old_video_id = data.video_id
                    obj.privacy_type = data.privacy_type

                //payload will be called
                if (data.description || data.location_string || data.lat || data.long || data.product) {
                    obj.description = data.description,
                        obj.location_string = data.location_string,
                        obj.lat = data.lat,
                        obj.long = data.long,
                        obj.product = data.product
                }
                console.log("--------------",data.status)
                obj.status = data.status == "1" ? true:false;
                
               
               
                let post = await Post.create(obj);
                
                post.video_hls = "https://vod.api.video/vod/"+post.video_id+"/hls/manifest.m3u8";

                let post_id = post.id;

                let followers = await Follower.findAll({where:{receiver_id:req.AuthUser.id}})
               
               
                if(followers.length >0 && post.status ===true){
                for(let i=0;i<followers.length;i++){

                let pushNotfSettingDetail = await PushNotification.findOne({
                    where: {
                        id: followers[i].sender_id
                    }
                });
            
                if (pushNotfSettingDetail && pushNotfSettingDetail.video_updated == 1){
                    if(followers[i].sender_id != req.AuthUser?.id){
                        var message = `${req.AuthUser?.username} has uploaded a post`;
                        let payload = {
                            unique_id: req.AuthUser?.unique_id,
                            username: req.AuthUser?.username,
                            user_id: req.AuthUser.id,
                            sender_id: req.AuthUser.id,
                            receiver_id: followers[i].sender_id,
                            video_id: post_id,
                            image: req.AuthUser?.profile_pic,
                            title: message,
                            type: 'uploadPost',
                        }
                        await Helper.sendPushNotification2(req, followers[i].sender_id, process.env.APP_NAME, message, payload);
                        await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:followers[i].sender_id,message:`${req.AuthUser.username} this user uploaded a post.`,type:"Post"})
                        }
                    }
                }
            }

            if(post.status === true){
                await TransactionHistory.create({user_id:req.AuthUser.id,post_id:post_id,type:"upload_post",Remarks:`user uploaded a post.`,points:1})
                let points = await TransactionHistory.findAll({where:{user_id:req.AuthUser.id , type : 'upload_post'}})
                await User.update({uploadPost_points:points?.length},{where:{id:req.AuthUser.id}})
            }
          
                function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                  }
 
                
                if(!data.sound_id || data.sound_id === null){
                   
                    await sleep(10000); 
                      try {

                          const audioFilePath = await Helper.convertVideoToAudio(data.video.trim(), req.AuthUser.id);



                          // const duration = await Helper.getAudioDuration(audioFilePath)
                          // console.log("------------------------iiiiiiiiiiiiiiiii-",duration)

                          let newSoundData = await Sound.create({ audio: audioFilePath.path, name: req.AuthUser.username, thumbnail: data.thumbnail, duration: audioFilePath.duration.toFixed(2) });

                          await Post.update({ sound_id: newSoundData.id, duration: audioFilePath.duration.toFixed(2) }, { where: { id: post_id } });
 
                        post.dataValues.sound_Link = process.env.Sound_URL + '/' + audioFilePath
                        post.dataValues.sound_id = newSoundData.id
                        post.dataValues.sound_name = req.AuthUser.username
                        await post.save();
                    } catch (error) {
                        console.error("Error converting video to audio:", error);
                    }
                }
                else{
                    console.log("else condition----------------------------------------------------------------------",data)
                    let duration = await Sound.findOne({where:{id:data.sound_id}})
                    await Post.update({ sound_id:data.sound_id ,duration:duration.duration.toFixed(2)}, { where: { id: post_id } });
                }

         
                //hash tags added is here
                if (data.hashtags_json) {
                  console.log("-----------------------",data.hashtags_json)
                    let hash_tag = JSON.parse(data.hashtags_json);
                    let hashTagLenght = hash_tag.length;
    
                    for (let i = 0; i < hashTagLenght; i++) {
                        let checkHashTagExists = await HashTag.findOne({ where: { name: hash_tag[i].name } });
                      
                        let obj = {
                            name: hash_tag[i].name,
                        }
                      
                        if(checkHashTagExists !=null && Object.keys(checkHashTagExists)?.length > 0){
                        console.log("if part",)
                         let hashTagId = await checkHashTagExists.id;
                            let postHash = await HashTagPost.create({ hashtag_id: hashTagId, post_id: post_id });
                        
                        } else {
                            console.log("els epart")
                            let hashtags = await HashTag.create(obj);
                            let postHash = await HashTagPost.create({ hashtag_id: hashtags.id, post_id: post_id });
                        }

                    }
                }
                console.log("-------------",post.status)
                post.dataValues.status = post.status ? 1 : 0 
                await promotion.create({
                    post_id:post_id,
                    user_id:req.AuthUser.id,
                    start_datetime:post.createdAt ,
                    end_datetime:post.updatedAt,
                    website_url:data.video,
                    followers:followers.length,
                    audience_id:req.AuthUser.id
                }) 
                return await Helper.successResponseWithData(res, 'post_created', 'Post has been created successfully', post);
            }
        } catch (error) {
            console.log("________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },

    publishPost: async (req, res) => {
        try {

            let data = req.body;
           
            await Post.update({status:true},{where:{id:data.post_id}})
            let post = await Post.findOne({where:{id:data.post_id}})


            return await Helper.successResponseWithData(res, 'post_created', 'Post has been created successfully', post);
        } catch (error) {
            console.log("________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    /**
    * Developer => Prince
    * Function fetchPost
    * 
    */
    fetchPost: async (req, res) => {
        try {
            let data = req.body;
           let decodedToken,userId,token
           if(req.headers.authorization){
            token= req.headers.authorization.split(" ")[1]
            decodedToken = jwt.verify(token, process.env.JWT_SECRET)
            userId = decodedToken.id;

           }
           
            if (data.type == 1) {
                let followingUser;
                let posts = "";
                let allPosts;
                let postPromises=[]
              if(token){
                 followingUser = await Follower.findAll({ attributes: ['receiver_id'], where: { sender_id:userId} });
              }
                
                if (followingUser?.length > 0) {
                    // for (let i = 0; i < followingUser?.length; i++) {
                    //     console.log("followingUser",followingUser[i].receiver_id)
                    //     // if (followingUser[i]?.receiver_id != null) {
                    //         posts = await Post.findAll({
                    //             where: { user_id: '43714d02-6b96-4a03-bf29-7517bf557220' },
                    //             include: [
                    //                 {
                    //                 model: HashTagPost,
                    //                 as: 'hashTags',
                    //                 required: false,
                    //                 include: [{ 
                    //                     model: HashTag,
                    //                     as: 'hashtag',
                    //                     required: false
                    //                 }]
                    //             }, 
                    //             {
                    //                 model: PostLike,
                    //                 as: 'likePost',
                    //                 required: false,
                    //                 include: [{
                    //                     model: User,
                    //                     as: 'user',
                    //                     required: false,
                    //                     attributes: ['id', 'first_name', 'email']
                    //                 }]
                    //             }, 
                    //             {
                    //                 model: PostComment,
                    //                 as: 'comment',
                    //                 required: false,
                    //                 include: [{
                    //                     model: User,
                    //                     as: 'user',
                    //                     required: false,
                    //                     attributes: ['id', 'first_name', 'email', 'device', 'device_token']
                    //                 }]
                    //             },
                    //             {
                    //                 model: User,
                    //                 as: 'user',
                    //                 required: false,
                    //                 attributes: ['id', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic']
                    //             }
                    //         ],

                    //             limit: data?.limit || 10,
                    //             offset: data?.offset || 0,
                    //             order: [['createdAt', 'DESC']]
                    //         });
                    //     // }
                    // }
                    // Create an array to store promises for fetching posts
                    postPromises = [];

                    for (let i = 0; i < followingUser?.length; i++) {

                        // Push the promise for fetching posts to the postPromises array
                        postPromises.push(
                            Post.findAll({
                                where: { user_id: followingUser[i].receiver_id ,where:{privacy_type:'private'},},
                                include: [
                                    {
                                        model: HashTagPost,
                                        as: 'hashTags',
                                        required: false,
                                        include: [{
                                            model: HashTag,
                                            as: 'hashtag',
                                            required: false
                                        }]
                                    },
                                    {
                                        model: PostLike,
                                        as: 'likePost',
                                        required: false,
                                        include: [{
                                            model: User,
                                            as: 'user',
                                            required: false,
                                            attributes: ['id', 'first_name', 'email']
                                        }]
                                    },
                                    {
                                        model: PostComment,
                                        as: 'comment',
                                        required: false,
                                        include: [{
                                            model: User,
                                            as: 'user',
                                            required: false,
                                            attributes: ['id', 'first_name', 'email', 'device', 'device_token']
                                        }]
                                    },
                                    {
                                        model: Sound,
                                        as: 'sound',
                                        required: false,
                                        // separate: true, // Fetch comments separately
                                    },
                                    {
                                        model: User,
                                        as: 'user',
                                        required: false,
                                        attributes: ['id','username', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic']
                                    }
                                ],
                                limit: data?.limit || 10,
                                offset: data?.offset || 0,
                                order: [['createdAt', 'DESC']]
                            })
                        );
                    }

                    // Wait for all promises to resolve
                    posts = await Promise.all(postPromises);

                    // Concatenate the arrays of posts into a single array
                    allPosts = posts.flat();
                    
            
                    let checkFollow
                    let is_liked ,is_favourite;
                    let soundCount;
                    let soundFav;
                    if (allPosts.length > 0) {
                        
                        for (let i = 0; i < allPosts.length; i++) {
                            allPosts[i].dataValues.video_hls = "https://vod.api.video/vod/" + allPosts[i].dataValues.old_video_id + "/hls/manifest.m3u8";
                            let followers = await Follower.findAll({ where: { receiver_id: allPosts[i].user_id } });
                            let followings = await Follower.findAll({ where: { sender_id: allPosts[i].user_id } });

                            let _posts = await Post.findAll({ where: { user_id: allPosts[i].user_id } });
                            let likes = await PostLike.findAll({ where: { user_id: allPosts[i].user_id } });
                            let profilePic = await User.findAll({where:{id:allPosts[i].user_id}})

                            
                            let rePostCount = await Repost.findAll({ where: { post_id: allPosts[i].id } });
                            if (userId) {
                                is_liked = await PostLike.findAll({ where: { post_id: allPosts[i].id, user_id: userId } });
                                checkFollow = await Follower.findAll({ where: { receiver_id: allPosts[i].user_id, sender_id: userId } });
                                is_favourite = await PostFavourite.findAll({ where: {post_id:allPosts[i].id,user_id:userId} });
                                
                                
                                if(allPosts[i].post && allPosts[i].post.sound && allPosts[i].post.sound.id ){
                                    soundFav = await SoundFavourite.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id, user_id: userId } })
                                }
                                
                                // soundFav = await SoundFavourite.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id, user_id: userId } })
                            }
                            if(allPosts[i].post && allPosts[i].post.sound && allPosts[i].post.sound.id ){
                                soundCount =  await Post.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id } })
                            }
                            // let soundCount = await Post.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id } })
                            

    
                            if (allPosts[i].id != null) {
                                let totalPostcomment = await PostComment.findAll({ where: { post_id: allPosts[i].id } });
                                let totalRePost = await Repost.findAll({ where: { post_id: allPosts[i].id } });
                                let totalLikePost = await PostLike.findAll({ where: { post_id: allPosts[i].id } })
                                let favouritePost = await PostFavourite.findAll({ where: { post_id: allPosts[i].id } })
                                const privacyDetails = await PrivacySetting.findOne({
                                    where: {
                                        user_id: allPosts[i].user_id
                                    }
                                });
                                let privacySetting = {};
                                if(privacyDetails){
                                    privacySetting = {
                                        videos_download: privacyDetails.dataValues.videos_download,
                                        direct_message: privacyDetails.dataValues.direct_message,
                                        duet: privacyDetails.dataValues.duet,
                                        liked_videos: privacyDetails.dataValues.liked_videos,
                                        video_comment: privacyDetails.dataValues.video_comment,
                                        direct_messages: privacyDetails.dataValues.direct_messages,
                                    }
                                }
                                
                                allPosts[i].dataValues.video_comment_count = totalPostcomment?.length || 0;
                                allPosts[i].dataValues.totalRePost = totalRePost?.length || 0;
                                allPosts[i].dataValues.like_count = totalLikePost?.length || 0;
                                allPosts[i].dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0;

                                allPosts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                                allPosts[i].dataValues.rePostCount = rePostCount?.length || 0
                                allPosts[i].dataValues.favourite_count = favouritePost?.length || 0;
                                allPosts[i].dataValues.privacySetting = privacySetting;
                            

                                if (allPosts[i].dataValues.sound !== null) {
                                    allPosts[i].dataValues.sound.audio = process.env.Sound_URL + '/' + allPosts[i].dataValues.sound.audio
                                    allPosts[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                                    allPosts[i].dataValues.sound.dataValues.video_count = soundCount?.length || 0 
                                }
                                else if (allPosts[i].dataValues.sound === null) {
                                    allPosts[i].dataValues.sound = {}
                                }
                            }

                            allPosts[i].user.dataValues.followers = followers?.length || 0
                            allPosts[i].user.dataValues.followings = followings?.length || 0
                            allPosts[i].user.dataValues.totalPost = _posts?.length || 0
                            allPosts[i].user.dataValues.totalLikes = likes?.length || 0;

                            allPosts[i].user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
                            allPosts[i].user.dataValues.profile_pic = profilePic[0].dataValues.profile_pic

                        }
    
                    }

                }
            
            // console.log('allposts=========',allPosts)
            allPosts = await Helper.removeBlockUsers(allPosts,userId);

                return await Helper.successResponseWithData(res, 'posts_fetched', 'Posts has been fetched successfully', allPosts?.length > 0 ? allPosts : []);
            
            } else if (data.type == 2) {

                let posts = await Post.findAll({
                    include: [
                        {
                            model: HashTagPost,
                            as: 'hashTags',
                            required: false,
                            separate: true, // Fetch comments separately
                            include: [
                                {
                                    model: HashTag,
                                    as: 'hashtag',
                                    required: false
                                }
                            ]
                        }, 
                        {
                            model: PostLike,
                            as: 'likePost',
                            required: false,
                            separate: true, // Fetch likes separately
                            include: [
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'email']
                                }
                            ]
                        }, 
                        {
                            model: PostComment,
                            as: 'comment',
                            required: false,
                            separate: true, // Fetch comments separately
                            include: [
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'email', 'device', 'device_token']
                                }
                            ]
                        },
                        {
                            model: Sound,
                            as: 'sound',
                            required: false,
                            // separate: true, // Fetch comments separately
                        },
                        {
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id', 'first_name', 'device', 'device_token','username']
                        }
                    ],
                    // where:{privacy_type:'public' ,privacy_type:null},
                    where: {
                        [Op.or]: [
                            { privacy_type: 'public' },
                            { privacy_type: null }
                        ]
                    },
                    limit:50,
                    // offset: data?.offset || 0,
// offset: getRandomOffset(totalPosts, data?.limit || 10),
                    subQuery: false,
                    // order: [['createdAt', 'DESC']]
                    // order: Sequelize.literal('random()'), // Use a database-specific function to generate random ordering
                    order: sequelize.random(),
                });
                
              
                let is_liked = 0;
                let is_favourite = 0
                let checkFollow;
                let soundFav;
                let soundCount;

                if (posts.length > 0) {   
                for (let i = 0; i < posts.length; i++) {
                
                let followers = await Follower.findAll({ where: { receiver_id: posts[i].user_id } });
                let followings = await Follower.findAll({ where: { sender_id: posts[i].user_id } });

                let _posts = await Post.findAll({ where: { user_id: posts[i].user_id } });
                let likes = await PostLike.findAll({ where: { user_id: posts[i].user_id } });
                let profilePic = await User.findAll({where:{id:posts[i].user_id}})
                    
                if (posts[i].id != null) {
                let totalPostcomment = await PostComment.findAll({ where: { post_id: posts[i].id } });
                let totalRePost = await Repost.findAll({ where: { post_id: posts[i].id } });
                let totalLikePost = await PostLike.findAll({ where: { post_id: posts[i].id } })
                let favouritePost = await PostFavourite.findAll({ where: { post_id: posts[i].id } })
                
                           
                        
                if (token) {
                is_liked = await PostLike.findAll({ where: {post_id:posts[i].id,user_id:userId} });
                is_favourite = await PostFavourite.findAll({ where: {post_id:posts[i].id,user_id:userId} });
                    
                }
                if (userId) {
                checkFollow = await Follower.findAll({ where: { receiver_id: posts[i].user_id, sender_id: userId } });
                if(posts[i] && posts[i].dataValues && posts[i].dataValues.sound && posts[i].dataValues.sound.id ){
                    soundFav = await SoundFavourite.findAll({ where: { sound_id: posts[i].dataValues.sound.id, user_id: userId } })
                }
                }
                            
                let rePostCount = await Repost.findAll({ where: { post_id: posts[i].id } });
                if(posts[i] && posts[i].sound && posts[i].sound.id ){
                    soundCount = await Post.findAll({where:{sound_id:posts[i].sound.id}})
                }

                // let soundCount = await Post.findAll({where:{sound_id:posts[i].sound.id}})
                const privacyDetails = await PrivacySetting.findOne({
                    where: {
                        user_id: posts[i].user_id
                    }
                });
                let privacySetting={};
                if(privacyDetails){
                    privacySetting= {
                        videos_download: privacyDetails.dataValues.videos_download,
                        direct_message: privacyDetails.dataValues.direct_message,
                        duet: privacyDetails.dataValues.duet,
                        liked_videos: privacyDetails.dataValues.liked_videos,
                        video_comment: privacyDetails.dataValues.video_comment,
                        direct_messages: privacyDetails.dataValues.direct_messages,
                    }
                }
                
                
                posts[i].dataValues.privacySetting = privacySetting;
                posts[i].dataValues.video_comment_count = totalPostcomment?.length || 0;
                posts[i].dataValues.totalRePost = totalRePost?.length || 0;
                posts[i].dataValues.like_count = totalLikePost?.length || 0;
                posts[i].dataValues.is_favourite = is_favourite?.length > 0 ? 1 : 0;
                posts[i].dataValues.favourite_count = favouritePost?.length || 0;


                posts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0

                posts[i].dataValues.rePostCount = rePostCount?.length || 0
                if(posts[i].dataValues.sound !== null){
                posts[i].dataValues.sound.audio = process.env.Sound_URL  + '/' + posts[i].dataValues.sound.audio
                posts[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0; 
                posts[i].dataValues.sound.dataValues.video_count = soundCount?.length || 0 
                }
                else if(posts[i].dataValues.sound === null){
                    posts[i].dataValues.sound = {}
                    }
                
                }

                posts[i].user.dataValues.followers = followers?.length || 0
                posts[i].user.dataValues.followings = followings?.length || 0
                posts[i].user.dataValues.totalPost = _posts?.length || 0
                posts[i].user.dataValues.totalLikes = likes?.length || 0
                posts[i].user.dataValues.profile_pic = profilePic[0].dataValues.profile_pic

                posts[i].user.dataValues.button = checkFollow?.length ? "Following" :"Follow"

                posts[i].dataValues.video_hls = "https://vod.api.video/vod/"+posts[i].dataValues.old_video_id+"/hls/manifest.m3u8";
                //console.log(posts);
                
             
                }
                }

                let filteredPosts = posts.filter(item => item.status === true);
                // if (posts.length > 0) {
                //     let userIds = posts.map(post => post.user_id);
                //     let postIds = posts.map(post => post.id);
                
                //     let [followers, followings, _posts, likes, profilePics, totalPostcomments, totalRePosts, totalLikePosts, favouritePosts,rePostCounts] = await Promise.all([
                //         Follower.findAll({ where: { receiver_id: userIds } }),
                //         Follower.findAll({ where: { sender_id: userIds } }),
                //         Post.findAll({ where: { user_id: userIds } }),
                //         PostLike.findAll({ where: { user_id: userIds } }),
                //         User.findAll({ where: { id: userIds }, attributes: ['id', 'profile_pic'] }),

                //         PostComment.findAll({ where: { post_id: postIds } }),
                //         Repost.findAll({ where: { post_id: postIds } }),
                //         PostLike.findAll({ where: { post_id: postIds } }),
                //         PostFavourite.findAll({ where: { post_id: postIds } }),
                //         Repost.findAll({ where: { post_id: postIds } }),
                        
                //     ]);
                //     let isLiked ,checkFollow ,is_favourite 
                //     if(token){
                //         await Promise.all([
                //         isLiked = PostLike.findAll({ where: { post_id: postIds, user_id: userId } }),
                //         checkFollow = Follower.findAll({ where: { receiver_id: userIds, sender_id: userId } }),
                //         is_favourite = PostFavourite.findAll({ where: {post_id:postIds,user_id:userId} })   
                //     ]);
                // }
                
                //     for (let i = 0; i < posts.length; i++) {
                //         posts[i].user.dataValues.followers = followers.filter(follower => follower.receiver_id === posts[i].user_id).length;
                //         posts[i].user.dataValues.followings = followings.filter(following => following.sender_id === posts[i].user_id).length;
                //         posts[i].user.dataValues.totalPost = _posts.filter(post => post.user_id === posts[i].user_id).length;
                //         posts[i].user.dataValues.totalLikes = likes.filter(like => like.user_id === posts[i].user_id).length;
                //         posts[i].user.dataValues.profile_pic = profilePics.find(pic => pic.id === posts[i].user_id)?.profile_pic || null;
                //         // posts[i].user.dataValues.button = checkFollow.find(follow => follow.receiver_id === posts[i].user_id) ? "Following" : "Follow";
                //         posts[i].user.dataValues.button =checkFollow.then((followData)=>{ followData.find(follow => follow.receiver_id === posts[i].user_id) ? "Following" : "Follow";})
                
                //         posts[i].dataValues.video_comment_count = totalPostcomments.filter(comment => comment.post_id === posts[i].id).length;
                //         posts[i].dataValues.totalRePost = totalRePosts.filter(repost => repost.post_id === posts[i].id).length;
                //         posts[i].dataValues.like_count = totalLikePosts.filter(like => like.post_id === posts[i].id).length;
                //         posts[i].dataValues.is_favourite =is_favourite.then((is_favourite)=>{ is_favourite.find(favourite => favourite.post_id === posts[i].id) ? 1 : 0})
                //         posts[i].dataValues.is_like =isLiked.then((isLiked)=>{ isLiked.find(like => like.post_id === posts[i].id) ? 1 : 0})
                //         posts[i].dataValues.rePostCount = rePostCounts.filter(repost => repost.post_id === posts[i].id).length;
                //         posts[i].dataValues.video_hls = "https://vod.api.video/vod/" + posts[i].dataValues.old_video_id + "/hls/manifest.m3u8";
                //     }
                // }
                // console.log('req.AuthUser.id======',req.AuthUser.id)
                filteredPosts = await Helper.removeBlockUsers(filteredPosts,userId);

                return await Helper.successResponseWithData(res, 'user_id_req', 'Posts has been fetched successfully', filteredPosts?.length > 0 ? filteredPosts : []);
            } else { return await Helper.ErrorResponse(res, 'type_not_valid', 'type not acceptable') }
        } catch (error) {
            console.log("______________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },

    fetchPost1: async (req, res) => {
        try {
            let data = req.body;
           let decodedToken,userId,token
           if(req.headers.authorization){
            token= req.headers.authorization.split(" ")[1]
            decodedToken = jwt.verify(token, process.env.JWT_SECRET)
            userId = decodedToken.id;

           }
           
       
            if (data.type == 1) {
                let followingUser;
                let posts = "";
                let allPosts;
                let postPromises=[]
              if(token){
                 followingUser = await Follower.findAll({ attributes: ['receiver_id'], where: { sender_id:userId} });
              }
                
                if (followingUser?.length > 0) {
                    // for (let i = 0; i < followingUser?.length; i++) {
                    //     console.log("followingUser",followingUser[i].receiver_id)
                    //     // if (followingUser[i]?.receiver_id != null) {
                    //         posts = await Post.findAll({
                    //             where: { user_id: '43714d02-6b96-4a03-bf29-7517bf557220' },
                    //             include: [
                    //                 {
                    //                 model: HashTagPost,
                    //                 as: 'hashTags',
                    //                 required: false,
                    //                 include: [{ 
                    //                     model: HashTag,
                    //                     as: 'hashtag',
                    //                     required: false
                    //                 }]
                    //             }, 
                    //             {
                    //                 model: PostLike,
                    //                 as: 'likePost',
                    //                 required: false,
                    //                 include: [{
                    //                     model: User,
                    //                     as: 'user',
                    //                     required: false,
                    //                     attributes: ['id', 'first_name', 'email']
                    //                 }]
                    //             }, 
                    //             {
                    //                 model: PostComment,
                    //                 as: 'comment',
                    //                 required: false,
                    //                 include: [{
                    //                     model: User,
                    //                     as: 'user',
                    //                     required: false,
                    //                     attributes: ['id', 'first_name', 'email', 'device', 'device_token']
                    //                 }]
                    //             },
                    //             {
                    //                 model: User,
                    //                 as: 'user',
                    //                 required: false,
                    //                 attributes: ['id', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic']
                    //             }
                    //         ],

                    //             limit: data?.limit || 10,
                    //             offset: data?.offset || 0,
                    //             order: [['createdAt', 'DESC']]
                    //         });
                    //     // }
                    // }
                    // Create an array to store promises for fetching posts
                    postPromises = [];

                    for (let i = 0; i < followingUser?.length; i++) {

                        // Push the promise for fetching posts to the postPromises array
                        postPromises.push(
                            Post.findAll({
                                where: { user_id: followingUser[i].receiver_id },
                                include: [
                                    {
                                        model: HashTagPost,
                                        as: 'hashTags',
                                        required: false,
                                        include: [{
                                            model: HashTag,
                                            as: 'hashtag',
                                            required: false
                                        }]
                                    },
                                    {
                                        model: PostLike,
                                        as: 'likePost',
                                        required: false,
                                        include: [{
                                            model: User,
                                            as: 'user',
                                            required: false,
                                            attributes: ['id', 'first_name', 'email','username']
                                        }]
                                    },
                                    {
                                        model: PostComment,
                                        as: 'comment',
                                        required: false,
                                        include: [{
                                            model: User,
                                            as: 'user',
                                            required: false,
                                            attributes: ['id', 'first_name', 'email', 'device', 'device_token','username']
                                        }]
                                    },
                                    {
                                        model: User,
                                        as: 'user',
                                        required: false,
                                        attributes: ['id','username', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic']
                                    }
                                ],
                                limit: data?.limit || 10,
                                offset: data?.offset || 0,
                                order: [['createdAt', 'DESC']]
                            })
                        );
                    }

                    // Wait for all promises to resolve
                    posts = await Promise.all(postPromises);

                    // Concatenate the arrays of posts into a single array
                    allPosts = posts.flat();
            
                    let checkFollow
                    if (allPosts.length > 0) {
                        for (let i = 0; i < allPosts.length; i++) {
                            allPosts[i].dataValues.video_hls = "https://vod.api.video/vod/" + allPosts[i].dataValues.old_video_id + "/hls/manifest.m3u8";
                            let followers = await Follower.findAll({ where: { receiver_id: allPosts[i].user_id } });
                            let followings = await Follower.findAll({ where: { sender_id: allPosts[i].user_id } });

                            let _posts = await Post.findAll({ where: { user_id: allPosts[i].user_id } });
                            let likes = await PostLike.findAll({ where: { user_id: allPosts[i].user_id } });

                            let is_liked = await PostLike.findAll({ where: { post_id: allPosts[i].id, user_id: userId } });
                            let rePostCount = await Repost.findAll({ where: { post_id: allPosts[i].id } });
                            if (userId) {
                                checkFollow = await Follower.findAll({ where: { receiver_id: allPosts[i].user_id, sender_id: userId } });
                            }
   
    
                            if (allPosts[i].id != null) {
                                let totalPostcomment = await PostComment.findAll({ where: { post_id: allPosts[i].id } });
                                let totalRePost = await Repost.findAll({ where: { post_id: allPosts[i].id } });
                                let totalLikePost = await PostLike.findAll({ where: { post_id: allPosts[i].id } })
                                let favouritePost = await PostFavourite.findAll({ where: { post_id: allPosts[i].id } })
    
                                allPosts[i].dataValues.totalPostComments = totalPostcomment?.length || 0;
                                allPosts[i].dataValues.totalRePost = totalRePost?.length || 0;
                                allPosts[i].dataValues.totalLikePost = totalLikePost?.length || 0;
                                allPosts[i].dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0;
    
                                allPosts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                                allPosts[i].dataValues.rePostCount = rePostCount?.length || 0
                            }
    
                            allPosts[i].user.dataValues.followers = followers?.length || 0
                            allPosts[i].user.dataValues.followings = followings?.length || 0
                            allPosts[i].user.dataValues.totalPost = _posts?.length || 0
                            allPosts[i].user.dataValues.totalLikes = likes?.length || 0;

                            allPosts[i].user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
                        }
    
                    }

                }
            
            
                return await Helper.successResponseWithData(res, 'posts_fetched', 'Posts has been fetched successfully', allPosts?.length > 0 ? allPosts : []);
            
            } else if (data.type == 2) {

                // Define a function to generate a random offset
                // function getRandomOffset(totalPosts, limit) {
                //     // Calculate the number of full batches
                //     const fullBatches = Math.floor(totalPosts / limit);
                //     // Calculate the remaining posts after the last full batch
                //     const remainingPosts = totalPosts % limit;
                    
                //     // Generate a random batch number between 0 and the number of full batches
                //     const randomBatch = Math.floor(Math.random() * (fullBatches + (remainingPosts > 0 ? 1 : 0)));
                    
                //     // Calculate the offset based on the random batch
                //     let randomOffset = randomBatch * limit;
                    
                //     // If there are remaining posts and the random batch is the last batch, adjust the offset
                //     if (randomBatch === fullBatches && remainingPosts > 0) {
                //         randomOffset += Math.floor(Math.random() * (remainingPosts - limit + 1));
                //     }
                
                //     return randomOffset;
                // }

               // Define postIndices array outside the function to maintain state
                let postIndices = [];

                async function getRandomOffset(totalPosts, limit) {
                    // If postIndices array is empty, generate a new shuffled array
                
                    if (postIndices.length === 0) {
                        postIndices = Array.from({ length: totalPosts }, (_, i) => i);
                        for (let i = postIndices.length - 1; i > 0; i--) {
                            const j = Math.floor(Math.random() * (i + 1));
                            [postIndices[i], postIndices[j]] = [postIndices[j], postIndices[i]];
                        }
                    }

                    // If all posts have been fetched, reset the postIndices array
                    if (postIndices.length === 0) {
                        postIndices = Array.from({ length: totalPosts }, (_, i) => i);
                        for (let i = postIndices.length - 1; i > 0; i--) {
                            const j = Math.floor(Math.random() * (i + 1));
                            [postIndices[i], postIndices[j]] = [postIndices[j], postIndices[i]];
                        }
                    }

                    // Take the required number of indices as offset and remove them from the array
                    const randomOffsetIndices = postIndices.splice(0, limit);

                    // Calculate the offset based on the limit
                    const randomOffset = randomOffsetIndices.map(index => index * limit);

                    // Return a random number within the range of totalPosts
                    return Math.floor(Math.random() * (totalPosts - limit));
                }

                // Assuming `Post` is your Sequelize model
                let totalPosts = await Post.count(); // Count total number of posts
                let randomOffset = await getRandomOffset(totalPosts, data?.limit || 10);


             
                let posts = await Post.findAll({
                    include: [
                        {
                            model: HashTagPost,
                            as: 'hashTags',
                            required: false,
                            include: [
                                {
                                    model: HashTag,
                                    as: 'hashtag',
                                    required: false
                                }
                            ]
                        }, 
                        {
                            model: PostLike,
                            as: 'likePost',
                            required: false,
                            separate: true, // Fetch likes separately
                            include: [
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'email','username']
                                }
                            ]
                        }, 
                        {
                            model: PostComment,
                            as: 'comment',
                            required: false,
                            separate: true, // Fetch comments separately
                            include: [
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'email', 'device', 'device_token','username']
                                }
                            ]
                        },
                        {
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id', 'first_name', 'device', 'device_token','username']
                        }
                    ],
                    limit: data?.limit || 10,
                    // offset: data?.offset || 0,
                    offset: randomOffset,
                    subQuery: false,
                    order: [['createdAt', 'DESC']]
                });
                
               
                let is_liked = 0;
                let checkFollow;
                if (posts.length > 0) {
                    
                    for (let i = 0; i < posts.length; i++) {
                    console.log("cghec --------------------------------------------------------------",posts[i].id)
                    let followers = await Follower.findAll({ where: { receiver_id: posts[i].user_id } });
                    let followings = await Follower.findAll({ where: { sender_id: posts[i].user_id } });

                    let _posts = await Post.findAll({ where: { user_id: posts[i].user_id } });
                    let likes = await PostLike.findAll({ where: { user_id: posts[i].user_id } });
                    let profilePic = await User.findAll({where:{id:posts[i].user_id}})
                    
                    if (posts[i].id != null) {
                    let totalPostcomment = await PostComment.findAll({ where: { post_id: posts[i].id } });
                    let totalRePost = await Repost.findAll({ where: { post_id: posts[i].id } });
                    let totalLikePost = await PostLike.findAll({ where: { post_id: posts[i].id } })
                    let favouritePost = await PostFavourite.findAll({ where: { post_id: posts[i].id } })
                           
                        
                    if (token) {
                    is_liked = await PostLike.findAll({ where: {post_id:posts[i].id,user_id:userId} });
                    
                    }
                    if (userId) {
                    checkFollow = await Follower.findAll({ where: { receiver_id: posts[i].user_id, sender_id: userId } });
                    }
                            
                    let rePostCount = await Repost.findAll({ where: { post_id: posts[i].id } });

                    posts[i].dataValues.video_comment_count = totalPostcomment?.length || 0;
                    posts[i].dataValues.totalRePost = totalRePost?.length || 0;
                    posts[i].dataValues.like_count = totalLikePost?.length || 0;
                    posts[i].dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0;


                    posts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0

                    posts[i].dataValues.rePostCount = rePostCount?.length || 0
                    }

                    posts[i].user.dataValues.followers = followers?.length || 0
                    posts[i].user.dataValues.followings = followings?.length || 0
                    posts[i].user.dataValues.totalPost = _posts?.length || 0
                    posts[i].user.dataValues.totalLikes = likes?.length || 0
                    posts[i].user.dataValues.profile_pic = profilePic[0].dataValues.profile_pic

                    posts[i].user.dataValues.button = checkFollow?.length ? "Following" :"Follow"

                    posts[i].dataValues.video_hls = "https://vod.api.video/vod/"+posts[i].dataValues.old_video_id+"/hls/manifest.m3u8";
                    //console.log(posts);
                    }
                }


                // if (posts.length > 0) {
                //     let userIds = posts.map(post => post.user_id);
                //     let postIds = posts.map(post => post.id);
                
                //     let [followers, followings, _posts, likes, profilePics, totalPostcomments, totalRePosts, totalLikePosts, favouritePosts, isLiked, checkFollow, rePostCounts] = await Promise.all([
                //         Follower.findAll({ where: { receiver_id: userIds } }),
                //         Follower.findAll({ where: { sender_id: userIds } }),
                //         Post.findAll({ where: { user_id: userIds } }),
                //         PostLike.findAll({ where: { user_id: userIds } }),
                //         User.findAll({ where: { id: userIds }, attributes: ['id', 'profile_pic'] }),
                //         PostComment.findAll({ where: { post_id: postIds } }),
                //         Repost.findAll({ where: { post_id: postIds } }),
                //         PostLike.findAll({ where: { post_id: postIds } }),
                //         PostFavourite.findAll({ where: { post_id: postIds } }),
                //         PostLike.findAll({ where: { post_id: postIds, user_id: userId } }),
                //         Follower.findAll({ where: { receiver_id: userIds, sender_id: userId } }),
                //         Repost.findAll({ where: { post_id: postIds } })
                //     ]);
                
                //     for (let i = 0; i < posts.length; i++) {
                //         posts[i].user.dataValues.followers = followers.filter(follower => follower.receiver_id === posts[i].user_id).length;
                //         posts[i].user.dataValues.followings = followings.filter(following => following.sender_id === posts[i].user_id).length;
                //         posts[i].user.dataValues.totalPost = _posts.filter(post => post.user_id === posts[i].user_id).length;
                //         posts[i].user.dataValues.totalLikes = likes.filter(like => like.user_id === posts[i].user_id).length;
                //         posts[i].user.dataValues.profile_pic = profilePics.find(pic => pic.id === posts[i].user_id)?.profile_pic || null;
                //         posts[i].user.dataValues.button = checkFollow.find(follow => follow.receiver_id === posts[i].user_id) ? "Following" : "Follow";
                
                //         posts[i].dataValues.video_comment_count = totalPostcomments.filter(comment => comment.post_id === posts[i].id).length;
                //         posts[i].dataValues.totalRePost = totalRePosts.filter(repost => repost.post_id === posts[i].id).length;
                //         posts[i].dataValues.like_count = totalLikePosts.filter(like => like.post_id === posts[i].id).length;
                //         posts[i].dataValues.is_favourite = favouritePosts.find(favourite => favourite.post_id === posts[i].id) ? 1 : 0;
                //         posts[i].dataValues.is_like = isLiked.find(like => like.post_id === posts[i].id) ? 1 : 0;
                //         posts[i].dataValues.rePostCount = rePostCounts.filter(repost => repost.post_id === posts[i].id).length;
                //         posts[i].dataValues.video_hls = "https://vod.api.video/vod/" + posts[i].dataValues.old_video_id + "/hls/manifest.m3u8";
                //     }
                // }

                return await Helper.successResponseWithData(res, 'user_id_req', 'Posts has been fetched successfully', posts?.length > 0 ? posts : []);
            } else { return await Helper.ErrorResponse(res, 'type_not_valid', 'type not acceptable') }
        } catch (error) {
            console.log("______________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },

    /**
    * Developer => Prince
    * Function fetchUserPost
    * 
    */
    fetchUserPost: async (req, res) => {
        try {

            let data = req.body;
            let user_id = req.AuthUser.id;

            let userPosts = await Post.findAll({
                include: [{
                    model: HashTagPost,
                    as: 'hashTags',
                    required: false,
                    include: [{
                        model: HashTag,
                        as: 'hashtag',
                        required: false
                    }]
                }, {
                    model: PostLike,
                    as: 'likePost',
                    required: false,
                    include: [{
                        model: User,
                        as: 'user',
                        required: false,
                        attributes: ['id', 'first_name', 'email','username']
                    }]
                }, {
                    model: PostComment,
                    as: 'comment',
                    required: false,
                    include: [{
                        model: User,
                        as: 'user',
                        required: false,
                        attributes: ['id', 'first_name', 'email', 'device', 'device_token','username']
                    }]
                },
                {
                    model: User,
                    as: 'user',
                    required: false,
                    attributes: ['id', 'first_name', 'device', 'device_token','username']
                }],
                where: { user_id: user_id },
                order: [['createdAt', 'DESC']],
                limit: data?.limit || 10,
                offset: data?.offset || 0
            });

            let followers = await Follower.findAll({ where: { receiver_id: user_id } });
            let followings = await Follower.findAll({ where: { sender_id: user_id } });
            let posts = await Post.findAll({ where: { user_id: user_id } });
            let likes = await PostLike.findAll({ where: { user_id: user_id } });
            const privacyDetails = await PrivacySetting.findOne({
                where: {
                    user_id: user_id
                }
            });
            let privacySetting = {};
            if(privacyDetails){
                privacySetting = {
                    videos_download: privacyDetails.dataValues.videos_download,
                    direct_message: privacyDetails.dataValues.direct_message,
                    duet: privacyDetails.dataValues.duet,
                    liked_videos: privacyDetails.dataValues.liked_videos,
                    video_comment: privacyDetails.dataValues.video_comment,
                    direct_messages: privacyDetails.dataValues.direct_messages,
                }
            }

            await userPosts?.map((items) => {
                items.dataValues.followers_count = followers?.length,
                    items.dataValues.following_count = followings?.length,
                    items.dataValues.likes_count = items.dataValues.likePost?.length,
                    items.dataValues.video_count = posts?.length,
                    items.dataValues.privacySetting = privacySetting
            })
            



            return await Helper.successResponseWithData(res, 'fetch_user_post', 'User post has been fetched successfully', userPosts);
        } catch (error) {
            console.log("_____________________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    /**
    * Developer => Prince
    * Function postsByUserId
    * 
    */
    postsByUserId: async (req, res) => {

        try {
            let data = req.body;

            //get all repost
            if (data.type == "repost") {
                let repost = await Repost.findAll({
                    where: { user_id: req.AuthUser.id },
                    limit: data?.limit || 10,
                    offset: data?.offset || 0,
                });
                let RepostResult = "";
                let postLenght = repost.length;
                if (repost.length > 0) {
                    for (let i = 0; i < postLenght; i++) {
                        if (repost[i].post_id != null) {
                            RepostResult = await Post.findAll({
                                include: [{
                                    model: HashTagPost,
                                    as: 'hashTags',
                                    required: false,
                                    include: [{
                                        model: HashTag,
                                        as: 'hashtag',
                                        required: false
                                    }]
                                }, {
                                    model: PostLike,
                                    as: 'likePost',
                                    required: false,
                                    include: [{
                                        model: User,
                                        as: 'user',
                                        required: false,
                                        attributes: ['id', 'first_name', 'email', 'username']
                                    }]
                                }, {
                                    model: PostComment,
                                    as: 'comment',
                                    required: false,
                                    include: [{
                                        model: User,
                                        as: 'user',
                                        required: false,
                                        attributes: ['id', 'first_name', 'email', 'device', 'device_token', 'username']
                                    }]
                                },
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic', 'username']
                                }],
                                limit: data?.limit || 10,
                                offset: data?.offset || 0,
                                order: [['createdAt', 'DESC']],
                                where: { id: repost[i].post_id }
                            })

                        }
                    }
                }
                return await Helper.successResponseWithData(res, 'repost_fetched', 'Auth Re-posts has been fetched successfully', RepostResult);
            }

            let user_id = req.AuthUser.id;
            let UserFollow
            let posts;
            if (data.user_id) {
                UserFollow = await Follower.findOne({ where: { sender_id: req.AuthUser.id, receiver_id: data.user_id } });

                user_id = data.user_id
            }

            if (!user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User id is required')
            }
            if (UserFollow) {
                posts = await Post.findAll({
                    where: {
                        user_id: user_id,
                        status: true,
                        // [Op.or]: [
                        //     { privacy_type: 'public' },
                        //     { privacy_type: null }
                        // ]
                    },
                    include: [{
                        model: HashTagPost,
                        as: 'hashTags',
                        required: false,
                        seperate: true,
                        include: [{
                            model: HashTag,
                            as: 'hashtag',
                            required: false
                        }]
                    }, {
                        model: PostLike,
                        as: 'likePost',
                        required: false,
                        seperate: true,
                        include: [{
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id', 'first_name', 'email', 'username']
                        }]
                    }, {
                        model: PostComment,
                        as: 'comment',
                        required: false,
                        seperate: true,
                        include: [{
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id', 'first_name', 'email', 'device', 'device_token', 'username']
                        }]
                    },
                    {
                        model: Sound,
                        as: 'sound',
                        required: false,
                        // separate: true, // Fetch comments separately
                    },
                    {
                        model: User,
                        as: 'user',
                        required: false,
                        attributes: ['id', 'first_name', 'device', 'device_token', 'last_name', 'username', 'profile_pic', 'username']
                    }],
                    order: [['createdAt', 'DESC']],
                    limit: data?.limit || 10,
                    offset: data?.offset || 0,

                });
            }
            else {
                posts = await Post.findAll({
                    where: {
                        user_id: user_id,
                        status: true,
                        [Op.or]: [
                            { privacy_type: 'public' },
                            { privacy_type: null }
                        ]
                    },
                    include: [{
                        model: HashTagPost,
                        as: 'hashTags',
                        required: false,
                        seperate: true,
                        include: [{
                            model: HashTag,
                            as: 'hashtag',
                            required: false
                        }]
                    }, {
                        model: PostLike,
                        as: 'likePost',
                        required: false,
                        seperate: true,
                        include: [{
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id', 'first_name', 'email', 'username']
                        }]
                    }, {
                        model: PostComment,
                        as: 'comment',
                        required: false,
                        seperate: true,
                        include: [{
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id', 'first_name', 'email', 'device', 'device_token', 'username']
                        }]
                    },
                    {
                        model: Sound,
                        as: 'sound',
                        required: false,
                        // separate: true, // Fetch comments separately
                    },
                    {
                        model: User,
                        as: 'user',
                        required: false,
                        attributes: ['id', 'first_name', 'device', 'device_token', 'last_name', 'username', 'profile_pic', 'username']
                    }],
                    order: [['createdAt', 'DESC']],
                    limit: data?.limit || 10,
                    offset: data?.offset || 0,

                });
            }
            // const filteredPosts = posts.filter(item => item.status === true);

            for (let i = 0; i < posts.length; i++) {

                let check_fav = await PostFavourite.findAll({ where: { user_id: req.AuthUser.id, post_id: posts[i].id } })
                let is_liked = await PostLike.findAll({ where: { post_id: posts[i].id, user_id: req.AuthUser.id } });

                let likePost = await PostLike.findAll({ where: { post_id: posts[i].id } })
                let commentPost = await PostComment.findAll({ where: { post_id: posts[i].id } });
                let favoritePost = await PostFavourite.findAll({ where: { post_id: posts[i].id } });
                // let soundFav = await SoundFavourite.findAll({ where: { sound_id: posts[i].dataValues.sound.id, user_id: posts[i].user_id } }) 

                // let soundCount = await Post.findAll({ where: { sound_id: posts[i].dataValues.sound.id} })
                let soundCount;
                let soundFav;

                if (posts[i] && posts[i].sound && posts[i].sound.id) {
                    soundFav = await SoundFavourite.findAll({ where: { sound_id: posts[i].dataValues.sound.id, user_id: posts[i].user_id } })
                }
                console.log('sosususnnsnsns', posts[i].sound)
                if (posts[i] && posts[i].sound && posts[i].sound.id) {
                    soundCount = await Post.findAll({ where: { sound_id: posts[i].dataValues.sound.id } })
                }
                const privacyDetails = await PrivacySetting.findOne({
                    where: {
                        user_id: posts[i].user_id
                    }
                });
                let privacySetting = {};
                if (privacyDetails) {
                    privacySetting = {
                        videos_download: privacyDetails.dataValues.videos_download,
                        direct_message: privacyDetails.dataValues.direct_message,
                        duet: privacyDetails.dataValues.duet,
                        liked_videos: privacyDetails.dataValues.liked_videos,
                        video_comment: privacyDetails.dataValues.video_comment,
                        direct_messages: privacyDetails.dataValues.direct_messages,
                    }
                }

                posts[i].dataValues.privacySetting = privacySetting;
                posts[i].dataValues.is_favourite = check_fav?.length > 0 ? 1 : 0;

                posts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0

                posts[i].dataValues.like_count = likePost?.length ? likePost?.length : 0
                posts[i].dataValues.video_comment_count = commentPost?.length ? commentPost.length : 0
                posts[i].dataValues.favourite_count = favoritePost?.length ? favoritePost.length : 0
                posts[i].dataValues.pin = 0;

                if (posts[i].dataValues.sound !== null) {
                    posts[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                    posts[i].dataValues.sound.dataValues.video_count = soundCount?.length || 0
                    posts[i].dataValues.sound.audio = process.env.Sound_URL + '/' + posts[i].dataValues.sound.audio
                }
                else if (posts[i].dataValues.sound === null) {
                    posts[i].dataValues.sound = {}
                }

                let followers = await Follower.findAll({ where: { receiver_id: posts[i].user_id } });
                let followings = await Follower.findAll({ where: { sender_id: posts[i].user_id } });
                checkFollow = await Follower.findAll({ where: { receiver_id: posts[i].user_id, sender_id: req.AuthUser.id } });

                if (posts[i].user != null) {
                    posts[i].user.dataValues.followers = followers?.length || 0
                    posts[i].user.dataValues.followings = followings?.length || 0
                    posts[i].user.dataValues.button = checkFollow?.length ? "Following" : "Follow"
                }
            }



            if (!posts) {
                return await Helper.ErrorResponse(res, 'post_not_found', 'Posts not available')
            }
            return await Helper.successResponseWithData(res, 'post_found', 'Posts retrieved  successfully', posts);

        } catch (error) {
            console.log('erororo=======', error)
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    draftPostsByUserId: async (req, res) => {

        try {
            let data = req.body;
            
            //get all repost
            if (data.type == "repost") {
                let repost = await Repost.findAll({
                    where: { user_id: req.AuthUser.id },
                    limit: data?.limit || 10,
                    offset: data?.offset || 0,
                });
                let RepostResult = "";
                let postLenght = repost.length;
                if (repost.length > 0) {
                    for (let i = 0; i < postLenght; i++) {
                        if (repost[i].post_id != null) {
                            RepostResult = await Post.findAll({
                                include: [{
                                    model: HashTagPost,
                                    as: 'hashTags',
                                    required: false,
                                    include: [{
                                        model: HashTag,
                                        as: 'hashtag',
                                        required: false
                                    }]
                                }, {
                                    model: PostLike,
                                    as: 'likePost',
                                    required: false,
                                    include: [{
                                        model: User,
                                        as: 'user',
                                        required: false,
                                        attributes: ['id', 'first_name', 'email','username']
                                    }]
                                }, {
                                    model: PostComment,
                                    as: 'comment',
                                    required: false,
                                    include: [{
                                        model: User,
                                        as: 'user',
                                        required: false,
                                        attributes: ['id', 'first_name', 'email', 'device', 'device_token','username']
                                    }]
                                },
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic','username']
                                }],
                                limit: data?.limit || 10,
                                offset: data?.offset || 0,
                                order: [['createdAt', 'DESC']],
                                where: { id: repost[i].post_id }
                            })

                        }
                    }
                }
                return await Helper.successResponseWithData(res, 'repost_fetched', 'Auth Re-posts has been fetched successfully', RepostResult);
            }

            let user_id = req.AuthUser.id;

            if (data.user_id) {
                user_id = data.user_id
            }

            if (!user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User id is required')
            }

            let posts = await Post.findAll({
                where: {
                    user_id: user_id
                },
                include: [{
                    model: HashTagPost,
                    as: 'hashTags',
                    required: false,
                    include: [{
                        model: HashTag,
                        as: 'hashtag',
                        required: false
                    }]
                }, {
                    model: PostLike,
                    as: 'likePost',
                    required: false,
                    include: [{
                        model: User,
                        as: 'user',
                        required: false,
                        attributes: ['id', 'first_name', 'email','username']
                    }]
                }, {
                    model: PostComment,
                    as: 'comment',
                    required: false,
                    include: [{
                        model: User,
                        as: 'user',
                        required: false,
                        attributes: ['id', 'first_name', 'email', 'device', 'device_token','username']
                    }]
                },
                {
                    model: Sound,
                    as: 'sound',
                    required: false,
                    // separate: true, // Fetch comments separately
                },
                {
                    model: User,
                    as: 'user',
                    required: false,
                    attributes: ['id', 'first_name', 'device', 'device_token','last_name','username','profile_pic','username']
                }],
                order: [['createdAt', 'DESC']],
                limit: data?.limit || 10,
                offset: data?.offset || 0,

            });
            
           
            for (let i = 0; i < posts.length; i++) {
                
                let check_fav = await PostFavourite.findAll({ where: { user_id: req.AuthUser.id, post_id: posts[i].id } })
                let is_liked = await PostLike.findAll({ where: { post_id: posts[i].id, user_id: req.AuthUser.id } });

                let likePost = await PostLike.findAll({ where: { post_id:posts[i].id } })
                let commentPost = await PostComment.findAll({ where: { post_id:posts[i].id } });
                let favoritePost = await PostFavourite.findAll({ where: { post_id:posts[i].id  } });
                let soundFav = await SoundFavourite.findAll({ where: { sound_id: posts[i].dataValues.sound.id, user_id: posts[i].user_id } }) 

                let soundCount = await Post.findAll({ where: { sound_id: posts[i].dataValues.sound.id} })
                const privacyDetails = await PrivacySetting.findOne({
                    where: {
                        user_id: posts[i].user_id
                    }
                });
                let privacySetting = {};
                if(privacyDetails){
                    privacySetting = {
                        videos_download: privacyDetails.dataValues.videos_download,
                        direct_message: privacyDetails.dataValues.direct_message,
                        duet: privacyDetails.dataValues.duet,
                        liked_videos: privacyDetails.dataValues.liked_videos,
                        video_comment: privacyDetails.dataValues.video_comment,
                        direct_messages: privacyDetails.dataValues.direct_messages,
                    }
                }

                posts[i].dataValues.privacySetting = privacySetting;

               
                posts[i].dataValues.is_favourite = check_fav?.length > 0 ? 1 : 0;

                posts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                
                posts[i].dataValues.like_count = likePost?.length ? likePost?.length :0
                posts[i].dataValues.video_comment_count = commentPost?.length ? commentPost.length :0
                posts[i].dataValues.favourite_count = favoritePost?.length ?favoritePost.length :0
                posts[i].dataValues.pin = 0 ;
                posts[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                posts[i].dataValues.sound.dataValues.video_count = soundCount?.length || 0 
                if (posts[i].dataValues.sound !== null) {
                    posts[i].dataValues.sound.audio = process.env.Sound_URL + '/' + posts[i].dataValues.sound.audio
                }
                else if (posts[i].dataValues.sound === null) {
                    posts[i].dataValues.sound = {}
                }
            }

           
            const filteredPosts = posts.filter(item => item.status === false);
            if (!posts) {
                return await Helper.ErrorResponse(res, 'post_not_found', 'Posts not available')
            }
            return await Helper.successResponseWithData(res, 'post_found', 'Draft Posts retrieved  successfully', filteredPosts);

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    /**
    * Developer => Anshuman
    * Function fetchPostById
    * 
    */
    fetchPostById: async (req, res) => {
        try {
            let post_id = req.body.post_id;
            if (!post_id) {
                return await Helper.ErrorResponse(res, 'post_id_req', 'Post id is required')
            }

            let posts = await Post.findOne({
                where: {
                    id: post_id
                },
                include: [
                    {
                        model: User,
                        as: 'user',
                        required: false,
                        attributes: ['id', 'first_name', 'last_name', 'profile_pic', 'device', 'device_token','username']
                    },
                    {
                        model: Sound,
                        as: 'sound',
                        required: false,
                        // separate: true, // Fetch comments separately
                    },
                ],
            });
            if (post_id != null) {
                let favouritePost = await PostFavourite.findAll({ where: { post_id: post_id ,user_id:req.AuthUser.id} })
                let is_liked = await PostLike.findAll({ where: { post_id: post_id ,user_id:req.AuthUser.id} });
                let likePost = await PostLike.findAll({ where: { post_id:post_id } })
                let commentPost = await PostComment.findAll({ where: { post_id:post_id } });
                let favoritePost = await PostFavourite.findAll({ where: { post_id:post_id  } });
                let soundCount;
                let soundFav;
                
                if(posts && posts.sound && posts.sound.id ){
                    soundFav = await SoundFavourite.findAll({ where: { sound_id: posts.sound.id, user_id: posts.user_id } })
                    posts.dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                }
                if(posts && posts.sound && posts.sound.id ){
                    soundCount = await Post.findAll({ where: { sound_id: posts.sound.id} })
                }

                const privacyDetails = await PrivacySetting.findOne({
                    where: {
                        user_id: posts.user_id
                    }
                });
                let privacySetting = {};
                if(privacyDetails){
                    privacySetting = {
                        videos_download: privacyDetails.dataValues.videos_download,
                        direct_message: privacyDetails.dataValues.direct_message,
                        duet: privacyDetails.dataValues.duet,
                        liked_videos: privacyDetails.dataValues.liked_videos,
                        video_comment: privacyDetails.dataValues.video_comment,
                        direct_messages: privacyDetails.dataValues.direct_messages,
                    }
                }

                posts.dataValues.privacySetting = privacySetting;
                posts.dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0;
                posts.dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                posts.dataValues.like_count = likePost?.length ? likePost?.length :0
                posts.dataValues.video_comment_count = commentPost?.length ? commentPost.length :0
                posts.dataValues.favourite_count = favoritePost?.length ?favoritePost.length :0

                if (posts.dataValues.sound !== null) {
                    posts.dataValues.sound.audio = process.env.Sound_URL + '/' + posts.dataValues.sound.audio,
                    posts.dataValues.sound.dataValues.video_count = soundCount?.length || 0 

                }
                else if (posts.dataValues.sound === null) {
                    posts.dataValues.sound = {}
                }
                let followers = await Follower.findAll({ where: { receiver_id: posts.user_id } });
                let followings = await Follower.findAll({ where: { sender_id: posts.user_id } });
                checkFollow = await Follower.findAll({ where: { receiver_id: posts.user_id, sender_id: req.AuthUser.id } });

                if(posts.user != null){
                    posts.user.dataValues.followers = followers?.length || 0
                    posts.user.dataValues.followings = followings?.length || 0
                    posts.user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
    
                    // allPosts[i].user.dataValues.totalPost = _posts?.length || 0
                    // allPosts[i].user.dataValues.totalLikes = likes?.length || 0;
                }
                
            }
            if (!posts) {
                return await Helper.ErrorResponse(res, 'post_not_found', 'Posts not available')
            }
            return await Helper.successResponseWithData(res, 'post_found', 'Post found successfully', posts);


        } catch (error) {
            console.log('erroroo=========',error)
            return await Helper.ErrorResponse(res, 'internal_serverm_error', error.message);
        }
    },
    /**
    * Developer => Prince
    * Function like post
    * 
    */
    likePost: async (req, res) => {
        try {
            let data = req.body;
            
            let checkPostExits = await Post.findOne({where:{id:data.post_id}});
            if (!checkPostExits) { return await Helper.ErrorResponse(res, 'post_not_found', 'Post not found') }
            let deviceToken = await User.findOne({ attributes: ['id', 'device', 'device_token', 'first_name', 'email', 'is_notification'], where: { id: checkPostExits.user_id } });


            let checkLikesOrNot = await PostLike.findAll({ where: { post_id: data.post_id, user_id: req.AuthUser.id } });
            console.log("like post",checkLikesOrNot.length)
            if (checkLikesOrNot.length > 0) {
                let dislike = await PostLike.destroy({ where: { user_id: req.AuthUser.id, post_id: data.post_id } })
                //delete notification entry as per table
                await Notification.destroy({ where: { sender_id: req.AuthUser.id } });
                let likesCount = await PostLike.findAll({ where:{post_id: data.post_id} });
                await Post.update({likes:likesCount.length},{where:{id:data.post_id}})
                if (dislike) { return await Helper.SuccessResponse(res, 'post_dislike_8465', 'Post has been dislike successfully'); }
            } else {
                console.log("req.AuthUser?.first_name",req.AuthUser?.username)
                // if (deviceToken?.device_token?.length > 60 && deviceToken.device_token !="" && deviceToken.id != req.AuthUser.id) {
                //     if(+deviceToken?.is_notification==1){
                //         let title='Like Post'
                //         let type = 'LikePost';

                let likePost = await PostLike.create({ user_id: req.AuthUser.id, post_id: data.post_id });
                let points = await TransactionHistory.findAll({where:{user_id:req.AuthUser.id,post_id:data.post_id,type:'like_post'}});
                // update like count on post table 
                let likesCount = await PostLike.findAll({ where:{post_id: data.post_id} });
                await Post.update({likes:likesCount.length},{where:{id:data.post_id}})
                
                if(points.length === 0){
                await TransactionHistory.create({user_id:req.AuthUser.id,post_id:data.post_id,type:"like_post",Remarks:`like on your post.`,points:1})
                }
                let point = await TransactionHistory.findAll({where:{user_id:req.AuthUser.id,type:'like_post'}});
                await User.update({like_points:point.length},{where:{id:req.AuthUser.id}})

                let pushNotfSettingDetail = await PushNotification.findOne({
                    where: {
                        id: checkPostExits.user_id
                    }
                });
               console.log('pushsshsh=============',pushNotfSettingDetail)
                if (pushNotfSettingDetail && pushNotfSettingDetail.likes == 1){
                    if(checkPostExits.user_id != req.AuthUser?.id){
                        var message = `${req.AuthUser?.username} has liked your post`;
                        let payload = {
                            unique_id: req.AuthUser?.unique_id,
                            username: req.AuthUser?.username,
                            user_id: req.AuthUser.id,
                            sender_id: req.AuthUser.id,
                            receiver_id: checkPostExits.user_id,
                            video_id: data.post_id,
                            image: req.AuthUser?.profile_pic,
                            title: message,
                            type: 'likePost',
                        }
                        //         var video_id=data.post_id;
                        //       await Helper.sendPushNotification(deviceToken.device_token,process.env.APP_NAME,message,'',type);
                        //         //make entry in db
                        //         //creation the notify data
                        //         await Notification.create({sender_id:req.AuthUser.id,receiver_id:deviceToken.id,title:title,type:type,read:0,post_id:data.post_id});
                        //     }
                        // }
                        let checkNotifOn = await PushNotification.findOne({where:{id:req.AuthUser.id}})
                        console.log("push notf payload=========,",payload)
                        // if(checkNotifOn && checkPostExits.user_id != req.AuthUser.id &&  checkNotifOn.likes === 1){
                        await Helper.sendPushNotification2(req, checkPostExits.user_id, process.env.APP_NAME, message, payload);
                        await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:checkPostExits.user_id,message:message,type:"Post"})
                    }
                }
                return await Helper.successResponseWithData(res, 'post_like_5874', 'Post has been liked successfully', likePost);
            }
        } catch (error) {
            console.log("__________________________________error", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    /**
  * Developer => Prince
  * Function like post
  * 
  */
    deletePost: async (req, res) => {
        try {
            let data = req.body;
            
            if (!data.post_id) { return await Helper.ErrorResponse(res, 'post_id_req', 'post_id is required') }
            let checkPostExist = await Post.findOne({ where: { id: data.post_id, user_id: req.AuthUser.id } });
            let checkUser = await User.findOne({where:{id:req.AuthUser.id}})
           
            if (!checkPostExist) { return await Helper.ErrorResponse(res, 'post_not_found', 'post not found') }
            await PostLike.destroy({ where: { post_id: data.post_id } });
            await PostComment.destroy({ where: { post_id: data.post_id} });
            await PostFavourite.destroy({ where: { post_id: data.post_id} });
            // await TransactionHistory.destroy({ where: { post_id: data.post_id} });
            // await User.update({uploadPost_points:checkUser.uploadPost_points - 1},{where:{id:req.AuthUser.id}})
            
           
            let deletePost = await Post.destroy({ where: { id: data.post_id } });
            let getHashTag = await HashTagPost.findAll({where:{post_id:data.post_id}})
                       
            if(getHashTag !==null){
            getHashTag.map(async(id)=> {
            let totalPost = await HashTagPost.findAll({where:{hashtag_id:id.hashtag_id}})
            // console.log("check totla post ",totalPost.length)
            
            await HashTagPost.destroy({ where: { post_id: data.post_id} });
            if(totalPost.length ===1){
                console.log("inside hahstga post ength one ------------------------------------------")
                await HashTag.destroy({ where: { id: id.hashtag_id} });
            }
            })
            
        }
            if (deletePost) { return await Helper.SuccessResponse(res, 'delete_post', 'Post has been deleted successfully') }
        } catch (error) {
            console.log("____________________________________erorr is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    /**
   * Developer => Prince
   * Function like post
   * 
   */
    fetchUserLikePosts: async (req, res) => {
        try {
            let data = req.body;

            const postLike = await PostLike.findAll({
                where: { user_id: data.user_id },
                include: [{
                    model: Post,
                    as: 'post',
                    required: false,
                    //where:{user_id:data.user_id},
                    //attributes: ['id', 'user_id', 'description'],
                    include: [{
                        model: User,
                        as: 'user',
                        required: false,
                    },
                    {
                        model: Sound,
                        as: 'sound',
                        required: false,
                        // separate: true, // Fetch comments separately
                    },
                ]
                }],

                order: [['createdAt', 'DESC']],
                limit: data?.limit || 10,
                offset: data?.offset || 0,
            });

            

            if (postLike.length > 0) {
                
                for (let i = 0; i < postLike.length; i++) {
                    if (postLike[i].id != null && postLike[i].post && postLike[i].post.id) {
                        
                        
                        postLike[i].post.dataValues.is_like = 1
                        let totalPostcomment = await PostComment.findAll({ where: { post_id: postLike[i].post.id } });
                        let totalRePost = await Repost.findAll({ where: { post_id: postLike[i].post.id } });
                        let totalLikePost = await PostLike.findAll({ where: { post_id: postLike[i].post.id } })
                        let favouritePost = await PostFavourite.findAll({ where: { post_id: postLike[i].post.id ,user_id:req.AuthUser.id} })
                        let rePostCount = await Repost.findAll({ where: { post_id: postLike[i].post.id } });
                        let favoritePost = await PostFavourite.findAll({ where: { post_id: postLike[i].post.id } });

                        const privacyDetails = await PrivacySetting.findOne({
                            where: {
                                user_id: postLike[i].user_id
                            }
                        });
                        let privacySetting = {};
                        if(privacyDetails){
                            privacySetting = {
                                videos_download: privacyDetails.dataValues.videos_download,
                                direct_message: privacyDetails.dataValues.direct_message,
                                duet: privacyDetails.dataValues.duet,
                                liked_videos: privacyDetails.dataValues.liked_videos,
                                video_comment: privacyDetails.dataValues.video_comment,
                                direct_messages: privacyDetails.dataValues.direct_messages,
                            }
                        }
        
                        postLike[i].post.dataValues.privacySetting = privacySetting;
        
                        postLike[i].post.dataValues.video_comment_count = totalPostcomment?.length || 0;
                        postLike[i].post.dataValues.totalRePost = totalRePost?.length || 0;
                        postLike[i].post.dataValues.like_count = totalLikePost?.length || 0;
                        postLike[i].post.dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0
                        postLike[i].post.dataValues.rePostCount = rePostCount?.length || 0
                        postLike[i].post.dataValues.favourite_count = favoritePost?.length ? favoritePost.length : 0

                        // let soundFav = await SoundFavourite.findAll({ where: { sound_id: postLike[i].post.sound.id, user_id: postLike[i].user_id } })
                        // postLike[i].post.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;

                        // let soundCount = await Post.findAll({ where: { sound_id: postLike[i].post.sound.id} })
                        let soundCount;
                        let soundFav;
                        
                        if(postLike[i].post && postLike[i].post.sound && postLike[i].post.sound.id ){
                            soundFav = await SoundFavourite.findAll({ where: { sound_id: postLike[i].post.sound.id, user_id: postLike[i].user_id } })
                            postLike[i].post.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                        }
                        if(postLike[i].post && postLike[i].post.sound && postLike[i].post.sound.id ){
                            soundCount = await Post.findAll({ where: { sound_id: postLike[i].post.sound.id} })
                        }

                        if (postLike[i].post.sound !== null) {
                            postLike[i].post.sound.dataValues.video_count = soundCount?.length || 0 
                            postLike[i].post.sound.dataValues.audio = process.env.Sound_URL + '/' + postLike[i].post.sound.dataValues.audio
                        }
                        else if (postLike[i].post.sound === null) {
                            postLike[i].dataValues.sound = {}
                        }
                        let followers = await Follower.findAll({ where: { receiver_id: postLike[i].user_id } });
                        let followings = await Follower.findAll({ where: { sender_id: postLike[i].user_id } });
                        checkFollow = await Follower.findAll({ where: { receiver_id: postLike[i].user_id, sender_id: req.AuthUser.id } });
                        if(postLike[i].post.user != null){
                            postLike[i].post.user.dataValues.followers = followers?.length || 0
                            postLike[i].post.user.dataValues.followings = followings?.length || 0
                            postLike[i].post.user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
                        }
                    }

                }
            }

            return await Helper.successResponseWithData(res, 'post_like_5874', 'Post has been liked successfully', postLike);

        } catch (error) {
            console.log("__________________________________error", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    /**
   * Developer => Prince
   * Function like post
   * 
   */
    createDeleteComment: async (req, res) => {
        try {
            let data = req.body;
            if (!data.type) { return await Helper.ErrorResponse(res, 'type_req', 'type is required for 1 add and 2 for delete') }
            if (data.type == 1) {
                if (!data.post_id) { return await Helper.ErrorResponse(res, 'post_id_req', 'post id is required') }
                let checkPostExists = await Post.findAll({ where: { id: data.post_id } });
                if (!checkPostExists.length > 0) {
                    return await Helper.ErrorResponse(res, 'post_not_found', 'Post not found')
                } else {
                    if (!data.comment) { return await Helper.ErrorResponse(res, 'comment_req', 'Comment is required') }
                    let payload = {
                        user_id: req.AuthUser.id,
                        post_id: data.post_id,
                        comment: data.comment
                    }
                    let comment = await PostComment.create(payload);
                   
                    let checkcomment = ""
                     checkcomment =  await PostComment.findOne({
                        include: [{
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id', 'first_name', 'email', 'profile_pic','username'],
                        }, {
                            model: PostCommentReply,
                            as: 'postCommentReply',
                            required: false,
                            include: [{
                                model: User,
                                as: 'user',
                                required: false,
                                attributes: ['id', 'first_name', 'last_name', 'profile_pic','username']
                            }]
                        }],
                        where: { post_id: data.post_id , id:comment.id},
                        limit: data.limit || 10,
                        offset: data.offset || 0
                    });
                        let checkLikedComment = await PostCommentLike.findAll({ where: { comment_id: checkcomment.dataValues.id } })
                        let totalLikedComment = await PostCommentLike.findAll({ where: { comment_id: checkcomment.dataValues.id } })
                        console.log("check checkLikedComment",checkLikedComment.length,totalLikedComment.length)
        
                        checkcomment.dataValues.isLikedComment = checkLikedComment.length || 0;
                        checkcomment.dataValues.totalLikedComment = totalLikedComment.length || 0;

                        if(checkPostExists[0].user_id != req.AuthUser.id){
                            
                            await TransactionHistory.create({user_id:req.AuthUser.id,post_id:data.post_id,type:"comment_post",Remarks:`commented on your post.`,points:1})
                            let points = await TransactionHistory.findAll({where:{user_id:req.AuthUser.id,post_id:data.post_id,type:'comment_post'}})
                            await User.update({comments_points:points?.length},{where:{id:req.AuthUser.id}})
                            let pushNotfSettingDetail = await PushNotification.findOne({
                                where: {
                                    id: checkPostExists[0].user_id
                                }
                            });
                            let commentCount = await PostComment.findAll({ where: { post_id: data.post_id } });
                            await Post.update({ comments: commentCount.length }, { where: { id: data.post_id } })

                            if (pushNotfSettingDetail && pushNotfSettingDetail.comments == 1){
                                if(checkPostExists[0].user_id != req.AuthUser?.id){
                                    var message = `${req.AuthUser?.username} has commented on your post`;
                                    let payload = {
                                        unique_id: req.AuthUser?.unique_id,
                                        username: req.AuthUser?.username,
                                        user_id: req.AuthUser.id,
                                        sender_id: req.AuthUser.id,
                                        receiver_id: checkPostExists[0].user_id,
                                        video_id: data.post_id,
                                        image: req.AuthUser?.profile_pic,
                                        title: message,
                                        type: 'commentPost',
                                    }
                                    await Helper.sendPushNotification2(req, checkPostExists[0].user_id, process.env.APP_NAME, message, payload);
                                    await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:checkPostExists[0].user_id,message:`${req.AuthUser.username} has commented on your post.`,type:"Post"})
                                }
                            }
                        }
                    if (comment) { return await Helper.successResponseWithData(res, 'comment_create_1254', 'comment has been created successfully', checkcomment); }
                }
            } else if (data.type == 2) {
                if (!data.post_id) { return await Helper.ErrorResponse(res, 'post_id_req', 'post id is required') }
                if (!data.comment_id) { return await Helper.ErrorResponse(res, 'comment_id_req', 'comment id is required') }
                let checkCommentExist = await PostComment.findOne({ where: { id: data.comment_id, post_id: data.post_id } });
                if (checkCommentExist) {
                    await PostComment.destroy({ where: { id: data.comment_id, post_id: data.post_id, user_id: req.AuthUser.id } });
                    return await Helper.SuccessResponse(res, 'comment_deleted', 'Comment has been deleted successfully')
                } else {
                    return await Helper.ErrorResponse(res, 'comment_not_found', 'comment not found')
                }
            } else {
                return await Helper.ErrorResponse(res, 'type_not_accpetable', 'type is not acceptable')
            }
        } catch (error) {
            console.log("_______________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    /**
   * Developer => Prince
   * Function like post
   * 
   */
    searchPost: async (req, res) => {
        try {
            let data = req.body;
            let searchDetails = "";
            let searchValue = data.keyword?.toLowerCase();
            if (data.limit || data.offset) {
                if (!searchValue) { return await Helper.ErrorResponse(res, 'keyword_error_101', 'keyword is required'); }
                searchDetails = await Post.findAll({ // or User.findOne

                    where: {
                        description: {
                            [Op.iLike]: `%${searchValue}%`
                        },
                        limit: data.limit || 10,
                        offset: data.offset || 0,
                    }
                    //attributes: ['id', 'nombre'] // results you want returned
                });

            } else {
                searchDetails = await Post.findAll({ // or User.findOne
                    where: {
                        description: {
                            [Op.iLike]: `%${searchValue}%`
                        }
                    }
                    //attributes: ['id', 'nombre'] // results you want returned
                });
            }
            return await Helper.successResponseWithData(res, 'post_found', 'Post has been searched successfully', searchDetails);
        } catch (error) {
            console.log("_________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)
        }
    },
    /**
   * Developer => Prince
   * Function like post
   * 
   */
    fetchPostComment: async (req, res) => {
        try {
            let data = req.body;
            let comments = "";
            if (!data.post_id) { return await Helper.ErrorResponse(res, 'post_id_req', 'post_id is required') }

            comments = await PostComment.findAll({
                include: [{
                    model: User,
                    as: 'user',
                    required: false,
                    attributes: ['id', 'first_name','last_name','username', 'email', 'profile_pic']
                }, {
                    model: PostCommentReply,
                    as: 'postCommentReply',
                    required: false,
                    include: [{
                        model: User,
                        as: 'user',
                        required: false,
                        attributes: ['id', 'first_name', 'last_name', 'profile_pic','username']
                    }]
                }],
                where: { post_id: data.post_id },
                limit: data.limit || 10,
                offset: data.offset || 0
            });
            for (let i = 0; i < comments.length; i++) {

                let checkLikedComment = await PostCommentLike.findOne({ where: {user_id:req.AuthUser.id, comment_id: comments[i].id } })
                let totalLikedComment = await PostCommentLike.findAll({ where: { comment_id: comments[i].id } })

                comments[i].dataValues.isLikedComment = checkLikedComment ? 1 : 0;
                comments[i].dataValues.totalLikedComment = totalLikedComment.length || 0;


                await comments[i].dataValues.postCommentReply.forEach(async element => {
                    let checkLikedComment = await PostCommentReplyLike.findOne({ where: { comment_reply_id: element.id, user_id: req.AuthUser.id } })
                    let totalLikedComment = await PostCommentReplyLike.findAll({ where: { comment_reply_id: element.id } })
                    element.dataValues.isLikedReplyComment = checkLikedComment ? 1 : 0;
                    element.dataValues.totalLikedReplyComment = totalLikedComment.length || 0;
                });
                //comments[i].dataValues.postCommentReply.totalLikedComment=totalLikedComment.length || 0;
            }
            comments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
            
            return await Helper.successResponseWithData(res, 'post_found', 'Comments has been fetched successfully', comments);
        } catch (error) {
            console.log("__________________________________error", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
     /** 
   * Developer => Prince
   * Function like post
   * 
   */
     likeComment: async (req, res) => {
        try {
            let data = req.body;
            if (!data.comment_id) { return await Helper.ErrorResponse(res, 'comment_id_req', 'comment_id is required') }

            let checkCommentExists = await PostComment.findAll({ where: { id: data.comment_id } });

            if (!checkCommentExists.length > 0) { return await Helper.ErrorResponse(res, 'comment_not_found', 'comment not found') }

            let checkCommentlike = await PostCommentLike.findAll({ where: {user_id:req.AuthUser.id, comment_id: data.comment_id } });
           
            if (!checkCommentlike.length > 0) {
                let likeObj = {
                    user_id: req.AuthUser.id,
                    comment_id: data.comment_id
                }
                let likeComment = await PostCommentLike.create(likeObj);
                if (likeComment) {

                    let pushNotfSettingDetail = await PushNotification.findOne({
                        where: {
                            id: checkCommentExists[0].user_id
                        }
                    });
                    
                    if (pushNotfSettingDetail && pushNotfSettingDetail.likes == 1){
                        if(checkCommentExists[0].user_id != req.AuthUser?.id){
                            var message = `${req.AuthUser?.username} has liked your comment`;
                            let payload = {
                                unique_id: req.AuthUser?.unique_id,
                                username: req.AuthUser?.username,
                                user_id: req.AuthUser.id,
                                sender_id: req.AuthUser.id,
                                receiver_id: checkCommentExists[0].user_id,
                                video_id: checkCommentExists[0].post_id,
                                image: req.AuthUser?.profile_pic,
                                title: message,
                                type: 'commentLike',
                            }
                            await Helper.sendPushNotification2(req, checkCommentExists[0].user_id, process.env.APP_NAME, message, payload);
                            await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:checkCommentExists[0].user_id,message:`${req.AuthUser.username} has liked your comment.`,type:"Post"})
                        }
                    }
                return await Helper.successResponseWithData(res, 'post_fetched', 'post fetched successsfully', likeComment) }
            } else {
                await PostCommentLike.destroy({ where: { comment_id: data.comment_id, user_id: req.AuthUser.id } });
                return await Helper.ErrorResponse(res, 'Unliked_comment', 'Comment has been unliked successfully')
            }

        } catch (error) {
            console.log("_____________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)
        }
    },
     /** 
   * Developer => Prince
   * Function like post
   * 
   */
    postCommentReply: async (req, res) => {
        try {
            let data = req.body;
            if (!data.comment_id) { return await Helper.ErrorResponse(res, 'comment_id_req', 'comment_id is required') }
            if (!data.post_id) { return await Helper.ErrorResponse(res, 'post_id_req', 'post_id is required') }

            let checkCommentExists = await PostComment.findAll({ where: { id: data.comment_id } });
                        
            if (!checkCommentExists.length > 0) { return await Helper.ErrorResponse(res, 'comment_not_found', 'comment not found') }

            let checkCommentPost = await Post.findAll({ where: { id: data.post_id } });
            if (!checkCommentPost.length > 0) { return await Helper.ErrorResponse(res, 'post_not_found', 'post not found') }

            let checkCommentlike = await PostCommentReply.findAll({ where: { comment_id: data.comment_id, post_id: data.post_id } });
            console.log("Check comment reply",checkCommentlike,!checkCommentlike.length > 0)
            if (checkCommentExists) {
                let replyObj = {
                    user_id: req.AuthUser.id,
                    post_id: data.post_id,
                    comment_id: data.comment_id,
                    comment: data.comment
                }
                let likeCommentRepley = await PostCommentReply.create(replyObj);
                let pushNotfSettingDetail = await PushNotification.findOne({
                    where: {
                        id: checkCommentExists[0].user_id
                    }
                });
                
                if (pushNotfSettingDetail && pushNotfSettingDetail.comments == 1){
                    if(checkCommentExists[0].user_id != req.AuthUser?.id){
                        var message = `${req.AuthUser?.username} has replied on your comment`;
                        let payload = {
                            unique_id: req.AuthUser?.unique_id,
                            username: req.AuthUser?.username,
                            user_id: req.AuthUser.id,
                            sender_id: req.AuthUser.id,
                            receiver_id: checkCommentExists[0].user_id,
                            video_id: data.post_id,
                            image: req.AuthUser?.profile_pic,
                            title: message,
                            type: 'commentReply',
                        }
                        await Helper.sendPushNotification2(req, checkCommentExists[0].user_id, process.env.APP_NAME, message, payload);
                        await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:checkCommentExists[0].user_id,message:`${req.AuthUser.username} has replyed on your comment.`,type:"Post"})
                    }
                }    
                if (likeCommentRepley) { return await Helper.successResponseWithData(res, 'reply_comment', 'Reply comment has been Added successfully', likeCommentRepley) }
            } else {
                return await Helper.ErrorResponse(res, 'already_replied_comment', 'Reply comment has been already taken')
            }
        } catch (error) {
            console.log("_____________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)
        }
    },
     /** 
   * Developer => Prince
   * Function like post
   * 
   */
    PostCommentReplyLike: async (req, res) => {
        try {
            let data = req.body;
            if (!data.comment_reply_id) { return await Helper.ErrorResponse(res, 'comment_reply_id_req', 'comment_reply_id is required') }

            let checkCommentreply = await PostCommentReply.findOne({ where: { id: data.comment_reply_id } });
            if (!checkCommentreply) { return await Helper.ErrorResponse(res, 'post_comment_reply_not_found', 'post_comment_reply not found') }

            let checkCommentlike = await PostCommentReplyLike.findAll({ where: { comment_reply_id: data.comment_reply_id, user_id: req.AuthUser.id } });
            console.log('checkCommentlike---',checkCommentreply)
            if (!checkCommentlike.length > 0) {
                let replyObj = {
                    user_id: req.AuthUser.id,
                    comment_reply_id: data.comment_reply_id,
                }
                let postCommentReplyLike = await PostCommentReplyLike.create(replyObj);
                let pushNotfSettingDetail = await PushNotification.findOne({
                    where: {
                        id: checkCommentreply.user_id
                    }
                });
                if (pushNotfSettingDetail && pushNotfSettingDetail.likes == 1){
                    if(checkCommentreply.user_id != req.AuthUser?.id){
                        var message = `${req.AuthUser?.username} has liked your comment`;
                        let payload = {
                            unique_id: req.AuthUser?.unique_id,
                            username: req.AuthUser?.username,
                            user_id: req.AuthUser.id,
                            sender_id: req.AuthUser.id,
                            receiver_id: checkCommentreply.user_id,
                            video_id: checkCommentreply.post_id,
                            image: req.AuthUser?.profile_pic,
                            title: message,
                            type: 'commentReplyLike',
                        }
                        console.log('payllllod======',payload)
                        await Helper.sendPushNotification2(req, checkCommentreply.user_id, process.env.APP_NAME, message, payload);
                        await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:checkCommentreply.user_id,message:`${req.AuthUser.username} has liked your comment.`,type:"Post"})
                    }
                }
                if (postCommentReplyLike) { return await Helper.successResponseWithData(res, 'post_comment_reply_like', 'PostCommentReplyLike comment has been successfully', postCommentReplyLike) }
            } else {
                await PostCommentReplyLike.destroy({ where: { comment_reply_id: data.comment_reply_id, user_id: req.AuthUser.id } });
                return await Helper.ErrorResponse(res, 'post_comment_reply_unlike', 'PostCommentReplyLike comment has been unlike successfully')
            }
        } catch (error) {
            console.log("____________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)
        }
    },
     /** 
   * Developer => Prince
   * Function like post
   * 
   */
    fetchPostByHashTags: async (req, res) => {
        try {
            let body = req.body;
            let hashtags, posts = [];
            let favouritePost;
            let hashtagId;
            let hashtagFav 
            let allPost
    
            hashtags = await HashTag.findAll({ order: [['createdAt', 'DESC']] });
            if (body.hashtag_id && body.hashtag_id !== "") {
                 posts=await HashTag.findAll({
                     where: { id: body.hashtag_id }, order: [['createdAt', 'DESC']],
                     limit: body?.limit || 5,
                     offset: body?.offset || 0,
                     include:[{
                         model:Post,
                         //attributes:['id','thumbnail','views','video','description','user_id','sound_id','allow_comments','']
                         include: [
                            {
                                model: User,
                                as: 'user',
                                required: false,
                                attributes: ['id', 'first_name', 'device', 'device_token', 'username','profile_pic']
                            },
                            {
                                model: Sound,
                                as: 'sound',
                                required: false,
                                // separate: true, // Fetch comments separately
                            },
                        ]
                     }]
                 });
                 
             }
            else if (body.hashtag_name && body.hashtag_name !== "") {
                    posts=await HashTag.findAll({
                    where: { name: body.hashtag_name.toLowerCase() }, order: [['createdAt', 'DESC']],
                    limit: body?.limit || 5,
                    offset: body?.offset || 0,
                    include:[{
                        model:Post,
                        //attributes:['id','thumbnail','views','video','description','user_id','sound_id','allow_comments','']
                        include: [
                            {
                                model: User,
                                as: 'user',
                                required: false,
                                attributes: ['id', 'first_name', 'device', 'device_token', 'username','profile_pic']
                            },
                            {
                                model: Sound,
                                as: 'sound',
                                required: false,
                                // separate: true, // Fetch comments separately
                            },
                        ]
                    }]
                });
                hashtags.map((item)=>{
                    if(item.name.toLowerCase() == body.hashtag_name.toLowerCase()){
                        hashtagId = item.id
                    }
                })
                
            } else {
                allPost= await HashTagPost.findAll({
                    attributes: ['hashtag_id'],
                    // include:[{
                    //     model:Post,
                    //     //attributes:['id','thumbnail','views','video','description','user_id','sound_id','allow_comments','']
                    //     as:'posts',
                    //     include: [
                    //        {
                    //            model: User,
                    //            as: 'user',
                    //            required: false,
                    //            attributes: ['id', 'first_name', 'device', 'device_token', 'username','profile_pic']
                    //        },
                    //        {
                    //            model: Sound,
                    //            as: 'sound',
                    //            required: false,
                    //            // separate: true, // Fetch comments separately
                    //        },
                    //    ]
                    // }],
                    group: ['HashTagPost"."hashtag_id'],
                    order: [[Sequelize.fn('COUNT', Sequelize.col('HashTagPost"."hashtag_id')), 'DESC']],
                    limit: body?.limit || 10,
                    offset: body?.offset || 0,
                  })
                
            }


if(allPost){
            for(let i=0;i<allPost.length;i++){
               
                  posts.push(await HashTag.findOne({
                    where: { id: allPost[i].hashtag_id },
                    include:[{
                        model:Post,
                        //attributes:['id','thumbnail','views','video','description','user_id','sound_id','allow_comments','']
                        include: [
                           {
                               model: User,
                               as: 'user',
                               required: false,
                               attributes: ['id', 'first_name', 'device', 'device_token', 'username','profile_pic']
                           },
                           {
                               model: Sound,
                               as: 'sound',
                               required: false,
                               // separate: true, // Fetch comments separately
                           },
                       ]
                    }]
                })
                  )
            }
        }
        const postsArray = posts.map(hashTag => hashTag.Posts).flat();
            
        //    if(body.hashtag_id != null && body.hashtag_id != ""){
        //      favouritePost = await HashTagFavourite.findAll({ where: { hashtag_id:body.hashtag_id ,user_id:req.AuthUser.id } })
           
        //   }

           
            if(postsArray.length >0){
                for(let i=0;i<postsArray.length;i++){
                    console.log("--------------------",postsArray[i].HashTagPost.hashtag_id)
                    let totalPostcomment = await PostComment.findAll({ where: { post_id: postsArray[i].id } });
                    let totalLikePost = await PostLike.findAll({ where: { post_id: postsArray[i].id } })
                    
                    let is_liked = await PostLike.findAll({ where: {post_id:postsArray[i].id,user_id:req.AuthUser.id} });


                    let followers = await Follower.findAll({ where: { receiver_id: postsArray[i].user_id } });
                    let followings = await Follower.findAll({ where: { sender_id: postsArray[i].user_id } });
                    let hashtagFav = await HashTagFavourite.findAll({where:{user_id:req.AuthUser.id,hashtag_id:postsArray[i].HashTagPost.hashtag_id}})
                    postsArray[i].HashTagPost.dataValues.is_favourite = hashtagFav?.length ? 1 : 0;

        
                    let _posts = await Post.findAll({ where: { user_id: postsArray[i].user_id } });
                    let likes = await PostLike.findAll({ where: { user_id: postsArray[i].user_id } });
                    let favourite_count = await PostFavourite.findAll({ where: {post_id:postsArray[i].id } })
                    favouritePost = await PostFavourite.findAll({ where: { user_id:req.AuthUser.id,post_id:postsArray[i].id } }) 
                    const privacyDetails = await PrivacySetting.findOne({
                        where: {
                            user_id: postsArray[i].user_id
                        }
                    });
                    let privacySetting = {};
                    if(privacyDetails){
                        privacySetting = {
                            videos_download: privacyDetails.dataValues.videos_download,
                            direct_message: privacyDetails.dataValues.direct_message,
                            duet: privacyDetails.dataValues.duet,
                            liked_videos: privacyDetails.dataValues.liked_videos,
                            video_comment: privacyDetails.dataValues.video_comment,
                            direct_messages: privacyDetails.dataValues.direct_messages,
                        }
                    }
    
                    postsArray[i].dataValues.privacySetting = privacySetting;
    
                    postsArray[i].dataValues.video_comment_count = totalPostcomment?.length || 0;
                    postsArray[i].dataValues.like_count = totalLikePost?.length || 0;
                    
                    postsArray[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                    postsArray[i].dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0;
                    postsArray[i].dataValues.favourite_count = favourite_count?.length 

                    let checkFollow = await Follower.findAll({ where: { receiver_id: postsArray[i].user_id, sender_id: req.AuthUser.id } });
                    if(postsArray[i].user != null){
                        postsArray[i].user.dataValues.followers = followers?.length || 0
                        postsArray[i].user.dataValues.followings = followings?.length || 0
                        postsArray[i].user.dataValues.totalPost = _posts?.length || 0
                        postsArray[i].user.dataValues.totalLikes = likes?.length || 0
                        postsArray[i].user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
                    }

                    let soundCount;
                    let soundFav;
                    
                    if(postsArray[i].post && postsArray[i].post.sound && postsArray[i].post.sound.id ){
                        soundFav = await SoundFavourite.findAll({ where: { sound_id: postsArray[i].sound.id, user_id: postsArray[i].user_id } })
                        postsArray[i].sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                    }
                    if(postsArray[i].post && postsArray[i].post.sound && postsArray[i].post.sound.id ){
                        soundCount =  await Post.findAll({ where: { sound_id: postsArray[i].sound.id} })
                        postsArray[i].sound.dataValues.video_count = soundCount?.length || 0
                    }

                    // let soundFav = await SoundFavourite.findAll({ where: { sound_id: postsArray[i].sound.id, user_id: postsArray[i].user_id } })
                    // postsArray[i].sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;

                    // let soundCount = await Post.findAll({ where: { sound_id: postsArray[i].sound.id} })
                    // postsArray[i].sound.dataValues.video_count = soundCount?.length || 0

                    if(postsArray[i].sound !== null){
                        postsArray[i].sound.dataValues.audio = process.env.Sound_URL  + '/' + postsArray[i].sound.dataValues.audio
                        }
                        else if(postsArray[i].sound === null){
                            postsArray[i].sound = {}
                            }
                }

                for(let i=0;i<posts.length;i++){
                    //total hashtag post by id 
                    let totalHashPost = await HashTagPost.findAll({where:{hashtag_id:posts[i].id}})
                    posts[i].dataValues.video_count = totalHashPost?.length || 0
                    let hashtagFav = await HashTagFavourite.findAll({where:{user_id:req.AuthUser.id,hashtag_id:posts[i].id}})
                    posts[i].dataValues.is_favourite = hashtagFav?.length ? 1 : 0;
                }
            }
            

            return await Helper.successResponseWithData(res, 'fetch_post_by_hashtags', 'post has been fetched by hashtags successsfully', {allHashtags:hashtags,hashTagPosts:posts})

           
           

            let data = req.body;
            let currentUserId = req.AuthUser.id;
            let blockedUsers = [];
            let searchDetails = [];
            let allHashTags;

            if (data.id) {
                allHashTags = await HashTag.findAll({ where: { id: data.id }, order: [['createdAt', 'DESC']] });
            } else {
                allHashTags = await HashTag.findAll({ order: [['createdAt', 'DESC']] });
            }

            //all fetchb post by hashtag by anshuman
            //all fetchb post by hashtag by anshuman
            // if (data.trending_id == "49cba0a6-8d58-4985-a59e-1e53d23a2e51") {
            if (await allHashTags?.length == 0) {
                return await Helper.ErrorResponse(res, 'hastag_empty', 'No hashtag found');

            }

            let unq = await allHashTags?.filter(function (item) {
                var i = searchDetails?.findIndex(x => x.name == item.name);
                if (i <= -1) {
                    searchDetails.push({ id: item.id, name: item.name });
                }
                return null;
            });

            let blockedUserList = await BlockUser.findAll({
                attributes: ['user_id'],
                where: { block_user_id: currentUserId }
            })

            if (blockedUserList?.length > 0) {
                await blockedUserList.forEach((item) => blockedUsers.push(item.user_id));
            }

            // if(data.id){  
            //     searchDetails = await HashTag.findAll({where:{id:data.id}});
            // }

            let postArray = [];
            let postIds = [];
            console.log("heres", await searchDetails)

            await searchDetails?.forEach(async (item, index) => {

                let obj = await HashTagPost.findAll({
                    where: {
                        hashtag_id: item.id,
                        '$posts.user_id$': { [Op.notIn]: blockedUsers }
                    },
                    include: [{
                        model: Post,
                        as: 'posts',
                        required: false,
                        include: [
                            {
                                model: PostLike,
                                as: 'likePost',
                                required: false,
                                include: [{
                                    model: User,
                                    as: 'user',
                                    required: false
                                }]
                            }, {
                                model: PostComment,
                                as: 'comment',
                                required: false,
                                include: [{
                                    model: User,
                                    as: 'user',
                                    required: false,
                                }]
                            },
                        ],
                    }]
                }).then((res) => {
                    postArray.push({ id: item.id, hashtag: item.name, posts: res })
                })


                if (index + 1 == searchDetails.length) {
                    let reponsePayload = {
                        hashtags: searchDetails,
                        hashtagPosts: postArray
                    }
                    return await Helper.successResponseWithData(res, 'post_fetched', 'post fetched successsfully', reponsePayload)

                }
            })
            // }
            //end of code by anshuman

            //end of code by anshuman

            //end of trending post
            // if (data.id) {

            //     let pluck_post_id = await HashTagPost.findAll({
            //         includes: [{
            //             model: 'hashtags',
            //             as: 'hashtag',
            //             required: false
            //         }],
            //         //attributes: ['id', 'post_id', 'hashtag_id'], 
            //         where: { hashtag_id: data.id },
            //         limit: data.limit || 5,
            //         offset: data.offset || 0,
            //         order: [['createdAt', 'DESC']]
            //     });
            //     let hashPostIdLength = pluck_post_id.length;
            //     let post = "";

            //     if (hashPostIdLength > 0) {
            //         for (let i = 0; i < hashPostIdLength; i++) {
            //             if (pluck_post_id[i]?.post_id != null) {
            //                 post = await Post.findAll({
            //                     include: [{
            //                         model: HashTagPost,
            //                         as: 'hashTags',
            //                         required: false,
            //                         include: [{
            //                             model: HashTag,
            //                             as: 'hashtag',
            //                             required: false
            //                         }]
            //                     }, {
            //                         model: PostLike,
            //                         as: 'likePost',
            //                         required: false,
            //                         include: [{
            //                             model: User,
            //                             as: 'user',
            //                             required: false,
            //                             attributes: ['id', 'first_name', 'email']
            //                         }]
            //                     }, {
            //                         model: PostComment,
            //                         as: 'comment',
            //                         required: false,
            //                         include: [{
            //                             model: User,
            //                             as: 'user',
            //                             required: false,
            //                             attributes: ['id', 'first_name', 'email', 'device', 'device_token']
            //                         }]
            //                     },
            //                     {
            //                         model: User,
            //                         as: 'user',
            //                         required: false,
            //                         attributes: ['id', 'first_name', 'device', 'device_token']
            //                     }],
            //                     where: { id: pluck_post_id[i]?.post_id },
            //                     order: [['createdAt', 'DESC']],
            //                     limit: data.limit || 10,
            //                     offset: data.offset || 0
            //                 })
            //             }
            //         }
            //     }
            //     return await Helper.successResponseWithData(res, 'post_fetch_by_hashtags', 'Post has been fetched by hashtags', { hashtags: allHashTags, posts: post });
            // }

        } catch (error) {
            console.log("__________________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
     /** 
   * Developer => Prince
   * Function like post
   * 
   */
    addHashTagFavourite: async (req,res) => {
        try {
            let data=req.body;
            if(!data.hashtag_id){return await Helper.ErrorResponse(res,'hashtag_req','hashtag_id is required')};
            let checkHashTagExists=await HashTag.findOne({where:{id:data.hashtag_id}});
            if(!checkHashTagExists){return await Helper.ErrorResponse(res,'hashtag_not_found','hashtag not found')}
           
            let checkFavPostExists = await HashTagFavourite.findOne({ where: { hashtag_id: data.hashtag_id ,user_id:req.AuthUser.id} });

            if (checkFavPostExists) {
                await HashTagFavourite.destroy({ where: {hashtag_id:data.hashtag_id,user_id:req.AuthUser.id} });
                return await Helper.ErrorResponse(res, 'already_favorite', 'this hashtag is already favorite')
            }
            let obj={user_id:req.AuthUser.id,hashtag_id:data.hashtag_id};
            let favouriteHashtag=await HashTagFavourite.create(obj);
            if(favouriteHashtag){return await Helper.successResponseWithData(res,'fav_hashtag_added','hashtag has been favourite successfully',favouriteHashtag)}
        } catch (error) {
            console.log("_______________________________________________log is here",error);
            return await Helper.ErrorResponse(res, 'internal-server-error', error.message)
        }
    },

    
    /** 
   * Developer => KESHAV
   * Function FAV HASHTAG
   * 
   */

    fetchFavouriteHashTag: async (req, res) => {
        try {
            let data = req.body
            // let posts=await HashTagFavourite.findAll({
            //     where: { user_id: req.AuthUser.id },
            //     include:[{
            //         model: HashTag,
            //         as: 'hashtags',
            //         include:Post
            //     }]
            // });

            let posts=await HashTagFavourite.findAll({
                where: { user_id: req.AuthUser.id },
                include:[{
                    model: HashTag,
                    as: 'hashtags',
                    // attributes:['name'],
                    include:Post
                }],
                limit: data.limit || 10,
                offset: data.offset || 0,
                order: [['createdAt', 'DESC']]
            });
            let name,postsCount
            posts.forEach(item => {
                const { hashtags, ...rest } = item;
                
                name = hashtags.name;
                postsCount = hashtags.Posts.length;
                item.dataValues.name = name
                item.dataValues.video_count = postsCount
                
            });

            return await Helper.successResponseWithData(res, 'fetch_post_by_fav_hashtags', 'post has been fetched by fav hashtags successsfully', posts)
        }catch (error) {
            console.log("__________________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },


    /** 
   * Developer => Prince
   * Function like post
   * 
   */
    rePost: async (req, res) => {
        try {
            let data = req.body;
            if (!data.post_id) { return await Helper.ErrorResponse(res, 'post_id_req', 'post_id is required'); }
            let checkPostExistsOrNot = await Post.findOne({ where: { id: data.post_id } });
            if (!checkPostExistsOrNot) { return await Helper.ErrorResponse(res, 'post_not_found', 'post not found') }
            let payload = { user_id: req.AuthUser.id, post_id: data.post_id }
            let repost = await Repost.create(payload);

            //again repost will make for repost
            let v = await new Validator(req.body, {
                // description: "required",
                video: "required",
                thumbnail: "required",
                video_id: "required",
            }, {
                // "description.required": "Please enter the description",
                "video.required": "Please enter the video",
                "thumbnail.required": "Please enter the thumbnail",
                "video_id": "Please enter the video id"
            }
            );
            let checks = await v.check();
            if (!checks) {
                let description = v.errors.description ? v.errors.description : '';
                let video = v.errors.video ? v.errors.video : '';
                let thumbnail = v.errors.thumbnail ? v.errors.thumbnail : '';
                let video_id = v.errors.video_id ? v.errors.video_id : '';
                return await Helper.ErrorResponseWithStatusCode(res, [description, video, thumbnail, video_id]);
            } else {
                let obj = {};
                obj.user_id = req.AuthUser.id,
                    obj.video = data.video,
                    obj.thumbnail = data.thumbnail,
                    obj.allow_comment = data.allow_comment,
                    obj.allow_duet = data.allow_duet,
                    obj.video_id = data.video_id

                //payload will be called
                if (data.description || data.location_string || data.lat || data.long || data.product) {
                    obj.description = data.description,
                        obj.location_string = data.location_string,
                        obj.lat = data.lat,
                        obj.long = data.long,
                        obj.product = data.product
                }
                if (data.repost || data.repost_user_id) {
                    obj.repost = data.repost,
                        obj.repost_user_id = data.repost_user_id
                }

                let post = await Post.create(obj);
                let post_id = post.id;


                //hash tags added is here
                if (data.hashtags_json) {
                    //var hashTagCleanTag = await Helper.cleanString(data.hashTags);
                    let hash_tag = JSON.parse(data.hashtags_json);
                    let hashTagLenght = hash_tag.length;
                    for (let i = 0; i < hashTagLenght; i++) {
                        let checkHashTagExists = await HashTag.findAll({ where: { name: hash_tag[i].name } });
                        if (!checkHashTagExists.length > 0) {
                            let obj = {
                                name: hash_tag[i].name,
                            }
                            let hashtags = await HashTag.create(obj);
                            //hashtags assign to the post
                            let postHash = await HashTagPost.create({ hashtag_id: hashtags.id, post_id: post_id });

                        } else {
                            let update = await HashTag.update({ name: hash_tag[i].name },
                                { where: { id: checkHashTagExists.map(val => { return val?.id }) } })
                        }
                    }
                }
            }
            //end of repost for post


            return await Helper.successResponseWithData(res, 'rePost_created', 'Re-Post has been created successfully', repost);
        } catch (error) {
            console.log("_________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    fetchFollowingPosts: async (req, res) => {
        try {
            //144867cc-e353-465f-91ce-d616bb02bc36

            let data = req.body;
            let followingUser = await Follower.findAll({ attributes: ['id', 'receiver_id', 'status'], where: { sender_id: data.user_id } });
            let fetchPost = "";
            //getting the post as per of following
            let followingLenght = await followingUser.length
            if (followingUser.length > 0) {
                for (let i = 0; i < followingLenght; i++) {
                    if (followingUser[i]?.receiver_id != "") {

                        let posts = await Post.findAll({
                            attributes: ['id', 'user_id', 'sound_id', 'description', 'duet_video_id', 'old_video_id', 'block', 'createdAt', 'updatedAt'],
                            where: { user_id: followingUser[i].receiver_id },
                            order: [['createdAt', 'DESC']]
                        });
                        fetchPost = posts.filter(val => { return val.block == 0 })
                    }
                }
            }
            fetchPost = await Helper.removeBlockUsers(fetchPost,req.AuthUser.id);

            return res.send(fetchPost);

        } catch (error) {
            console.log("_______________________________error is here", error);
        }
    },
    rePortPost: async (req, res) => {
        try {
            let data = req.body;
            if (!data.report_reason_title) { return await Helper.ErrorResponse(res, 'reason_title_req', "report_reason_title required"); }
            if (!data.report_reason_id) { return await Helper.ErrorResponse(res, 'reason_reason_id', "report_reason_id is required"); }

            // let checkReportReasonExists = await ReportReason.findAll({ where: { id: data.report_reason_id } });
            // if (!checkReportReasonExists?.length > 0) { return await Helper.ErrorResponse(res, 'report_reason_not_found', 'report reason not found') }

            let checkPostExists = await Post.findAll({ where: { id: data.post_id } });
            if (!checkPostExists?.length > 0) { return await Helper.ErrorResponse(res, 'post_not_found', 'post not found') }

            if (data.report_user_id == req.AuthUser.id) {
                return await Helper.ErrorResponse(res, "auth_not_matched", "You should choose the different report_user_id, not choose yourself");
            }
            let obj = {};
            obj = {
                user_id: req.AuthUser.id,
                post_id: data.post_id,
                report_reason_title: data.report_reason_title
            }
            if (data.description) {
                obj.description = data.description
            }
            if (data.report_reason_id) {
                obj.report_reason_id = data.report_reason_id
            }

            let makeReport = await ReportPost.create(obj);
            if (makeReport) { return await Helper.SuccessResponse(res, "make_report", "Report Post has been created successfully"); }
        } catch (error) {
            console.log("__________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    increasePostView: async (req, res) => {
        try {

            let data = req.body;
            let checkPost = await PostView.findOne({  where: { post_id: data.post_id, user_id: req.AuthUser.id } });
            // if (checkPost) {
            //     return await Helper.ErrorResponse(res, 'already_view', 'Post has been already viewed')
            // } else {
            //     checkPost.view = 1; 
            //     if (await checkPost.save()) { return await Helper.SuccessResponse(res, 'view_increased', 'Post has been viewed successfully') }
            // }

            let totalView = await PostView.findAll({  where: { post_id: data.post_id } });
            await Post.update({ view:totalView.length }, { where: { id: data.post_id } });

            if (checkPost) {
                return await Helper.ErrorResponse(res, 'already_view', 'Post has already been viewed by the user');
            } else {
                await PostView.create({ post_id: data.post_id, user_id: req.AuthUser.id });
                return await Helper.SuccessResponse(res, 'view_increased', 'Post has been viewed successfully');
            }
        } catch (error) {
            console.log("_______________________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    deletePostView: async (req, res) => {
        try {

        } catch (error) {
            console.log("_______________________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    popularUserPost: async (req, res) => {
        try {
            let data = req.body;
            let reportPost = await ReportPost.findAll({ attributes: ['post_id'] });

            let posts = await Post.findAll({
                include: [{
                    attributes: ['first_name', 'last_name', 'profile_pic', 'id'],
                    model: User,
                    as: 'user',
                    required: false
                }],
                where: { video: { [Op.ne]: null }, id: { [Op.notIn]: await reportPost.map(val => { return val.post_id }) } },
                //attributes:['id','user_id','description'],
                limit: data.limit || 5,
                //offset:data.offset || 0,
                //order: Sequelize.literal('RANDOM()'),
            });

            return await Helper.successResponseWithData(res, 'top_5_popular_posts', 'Popular post has been fetched successfully', posts);

        } catch (error) {
            console.log("______________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    downloadVideo: async (req, res) => {
        try {
            let data = req.body;
            if (!data.post_id) { return await Helper.ErrorResponse(res, 'post_id_req', 'post id must be defined') }
            let checkPostExists = await Post.findOne({ where: { id: data.post_id } });
            if (checkPostExists === null) {
                return await Helper.ErrorResponse(res, 'post_not_found', 'Post with the specified ID does not exist');
            }
            let existingSavedVideo = await SavedVideo.findOne({
                where: {
                    user_id: req.AuthUser.id,
                    post_id: data.post_id
                }
            });
        
            if (existingSavedVideo) {
                // Video is already saved, return appropriate response
                return await Helper.ErrorResponse(res, 'video_already_saved', 'The video is already saved by the user');
            }
           let obj;
           let saved;
            if(checkPostExists !=null){
                obj = {
                    user_id:req.AuthUser.id,
                    post_id: data.post_id
                }
              saved =   await SavedVideo.create(obj)
            }

            if (saved) {
                return await Helper.successResponseWithData(res, 'save_video', 'You have saved the video successfully', saved);
            } else {
                return await Helper.ErrorResponse(res, 'save_failed', 'Failed to save the video');
            }

        } catch (error) {
            console.log("______________________________________error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    favouritePost: async (req, res) => {
        try {
            let data = req.body;
            if (!data.post_id) { return await Helper.ErrorResponse(res, 'post_id_req', 'post id must be defined') }
            let checkPostExists = await Post.findOne({ where: { id: data.post_id } });
            let checkFavPostExists = await PostFavourite.findOne({ where: { post_id: data.post_id ,user_id:req.AuthUser.id} });
            if (!checkPostExists) { return await Helper.ErrorResponse(res, 'post_not_found', 'post not found') }

            if (checkFavPostExists) {
                await PostFavourite.destroy({ where: { post_id: data.post_id ,user_id:req.AuthUser.id} });
                return await Helper.ErrorResponse(res, 'already_favorite', 'this post is already favorite')
            }
            let favouritePost = await PostFavourite.create({ user_id: req.AuthUser.id, post_id: data.post_id });
            if (favouritePost) {
                return await Helper.successResponseWithData(res, 'favourite_post_added', 'Favorite Post has been added successfully', favouritePost);
            }
                } catch (error) {
            console.log("___________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },
    fetchFavouritePost: async (req, res) => {
        try {
            let data = req.body;
                        
            let pluckPostId = await PostFavourite.findAll({
                where: { user_id: req.AuthUser.id },
                limit: data.limit || 10,
                offset: data.offset || 0,
                order: [['createdAt', 'DESC']]
            });
            

            if(!pluckPostId.length > 0){return await Helper.ErrorResponse(res,'till_now_is_not_Favourite','user not found along with favourite post')}
          
            let posts = "";
            if (pluckPostId?.length > 0) {
                for (let i = 0; i < pluckPostId.length; i++) {
                    // if (pluckPostId[i]?.post_id != null) {
                        // const postIdList = pluckPostId.map(item => item.post_id).filter(id => id !== null && id !== undefined);
                        // console.log("postIdList",postIdList)
                      
                            // posts = await Post.findAll({
                            //     where: { 
                            //         id: { 
                            //             [Sequelize.Op.in]: postIdList // Using the WHERE IN clause with the list of post IDs
                            //         } 
                            //     },
                            posts = await Post.findAll({where:{id: pluckPostId.map(item => item.post_id)},
                                include: [{
                                    model: HashTagPost,
                                    as: 'hashTags',
                                    required: false,
                                    separate: true, // Fetch comments separately
                                    include: [{
                                        model: HashTag,
                                        as: 'hashtag',
                                        required: false
                                    }]
                                }, 
                                {
                                    model: PostLike,
                                    as: 'likePost',
                                    required: false,
                                    separate: true, // Fetch comments separately
                                    include: [{
                                        model: User,
                                        as: 'user',
                                        required: false,
                                        attributes: ['id', 'first_name', 'email','username']
                                    }]
                                }, 
                                {
                                    model: PostComment,
                                    as: 'comment',
                                    required: false,
                                    separate: true, // Fetch comments separately
                                    include: [{
                                        model: User,
                                        as: 'user',
                                        required: false,
                                        attributes: ['id', 'first_name', 'email', 'device', 'device_token','username']
                                    }]
                                },
                                {
                                    model: Sound,
                                    as: 'sound',
                                    required: false,
                                    // separate: true, // Fetch comments separately
                                },
                                {
                                    model: User,
                                    as: 'user',
                                    required: false,
                                    attributes: ['id', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic','username']
                                }],
    
                                limit: data?.limit || 10,
                                offset: data?.offset || 0,
                                // order: [['createdAt', 'DESC']]
                            })
                       
                      
                    // }
                }
            }
            console.log("----------------------------------------------",posts)

            if (posts.length > 0) {
                for (let i = 0; i < posts.length; i++) {
                    let followers = await Follower.findAll({ where: { receiver_id: posts[i].user_id } });
                    let followings = await Follower.findAll({ where: { sender_id: posts[i].user_id } });

                    let _posts = await Post.findAll({ where: { user_id: posts[i].user_id } });
                    let likes = await PostLike.findAll({ where: { user_id: posts[i].user_id } });

                    if (posts[i].id != null) {
                        let totalPostcomment = await PostComment.findAll({ where: { post_id: posts[i].id } });
                        let totalRePost = await Repost.findAll({ where: { post_id: posts[i].id } });
                        let totalLikePost = await PostLike.findAll({ where: { post_id: posts[i].id } })
                        let favouritePost = await PostFavourite.findAll({ where: { post_id: posts[i].id } })

                        let is_liked = await PostLike.findAll({ where: { post_id: posts[i].id, user_id: req.AuthUser.id } });
                        let favoritePost = await PostFavourite.findAll({ where: { post_id: posts[i].id } });
                        const privacyDetails = await PrivacySetting.findOne({
                            where: {
                                user_id: posts[i].user_id
                            }
                        });
                        let privacySetting = {};
                        if(privacyDetails){
                            privacySetting = {
                                videos_download: privacyDetails.dataValues.videos_download,
                                direct_message: privacyDetails.dataValues.direct_message,
                                duet: privacyDetails.dataValues.duet,
                                liked_videos: privacyDetails.dataValues.liked_videos,
                                video_comment: privacyDetails.dataValues.video_comment,
                                direct_messages: privacyDetails.dataValues.direct_messages,
                            }
                        }
        
                        posts[i].dataValues.privacySetting = privacySetting;
        
                        posts[i].dataValues.video_comment_count = totalPostcomment.length || 0;
                        posts[i].dataValues.totalRePost = totalRePost.length || 0;
                        posts[i].dataValues.like_count = totalLikePost.length || 0;
                        posts[i].dataValues.is_favourite = favouritePost.length > 0 ? 1 : 0;


                        posts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                        posts[i].dataValues.favourite_count = favoritePost?.length ? favoritePost.length : 0
                    }

                    posts[i].user.dataValues.followers = followers?.length || 0
                    posts[i].user.dataValues.followings = followings?.length || 0
                    posts[i].user.dataValues.totalPost = _posts.length || 0
                    posts[i].user.dataValues.totalLikes = likes.length || 0

                    

                    if (posts[i].sound !== null) {
                        posts[i].sound.dataValues.audio = process.env.Sound_URL + '/' + posts[i].sound.dataValues.audio
                    }
                    else if (posts[i].sound === null) {
                        posts[i].sound.dataValues = {}
                    }

                    
                }
            }


            return await Helper.successResponseWithData(res, 'posts_fetched', 'Posts has been fetched successfully', posts?.length > 0 ? posts : []);
        } catch (error) {
            console.log("___________________________________Error is here", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);

        }
    },
    fetchFavouritePost1: async (req, res) => {
        try {
            let data = req.body;

            const postLike = await PostFavourite.findAll({
                where: { user_id: req.AuthUser.id},
                include: [{
                    model: Post,
                    as: 'post',
                    required: false,
                    //where:{user_id:data.user_id},
                    //attributes: ['id', 'user_id', 'description'],
                    include: [{
                        model: User,
                        as: 'user',
                        required: false,
                    },
                    {
                        model: Sound,
                        as: 'sound',
                        required: false,
                        // separate: true, // Fetch comments separately
                    },
                ]
                },
          ],

                order: [['createdAt', 'DESC']],
                limit: data?.limit || 10,
                offset: data?.offset || 0,
            });

            

            if (postLike.length > 0) {
                
                for (let i = 0; i < postLike.length; i++) {
                                           
                    let followers = await Follower.findAll({ where: { receiver_id: postLike[i].user_id } });
                    let followings = await Follower.findAll({ where: { sender_id: postLike[i].user_id } });

                    let _posts = await Post.findAll({ where: { user_id: postLike[i].user_id } });
                    let likes = await PostLike.findAll({ where: { user_id: postLike[i].user_id } });

                   if (postLike[i].post != null) {
                       
                        let totalPostcomment = await PostComment.findAll({ where: { post_id: postLike[i].post.id } });
                        let totalRePost = await Repost.findAll({ where: { post_id: postLike[i].post.id } });
                        let totalLikePost = await PostLike.findAll({ where: { post_id: postLike[i].post.id } })
                        let favouritePost = await PostFavourite.findAll({ where: { post_id: postLike[i].post.id } })

                        let is_liked = await PostLike.findAll({ where: { post_id: postLike[i].post.id, user_id: req.AuthUser.id } });
                        let favoritePost = await PostFavourite.findAll({ where: { post_id: postLike[i].post.id } });

                        postLike[i].post.dataValues.video_comment_count = totalPostcomment.length || 0;
                        postLike[i].post.dataValues.totalRePost = totalRePost.length || 0;
                        postLike[i].post.dataValues.like_count = totalLikePost.length || 0;
                        postLike[i].post.dataValues.is_favourite = favouritePost.length > 0 ? 1 : 0;
                        postLike[i].post.dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                        postLike[i].post.dataValues.favourite_count = favoritePost?.length ? favoritePost.length : 0

                        // postLike[i].post.user.dataValues.followers = followers?.length || 0
                        // postLike[i].post.user.dataValues.followings = followings?.length || 0
                        postLike[i].post.user.dataValues.totalPost = _posts.length || 0
                        postLike[i].post.user.dataValues.totalLikes = likes.length || 0
                        let soundCount;
                        let soundFav;
                        
                        if(postLike[i].post && postLike[i].post.sound && postLike[i].post.sound.id ){
                            soundFav = await SoundFavourite.findAll({ where: { sound_id: postLike[i].post.sound.id, user_id: postLike[i].user_id } })
                            postLike[i].post.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                        }
                        if(postLike[i].post && postLike[i].post.sound && postLike[i].post.sound.id ){
                            soundCount =  await Post.findAll({ where: { sound_id: postLike[i].post.sound.id} })
                            postLike[i].post.sound.dataValues.video_count = soundCount?.length || 0
                        }
                        // let soundFav = await SoundFavourite.findAll({ where: { sound_id: postLike[i].post.sound.id, user_id: postLike[i].user_id } })
                        // postLike[i].post.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
    
                        // let soundCount = await Post.findAll({ where: { sound_id: postLike[i].post.sound.id} })
                        // postLike[i].post.sound.dataValues.video_count = soundCount?.length || 0
    6
                        // console.log("------------------------",postLike[i].post.dataValues.sound)
                        if (postLike[i].post.dataValues.sound !== null) {
                            postLike[i].post.dataValues.sound.audio = process.env.Sound_URL + '/' + postLike[i].post.dataValues.sound.audio
                        }
                        else if (postLike[i].post.dataValues.sound === null) {
                            postLike[i].post.dataValues.sound = {}
                        }
                        let followers = await Follower.findAll({ where: { receiver_id: postLike[i].user_id } });
                        let followings = await Follower.findAll({ where: { sender_id: postLike[i].user_id } });
                        checkFollow = await Follower.findAll({ where: { receiver_id: postLike[i].user_id, sender_id: req.AuthUser.id } });
                        if(postLike[i].post.user != null){
                            postLike[i].post.user.dataValues.followers = followers?.length || 0
                            postLike[i].post.user.dataValues.followings = followings?.length || 0
                            postLike[i].post.user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
                        }
                    }
                    
                }
            }
            
            return await Helper.successResponseWithData(res, 'posts_fetched', 'Posts has been fetched successfully', postLike);

        } catch (error) {
            console.log("__________________________________error", error);
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },

    getUserRecentVideos: async (req, res) => {
        try {
            let data = req.body;
            if (!data.user_id) { return await Helper.ErrorResponse(res, 'user_id_req', 'user_id must be defined') }
            if (!data.start_datetime) { return await Helper.ErrorResponse(res, 'start_datetime_req', 'start_datetime must be defined') }
            if (!data.end_datetime) { return await Helper.ErrorResponse(res, 'end_datetime_req', 'end_datetime must be defined') }
                let userId = data.user_id
            
            let posts = "";
            let allPosts;
            let postPromises=[];
       
            // Push the promise for fetching posts to the postPromises array
            postPromises.push(
                // Post.findAll({
                //     where: { user_id: userId},
                    
                Post.findAll({
                    where: { user_id: userId, privacy_type: 'public', createdAt : {[Op.between] : [data.start_datetime , data.end_datetime ]} },
                    include: [
                        {
                            model: HashTagPost,
                            as: 'hashTags',
                            required: false,
                            include: [{
                                model: HashTag,
                                as: 'hashtag',
                                required: false
                            }]
                        },
                        {
                            model: PostLike,
                            as: 'likePost',
                            required: false,
                            include: [{
                                model: User,
                                as: 'user',
                                required: false,
                                attributes: ['id', 'first_name', 'email']
                            }]
                        },
                        {
                            model: PostComment,
                            as: 'comment',
                            required: false,
                            include: [{
                                model: User,
                                as: 'user',
                                required: false,
                                attributes: ['id', 'first_name', 'email', 'device', 'device_token']
                            }]
                        },
                        {
                            model: Sound,
                            as: 'sound',
                            required: false,
                            // separate: true, // Fetch comments separately
                        },
                        {
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id','username', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic']
                        }
                    ],
                    limit: data?.limit || 10,
                    offset: data?.offset || 0,
                    order: [['createdAt', 'DESC']]
                })
            );

            // Wait for all promises to resolve
            posts = await Promise.all(postPromises);

            // Concatenate the arrays of posts into a single array
            allPosts = posts.flat();
            

            let checkFollow
            let is_liked ,is_favourite;
            let soundCount;
            let soundFav;
            if (allPosts.length > 0) {
                
                for (let i = 0; i < allPosts.length; i++) {
                    allPosts[i].dataValues.video_hls = "https://vod.api.video/vod/" + allPosts[i].dataValues.old_video_id + "/hls/manifest.m3u8";
                    let followers = await Follower.findAll({ where: { receiver_id: allPosts[i].user_id } });
                    let followings = await Follower.findAll({ where: { sender_id: allPosts[i].user_id } });

                    let _posts = await Post.findAll({ where: { user_id: allPosts[i].user_id } });
                    let likes = await PostLike.findAll({ where: { user_id: allPosts[i].user_id } });
                    let profilePic = await User.findAll({where:{id:allPosts[i].user_id}})

                    
                    let rePostCount = await Repost.findAll({ where: { post_id: allPosts[i].id } });
                    if (userId) {
                        is_liked = await PostLike.findAll({ where: { post_id: allPosts[i].id, user_id: userId } });
                        checkFollow = await Follower.findAll({ where: { receiver_id: allPosts[i].user_id, sender_id: userId } });
                        is_favourite = await PostFavourite.findAll({ where: {post_id:allPosts[i].id,user_id:userId} });
                        
                        
                        if(allPosts[i].post && allPosts[i].post.sound && allPosts[i].post.sound.id ){
                            soundFav = await SoundFavourite.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id, user_id: userId } })
                        }
                        
                        // soundFav = await SoundFavourite.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id, user_id: userId } })
                    }
                    if(allPosts[i].post && allPosts[i].post.sound && allPosts[i].post.sound.id ){
                        soundCount =  await Post.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id } })
                    }
                    // let soundCount = await Post.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id } })
                    


                    if (allPosts[i].id != null) {
                        let totalPostcomment = await PostComment.findAll({ where: { post_id: allPosts[i].id } });
                        let totalRePost = await Repost.findAll({ where: { post_id: allPosts[i].id } });
                        let totalLikePost = await PostLike.findAll({ where: { post_id: allPosts[i].id } })
                        let favouritePost = await PostFavourite.findAll({ where: { post_id: allPosts[i].id } })
                        const privacyDetails = await PrivacySetting.findOne({
                            where: {
                                user_id: allPosts[i].user_id
                            }
                        });
                        let privacySetting = {};
                        if(privacyDetails){
                            privacySetting = {
                                videos_download: privacyDetails.dataValues.videos_download,
                                direct_message: privacyDetails.dataValues.direct_message,
                                duet: privacyDetails.dataValues.duet,
                                liked_videos: privacyDetails.dataValues.liked_videos,
                                video_comment: privacyDetails.dataValues.video_comment,
                                direct_messages: privacyDetails.dataValues.direct_messages,
                            }
                        }
                        
                        allPosts[i].dataValues.video_comment_count = totalPostcomment?.length || 0;
                        allPosts[i].dataValues.totalRePost = totalRePost?.length || 0;
                        allPosts[i].dataValues.like_count = totalLikePost?.length || 0;
                        allPosts[i].dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0;

                        allPosts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                        allPosts[i].dataValues.rePostCount = rePostCount?.length || 0
                        allPosts[i].dataValues.favourite_count = favouritePost?.length || 0;
                        allPosts[i].dataValues.privacySetting = privacySetting;
                    

                        if (allPosts[i].dataValues.sound !== null) {
                            allPosts[i].dataValues.sound.audio = process.env.Sound_URL + '/' + allPosts[i].dataValues.sound.audio
                            allPosts[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                            allPosts[i].dataValues.sound.dataValues.video_count = soundCount?.length || 0 
                        }
                        else if (allPosts[i].dataValues.sound === null) {
                            allPosts[i].dataValues.sound = {}
                        }
                    }

                    allPosts[i].user.dataValues.followers = followers?.length || 0
                    allPosts[i].user.dataValues.followings = followings?.length || 0
                    allPosts[i].user.dataValues.totalPost = _posts?.length || 0
                    allPosts[i].user.dataValues.totalLikes = likes?.length || 0;

                    allPosts[i].user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
                    allPosts[i].user.dataValues.profile_pic = profilePic[0].dataValues.profile_pic

                }

            }
            return allPosts?.length > 0 ? allPosts : [];
            // return await Helper.successResponseWithData(res, 'posts_fetched', 'Posts has been fetched successfully',{recent_videos,trending_videos, video_count: 5});
        } catch (error) {
            console.log("______________________error is here", error);
            return false;
            // return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },

    getUserTrendingVideos: async (req, res) => {
        try {
            let data = req.body;
            if (!data.user_id) { return await Helper.ErrorResponse(res, 'user_id_req', 'user_id must be defined') }
            if (!data.start_datetime) { return await Helper.ErrorResponse(res, 'start_datetime_req', 'start_datetime must be defined') }
            if (!data.end_datetime) { return await Helper.ErrorResponse(res, 'end_datetime_req', 'end_datetime must be defined') }
                let userId = data.user_id
            
            let posts = "";
            let allPosts;
            let postPromises=[];
       
            // Push the promise for fetching posts to the postPromises array
            postPromises.push(
                // Post.findAll({
                //     where: { user_id: userId},
                    
                Post.findAll({
                    where: { user_id: userId, privacy_type: 'public', createdAt : {[Op.between] : [data.start_datetime , data.end_datetime ]} },
                    include: [
                        {
                            model: HashTagPost,
                            as: 'hashTags',
                            required: false,
                            include: [{
                                model: HashTag,
                                as: 'hashtag',
                                required: false
                            }]
                        },
                        {
                            model: PostLike,
                            as: 'likePost',
                            required: false,
                            include: [{
                                model: User,
                                as: 'user',
                                required: false,
                                attributes: ['id', 'first_name', 'email']
                            }]
                        },
                        {
                            model: PostComment,
                            as: 'comment',
                            required: false,
                            include: [{
                                model: User,
                                as: 'user',
                                required: false,
                                attributes: ['id', 'first_name', 'email', 'device', 'device_token']
                            }]
                        },
                        {
                            model: Sound,
                            as: 'sound',
                            required: false,
                            // separate: true, // Fetch comments separately
                        },
                        {
                            model: User,
                            as: 'user',
                            required: false,
                            attributes: ['id','username', 'first_name', 'device', 'device_token', 'last_name', 'profile_pic']
                        }
                    ],
                    limit: data?.limit || 10,
                    offset: data?.offset || 0,
                    order: [['view', 'DESC']]
                })
            );

            // Wait for all promises to resolve
            posts = await Promise.all(postPromises);

            // Concatenate the arrays of posts into a single array
            allPosts = posts.flat();
            

            let checkFollow
            let is_liked ,is_favourite;
            let soundCount;
            let soundFav;
            if (allPosts.length > 0) {
                
                for (let i = 0; i < allPosts.length; i++) {
                    allPosts[i].dataValues.video_hls = "https://vod.api.video/vod/" + allPosts[i].dataValues.old_video_id + "/hls/manifest.m3u8";
                    let followers = await Follower.findAll({ where: { receiver_id: allPosts[i].user_id } });
                    let followings = await Follower.findAll({ where: { sender_id: allPosts[i].user_id } });

                    let _posts = await Post.findAll({ where: { user_id: allPosts[i].user_id } });
                    let likes = await PostLike.findAll({ where: { user_id: allPosts[i].user_id } });
                    let profilePic = await User.findAll({where:{id:allPosts[i].user_id}})

                    
                    let rePostCount = await Repost.findAll({ where: { post_id: allPosts[i].id } });
                    if (userId) {
                        is_liked = await PostLike.findAll({ where: { post_id: allPosts[i].id, user_id: userId } });
                        checkFollow = await Follower.findAll({ where: { receiver_id: allPosts[i].user_id, sender_id: userId } });
                        is_favourite = await PostFavourite.findAll({ where: {post_id:allPosts[i].id,user_id:userId} });
                        
                        
                        if(allPosts[i].post && allPosts[i].post.sound && allPosts[i].post.sound.id ){
                            soundFav = await SoundFavourite.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id, user_id: userId } })
                        }
                        
                        // soundFav = await SoundFavourite.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id, user_id: userId } })
                    }
                    if(allPosts[i].post && allPosts[i].post.sound && allPosts[i].post.sound.id ){
                        soundCount =  await Post.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id } })
                    }
                    // let soundCount = await Post.findAll({ where: { sound_id: allPosts[i].dataValues.sound.id } })
                    


                    if (allPosts[i].id != null) {
                        let totalPostcomment = await PostComment.findAll({ where: { post_id: allPosts[i].id } });
                        let totalRePost = await Repost.findAll({ where: { post_id: allPosts[i].id } });
                        let totalLikePost = await PostLike.findAll({ where: { post_id: allPosts[i].id } })
                        let favouritePost = await PostFavourite.findAll({ where: { post_id: allPosts[i].id } })
                        const privacyDetails = await PrivacySetting.findOne({
                            where: {
                                user_id: allPosts[i].user_id
                            }
                        });
                        let privacySetting = {};
                        if(privacyDetails){
                            privacySetting = {
                                videos_download: privacyDetails.dataValues.videos_download,
                                direct_message: privacyDetails.dataValues.direct_message,
                                duet: privacyDetails.dataValues.duet,
                                liked_videos: privacyDetails.dataValues.liked_videos,
                                video_comment: privacyDetails.dataValues.video_comment,
                                direct_messages: privacyDetails.dataValues.direct_messages,
                            }
                        }
                        
                        allPosts[i].dataValues.video_comment_count = totalPostcomment?.length || 0;
                        allPosts[i].dataValues.totalRePost = totalRePost?.length || 0;
                        allPosts[i].dataValues.like_count = totalLikePost?.length || 0;
                        allPosts[i].dataValues.is_favourite = favouritePost?.length > 0 ? 1 : 0;

                        allPosts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0
                        allPosts[i].dataValues.rePostCount = rePostCount?.length || 0
                        allPosts[i].dataValues.favourite_count = favouritePost?.length || 0;
                        allPosts[i].dataValues.privacySetting = privacySetting;
                    

                        if (allPosts[i].dataValues.sound !== null) {
                            allPosts[i].dataValues.sound.audio = process.env.Sound_URL + '/' + allPosts[i].dataValues.sound.audio
                            allPosts[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                            allPosts[i].dataValues.sound.dataValues.video_count = soundCount?.length || 0 
                        }
                        else if (allPosts[i].dataValues.sound === null) {
                            allPosts[i].dataValues.sound = {}
                        }
                    }

                    allPosts[i].user.dataValues.followers = followers?.length || 0
                    allPosts[i].user.dataValues.followings = followings?.length || 0
                    allPosts[i].user.dataValues.totalPost = _posts?.length || 0
                    allPosts[i].user.dataValues.totalLikes = likes?.length || 0;

                    allPosts[i].user.dataValues.button = checkFollow?.length ? "Following" :"Follow"
                    allPosts[i].user.dataValues.profile_pic = profilePic[0].dataValues.profile_pic

                }

            }
            return allPosts?.length > 0 ? allPosts : [];
        } catch (error) {
            console.log("______________________error is here", error);
            return false;
            // return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },

    getUserVideosCount: async (req, res) => {
        try {
            let data = req.body;
            let totalVideoCount = 0;
            if (!data.user_id) { return await Helper.ErrorResponse(res, 'user_id_req', 'user_id must be defined') }
             let allPosts = await Post.findAll({
                where: { user_id: data.user_id },
            });
         
            totalVideoCount = allPosts?.length > 0 ? allPosts?.length : 0;

            return totalVideoCount;
        } catch (error) {
            console.log("______________________error is here", error);
            return false;
        }
    },
}


PostController.showUserVideosTrendingAndRecent = async (req, res) => {
    try{
        let recent_videos = await PostController.getUserRecentVideos(req, res);
        let trending_videos = await PostController.getUserTrendingVideos(req, res);
        let video_count = await PostController.getUserVideosCount(req, res);;
        let responseObj = {recent_videos, trending_videos, video_count}
        return await Helper.successResponseWithData(res, 'posts_fetched', 'Posts has been fetched successfully', responseObj);

    } catch (error) {
        console.log("__________________________________error", error);
        return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
    }

}

module.exports = PostController;
