require("dotenv").config();
const { Validator } = require("node-input-validator");
const { Setting, Language, Category, User,ReportReason, Sound, SoundFavourite,PushNotification,NotificationMessages,Post ,
    HashTagPost,HashTag,PostLike,PostComment,Follower,PostFavourite,Repost,TransactionHistory,send_gift,promotion,PostView} = require('../../models');
const Cryptr = require("cryptr");
const { STATUSCODE, SUCCESSMESSAGE, CUSTOM_MESSAGE } = require('../utils/constant')
const Helper = require("../utils/helper");
const moment = require('moment');
const { where, Op, Transaction } = require("sequelize");
const db = require("../../models");
const axios = require('axios');

var SettingController = {
    /**
       * Developer => Prince
       * Function to auto login user in the system
       * 
       */
    fetchSetting: async (req, res) => {
        const transaction = await Setting.sequelize.transaction();
        try {
            let settings = await Setting.findAll({ limit: 1 });
            await transaction.commit();
            return await Helper.successResponseWithData(res, "200", "setting has been fetched successfully", settings);
        } catch (error) {
            console.log(error)
            if (transaction) { await transaction.rollback(); }
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    fetchLanguage: async (req, res) => {
       // const transaction = await Language.sequelize.transaction();
        try {
            let languages = await Language.findAll({
                //group:'title',
                order: [['createdAt', 'DESC']]
            });
            // if we get here they ran successfully, so...
           // await transaction.commit();
            return await Helper.successResponseWithData(res, "language_fetched", "language has been fetched successfully", languages);
        } catch (error) {
            console.log("_____________________________________________Error is here", error);
           // if (transaction) { await transaction.rollback(); }
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    fetchCategory: async (req, res) => {
       // const transaction = await Category.sequelize.transaction();
        try {
            let categories = await Category.findAll({
                attributes: ['id', 'title', 'status', 'createdAt'],
                order: [['createdAt', 'DESC']]
            });
            return await Helper.successResponseWithData(res, 'category_fetched', 'category has been fetched successfully', categories);
        } catch (error) {
            console.log("______________________________________error is here", error);
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },

    /**
        * Developer  :Anshuman
        * Api to change setttings in
        * * cases
                1. Notification enable/disable
                2. Mute/Unmute
                3. Block/Unblock
                4. lock/unlock profile
        */
    changeSetting: async (req, res) => {

        try {
            let data = req.body;
            let user_id = req.AuthUser.id;
            if(user_id != req.AuthUser?.id){
                var message = 'message response';// `${checkUserExist?.first_name} has started live streaming.`;
                let payload = {
                    unique_id: req.AuthUser?.unique_id,
                    username: req.AuthUser.username,
                    user_id: req.AuthUser.id,
                    sender_id: req.AuthUser.id,
                    receiver_id: user_id,
                    video_id: '',
                    image: checkUserExist?.profile_pic,
                    title: message,
                    type: 'Chat_Notif',
                }
                await Helper.sendPushNotification2(req, user_id, process.env.APP_NAME, message, payload);

                // let notificationResponse = await Helper.sendPushNotification2(req, user_id, 'message title', 'message response')
                await NotificationMessages.create({sender_id:req.AuthUser.id,receiver_id:user_id,message: 'message response',type:"Chat_Notif"})
            }

            if (Object.keys(data)?.length == 0) {
                return await Helper.ErrorResponse(res, 'no_settings_provided', 'Settings are not availbale');
            }
            let globalUser = await User.findOne({ where: { id: user_id } });
            // case 1 : Notification enable/disabled
            if (data.type = 1) {
                if (!data.is_notification) return await Helper.ErrorResponse(res, 'is_notification_req', 'notification value is required');

                globalUser.set({ is_notification: data.is_notification })

                if (await globalUser.save()) {
                    return await Helper.successResponseWithData(res, 'setting_updated', 'Notification enabled/disabled', globalUser);
                } else {
                    return await Helper.successResponseWithData(res, 'setting_updated', 'Notification enabled/disabled', globalUser);

                }
            }
            // case 1 : Notification enable/disable
            if (data.type = 2) {
                return await Helper.successResponseWithData(res, 'case_two', 'Mute/Unmute');
            }
            // case 1 : Notification enable/disable
            if (data.type = 3) {
                return await Helper.successResponseWithData(res, 'case_three', ' Block/Unblock');
            }

        } catch (error) {
            console.log("______________________________________error is here", error);
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    /**
        * Developer  :Prince
        * fetch All Report Reason
        * * cases
    */
    fetchAllReportReason:async (req,res) => {
        try {
            let reason=await ReportReason.findAll({attributes:['id','title','status'],order:[['createdAt','DESC']]});
            return await Helper.successResponseWithData(res, 'reason_fetched', 'Reason has been fetched successfully',reason);
        } catch (error) {
            console.log("_____________________________________Error is here",error);
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    /**
        * Developer  :Prince
        * fetch All sound
        * * cases
    */
    fetchAllSound:async (req,res) => {
        try {
            let data=req.body;
            let sound=await Sound.findAll({
                limit:data.limit || 10,
                offset:data.offset || 0,
                order:[['createdAt','DESC']]
            })

            for (let i = 0; i < sound.length; i++) {

                sound[i].dataValues.audio = process.env.Sound_URL + '/' + sound[i].dataValues.audio

                if (sound[i].id != null) {
                    let is_favourite = await SoundFavourite.findAll({ where: { sound_id: sound[i].id, user_id: req.AuthUser.id } });
                    sound[i].dataValues.is_favourite = is_favourite?.length > 0 ? 1 : 0;
                    
                }

            }
            return await Helper.successResponseWithData(res, 'sound_fetched', 'Sound has been fetched successfully', sound);
        } catch (error) {
            console.log("__________________________________________",error.message);
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    /**
        * Developer  :Prince
        * sound Favorite
        * * cases
    */ 
    soundFavorite: async (req,res) => {
        try {
            // let data=req.body;
            // if(!data.sound_id){return await Helper.ErrorResponse(res,'sound_id_req','sound id must be defined')}
            // let checkSoundExists=await Sound.findOne({where:{id:data.sound_id}});
            // if(checkSoundExists){
            //     let sound = await SoundFavourite.create({user_id:req.AuthUser.id,sound_id:data.sound_id});
            //     return await Helper.successResponseWithData(res, 'fav_sound_added', 'favorite Sound has been added successfully', sound);
            // } else {
            //     return await Helper.ErrorResponse(res, 'sound_not_found', 'Sound not found');
            // }

            let data=req.body;
            if(!data.sound_id){return await Helper.ErrorResponse(res,'sound_id_req','sound id must be defined')}
            let checkSoundExists=await Sound.findOne({where:{id:data.sound_id}});
            if(!checkSoundExists){return await Helper.ErrorResponse(res,'sound_not_found','sound not found')}
           
            let checkFavSoundExists = await SoundFavourite.findOne({ where: { sound_id: data.sound_id ,user_id:req.AuthUser.id} });

            if (checkFavSoundExists) {
                await SoundFavourite.destroy({ where: {sound_id:data.sound_id,user_id:req.AuthUser.id} });
                return await Helper.ErrorResponse(res, 'already_favorite', 'this sound is already favorite')
            }
            let sound = await SoundFavourite.create({user_id:req.AuthUser.id,sound_id:data.sound_id});
            if(sound){return await Helper.successResponseWithData(res,'fav_sound_added', 'favorite Sound has been added successfully', sound)}
        } catch (error) {
            console.log("______________________________error is here",error)
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    /**
        * Developer  :Prince
        * fetch Favorite Sound
        * * cases
    */
    fetchFavoriteSound: async (req,res) => {
        try {
            let data=req.body;
            let sound= await SoundFavourite.findAll({
                include:[{
                    model:User,
                    as:'user',
                    required:false,
                    attributes:['id','first_name','last_name','profile_pic','dob']
                },{
                    model:Sound,
                    as:'sound',
                    required:false
                }],
                where:{user_id:req.AuthUser.id},
                order:[['createdAt','DESC']],
                limit:data.limit || 10,
                offset:data.offset || 0
            });
            
            for(let i=0;i<sound.length;i++){
                
                let soundFav = await SoundFavourite.findAll({ where: { sound_id: sound[i].dataValues.sound.id, user_id: req.AuthUser.id } })
                sound[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;

                    let soundCount = await Post.findAll({ where: { sound_id: sound[i].dataValues.sound.id} })
                    sound[i].dataValues.sound.dataValues.video_count = soundCount?.length || 0
              
                if (sound[i].dataValues.sound !== null) {
                    sound[i].dataValues.sound.audio = process.env.Sound_URL  + '/' + sound[i].dataValues.sound.audio
                }
            }
            return await Helper.successResponseWithData(res, 'fav_sound_fetched', 'favorite Sound has been fetched successfully', sound);
        } catch (error) {
            console.log("_______________________________________Error is here",error.message);
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },

    updatePushNotificationSettings: async (req,res) => {
        try {
            const { user_id, likes, comments, new_followers, mentions, direct_messages, video_updates } = req.body;
            
            const notification = {};
            if (likes !== undefined) {
                notification.likes = likes;
            }
            if (comments !== undefined) {
                notification.comments = comments;
            }
            if (new_followers !== undefined) {
                notification.new_followers = new_followers;
            }
            if (mentions !== undefined) {
                notification.mentions = mentions;
            }
            if (direct_messages !== undefined) {
                notification.direct_messages = direct_messages;
            }
            if (video_updates !== undefined) {
                notification.video_updates = video_updates;
            }

            const details = await PushNotification.findOne({where:{id:user_id}})
            console.log("check push notification---",!!details,notification)
    
            if (!!details) {
                await PushNotification.update(notification,{where:{id:user_id}})
                let updatedDetails = await PushNotification.findOne({where:{id:user_id}})
    
                return await Helper.successResponseWithData(res, '200', 'Notifcation has been updated Successfully.', updatedDetails);
            } else {
                notification.id = user_id;
                const newDetails = await PushNotification.create(notification);
                console.log("else part")
    
                return await Helper.successResponseWithData(res, '200', 'Notifcation is created Successfully',newDetails);
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    },

    fetchSound: async (req,res) => {
        // try {
        //     let soundList = [
        //         {
        //         thumbnail:"",
        //         artistname:"arijit singh",
        //         title:"",
        //         duration:"",
        //         audioUrl:"https://samplesongs.netlify.app/Death%20Bed.mp3"
        //     },
        // ]
        //     return await Helper.successResponseWithData(res, 'fav_sound_fetched', 'favorite Sound has been fetched successfully', soundList);
        // } catch (error) {
        //     console.error('Error fetching sounds:', error);
        // }

        try {
            // Make GET request to the URL
            const response = await axios.get('https://gist.githubusercontent.com/Jetrom17/380adb1d9d7b6f23a948759b48fce64e/raw/278e42d5c8256240e4f01d050521930f420cca89/music-info.json');
    
            // Extract data from response
            const musicInfo = response.data;
    
            return await Helper.successResponseWithData(res, 'fav_sound_fetched', 'favorite Sound has been fetched successfully', musicInfo);
        } catch (error) {
            // Handle error
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    
    fetchNotification: async (req,res) => {
    
        try {
           let data = req.body 

           let notifData = await NotificationMessages.findAll({
            include:[
                {
                model:User,
                as:'user',
                required:false,
                attributes:['id','first_name','last_name','profile_pic','username'],
                // include: [{
                //     model: Post,
                //     as: 'posts',
                //     required: false,
                //     seperate:true,
                //     where: {
                //         // Filter posts only if the type is 'post'
                //         '$NotificationMessages.type$': 'Post'
                //     }
                // }]
                
            },
           
        ],
        // limit: data?.limit || 10,
        // offset: data?.offset || 0,
        order: [['createdAt', 'DESC']],
        where:{receiver_id:req.AuthUser.id}
        })

        for(let i=0;i<notifData.length;i++){
            console.log("-------------------",notifData[i])
            notifData[i].user.dataValues.button = ''
            notifData[i].dataValues.live_streaming_id = ''
            if(notifData[i].type = 'post'){
                notifData[i].dataValues.post = {}
            }
        }

            return await Helper.successResponseWithData(res, 'notif_list_fetched', 'Notification list has been fetched successfully', notifData);
        } catch (error) {
            // Handle error
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    showVideosAgainstSound: async (req,res) => {
    
        try {
           let data = req.body 
           let posts = await Post.findAll({
            where:{sound_id:data.sound_id}
           },{
            include: [
                // {
                //     model: HashTagPost,
                //     as: 'hashTags',
                //     required: false,
                //     separate: true, // Fetch comments separately
                //     include: [
                //         {
                //             model: HashTag,
                //             as: 'hashtag',
                //             required: false
                //         }
                //     ]
                // }, 
                // {
                //     model: PostLike,
                //     as: 'likePost',
                //     required: false,
                //     separate: true, // Fetch likes separately
                //     include: [
                //         {
                //             model: User,
                //             as: 'user',
                //             required: false,
                //             attributes: ['id', 'first_name', 'email']
                //         }
                //     ]
                // }, 
                // {
                //     model: PostComment,
                //     as: 'comment',
                //     required: false,
                //     separate: true, // Fetch comments separately
                //     include: [
                //         {
                //             model: User,
                //             as: 'user',
                //             required: false,
                //             attributes: ['id', 'first_name', 'email', 'device', 'device_token']
                //         }
                //     ]
                // },
                // {
                //     model: Sound,
                //     as: 'sound',
                //     required: false,
                //     separate: true, // Fetch comments separately
                // },
                // {
                //     model: User,
                //     as: 'user',
                //     required: false,
                //     attributes: ['id', 'first_name', 'device', 'device_token','username'],
                //     separate: true, // Fetch comments separately
                // }
            ],
            limit:data.limit || 10,
            offset: data?.offset || 0,
            subQuery: false,
            order: [['createdAt', 'DESC']]
        });
        
       
            let is_liked = 0;
            let is_favourite = 0
            let checkFollow;

            if (posts.length > 0) {
                for (let i = 0; i < posts.length; i++) {
                    console.log("-----------------------------------",posts)
                    let followers = await Follower.findAll({ where: { receiver_id: posts[i].user_id } });
                    let followings = await Follower.findAll({ where: { sender_id: posts[i].user_id } });

                    let _posts = await Post.findAll({ where: { user_id: posts[i].user_id } });
                    let likes = await PostLike.findAll({ where: { user_id: posts[i].user_id } });
                    let sound = await Sound.findOne({where:{id:posts[i].sound_id}})
                   

                    let hashtag = await HashTagPost.findAll({where:{post_id:posts[i].id}})
                    let postLike = await PostLike.findAll({where:{post_id:posts[i].id}})
                    let postComment = await PostComment.findAll({where:{post_id:posts[i].id}})
                    let user = await User.findOne({where:{id:posts[i].user_id},attributes: ['id', 'first_name','username','last_name', 'email', 'device', 'device_token','profile_pic']})
                    checkFollow = await Follower.findAll({ where: { receiver_id: posts[i].user_id, sender_id: posts[i].user_id } });
                    let soundFav = await SoundFavourite.findAll({where:{sound_id:data.sound_id,user_id:req.AuthUser.id}})
                    

                    posts[i].dataValues.hashtags = hashtag 
                    posts[i].dataValues.likePost = postLike
                    posts[i].dataValues.comment = postComment
                    posts[i].dataValues.sound  = sound
                    posts[i].dataValues.user = user

                   posts[i].dataValues.user.dataValues.followers = followers?.length || 0
                   posts[i].dataValues.user.dataValues.followings = followings?.length || 0
                   posts[i].dataValues.user.dataValues.totalPost = _posts?.length || 0
                   posts[i].dataValues.user.dataValues.totalLikes = likes?.length || 0

                   posts[i].dataValues.sound.dataValues.is_favourite = soundFav?.length > 0 ? 1 : 0;
                   

                    posts[i].dataValues.user.dataValues.button = checkFollow?.length ? "Following" : "Follow"

                    if (posts[i].id != null) {
                        console.log("-------------------------",posts[i].dataValues.sound,process.env.Sound_URL)
                        let totalPostcomment = await PostComment.findAll({ where: { post_id: posts[i].id } });
                        let totalRePost = await Repost.findAll({ where: { post_id: posts[i].id } });
                        let totalLikePost = await PostLike.findAll({ where: { post_id: posts[i].id } })
                        let favouritePost = await PostFavourite.findAll({ where: { post_id: posts[i].id } })

                        is_liked = await PostLike.findAll({ where: { post_id: posts[i].id, user_id: posts[i].user_id } });
                        is_favourite = await PostFavourite.findAll({ where: { post_id: posts[i].id, user_id: posts[i].user_id } });

                        let rePostCount = await Repost.findAll({ where: { post_id: posts[i].id } });

                        posts[i].dataValues.video_comment_count = totalPostcomment?.length || 0;
                        posts[i].dataValues.totalRePost = totalRePost?.length || 0;
                        posts[i].dataValues.like_count = totalLikePost?.length || 0;
                        posts[i].dataValues.is_favourite = is_favourite?.length > 0 ? 1 : 0;
                        posts[i].dataValues.favourite_count = favouritePost?.length || 0;


                        posts[i].dataValues.is_like = is_liked?.length > 0 ? 1 : 0

                        posts[i].dataValues.rePostCount = rePostCount?.length || 0
                        if (posts[i].dataValues.sound !== null) {
                            posts[i].dataValues.sound.audio = process.env.Sound_URL  + '/' + posts[i].dataValues.sound.audio 
                            posts[i].dataValues.sound.dataValues.video_count = posts?.length || 0
                        }

                    }


                    posts[i].dataValues.video_hls = "https://vod.api.video/vod/" + posts[i].dataValues.old_video_id + "/hls/manifest.m3u8";
                    // console.log(posts);
                }
            }

            return await Helper.successResponseWithData(res, 'sound_post_fetched', 'sound post list has been fetched successfully', posts);
        } catch (error) {
            // Handle error
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    transactionHistory: async (req,res) => {
    
        try {
           let data = req.body  
           if (!req.AuthUser.id) {
            return await Helper.ErrorResponse(res, 'user_id is required')
        }
           let posts = await TransactionHistory.findAll({
            where:{user_id:req.AuthUser.id}
           },{
            
            // limit:data.limit || 10,
            // offset: data?.offset || 0,
            subQuery: false,
            order: [['createdAt', 'DESC']]
        });
        
          console.log("------------------",posts,req.AuthUser.id)
            return await Helper.successResponseWithData(res, 'transaction_history fetched', 'Transaction history has been fetched successfully', posts);
        } catch (error) {
            // Handle error
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    wallet: async (req, res) => {

        try {
            let data = req.body
            if (!req.AuthUser.id) {
                return await Helper.ErrorResponse(res, 'user_id is required')
            }
            let rewards = await User.findOne({
                attributes: ['id','like_points','comments_points','share_points','uploadPost_points','referral_points'],
                where: { id: req.AuthUser.id }
            }, {

                subQuery: false,
                order: [['createdAt', 'DESC']]
            });
           
            let arr = []

            let checkSendGift = await send_gift.findAll({where:{sender_id:req.AuthUser.id}})
            // Extract coin values and sum them up
            const sum = checkSendGift.reduce((accumulator, currentGift) => {
                return accumulator + parseInt(currentGift.coin);
            }, 0);

            let checkReceiveGift = await send_gift.findAll({where:{receiver_id:req.AuthUser.id}})
            // Extract coin values and sum them up
            const receive = checkReceiveGift.reduce((accumulator, currentGift) => {
                return accumulator + parseInt(currentGift.coin);
            }, 0); 

            arr.push(
                {title:"Total earning",points:rewards.like_points + rewards.comments_points +rewards.uploadPost_points +rewards.referral_points +receive}, 
                {title:"Total spending",points:sum},
                {title:"Referral",points:rewards.referral_points}, 
                {title:"Daily Check in",points:0},
                {title:"Post Uploded",points:rewards.uploadPost_points}, 
                {title:"Gifts",points:receive},
                // {title:"Like share and comments",points: rewards.like_points + rewards.comments_points}
                {title:"Like ",points: rewards.like_points },
                {title:"share",points: 0},
                {title:"comments",points: rewards.comments_points}
                )
         
       
            return await res.send({
                status: true,
                code: "transaction_points fetched",
                message: "Transaction points has been fetched successfully",
                id:rewards.id,
                totalPoint:rewards.like_points + rewards.comments_points +rewards.uploadPost_points +rewards.referral_points +receive - sum,
                data: arr
            });
        } catch (error) {
            // Handle error
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },
    showPromotion: async (req, res) => {

        try {
            const {  start_datetime, end_datetime, starting_point } = req.body;
            let user_id = req.AuthUser.id

            // coin spend 
            let checkSendGift = await send_gift.findAll({where:{sender_id:req.AuthUser.id}})
            // Extract coin values and sum them up
            const sum = checkSendGift.reduce((accumulator, currentGift) => {
                return accumulator + parseInt(currentGift.coin);
            }, 0);

            //total likes 
            let likes = await User.findOne({where:{id:req.AuthUser.id}})

            //total views
            let views = await PostView.findAll({where:{user_id:req.AuthUser.id}}) 

           
    
            const details = await promotion.findAll({
                where: {
                    user_id,
                    // start_datetime,
                    // end_datetime,
                    // starting_point
                }
            });
    
            if (details.length > 0) {
                let total_coins = 0;
                let total_destination_tap = 0;
                let total_likes = 0;
                let total_views = 0;
    
                for (const detail of details) {
                    const { video_id, coin, destination_tap, start_datetime, end_datetime } = detail;
    
                    // const count_views = await VideoWatch.count({
                    //     where: {
                    //         video_id,
                    //         start_datetime,
                    //         end_datetime
                    //     }
                    // });
    
                    // const count_likes = await VideoLike.count({
                    //     where: {
                    //         video_id,
                    //         start_datetime,
                    //         end_datetime
                    //     }
                    // });
    
                    detail.dataValues.video_views = views.length;
    
                    total_coins += sum.length;
                    total_destination_tap += destination_tap;
                    total_likes += likes.length;
                    total_views += views.length;
                }
    
                const output = {
                    code: 200,
                    msg: {
                        Details: details,
                        Stats: {
                            total_coins,
                            total_destination_tap,
                            total_likes,
                            total_views
                        }
                    }
                };
    
                res.json(output);
                // return await Helper.successResponseWithData(res, 'promotion fetched', 'Promotion has been fetched successfully');
            } else {
                res.status(404).json({ error: 'No data found' });
            }
        } catch (error) {
            console.error('Error:', error);
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    }
}
module.exports = SettingController;