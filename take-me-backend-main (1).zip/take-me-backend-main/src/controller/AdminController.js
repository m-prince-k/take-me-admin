const { Validator } = require("node-input-validator");
const db = require('../../models');
const { User } = db;
const Cryptr = require("cryptr");
const { STATUSCODE, SUCCESSMESSAGE, CUSTOM_MESSAGE } = require('../utils/constant')
const Helper = require("../utils/helper");
const moment = require('moment');

require("dotenv").config();


var AdminController = {
     /**
    * Developer => Anshuman
    * Function to signup
    * 
    */
    signup: async (req, res) => {

        try {
            // manual login
            let data = req.body;
            if (!data.email) {
                return await Helper.ErrorResponse(res, 'email_req', 'Email id is required')
            }
            if (!data.username) {
                return await Helper.ErrorResponse(res, 'username_req', 'Password field is required')
            }
            if (!data.first_name) {
                return await Helper.ErrorResponse(res, 'first_name_req', 'First name is required')
            }

            let user = await User.findOne({ where: { email: data.email } })
            if (user != null && Object.keys(user)?.length > 0) {

                let token = await Helper.generateToken({ email: user?.email, id: user.id }, process.env.JWT_SECRET_REF, { expiresIn: process.env.JWT_EXPIRES });

                user.datValues.accessToken = token

                return await Helper.successResponseWithData(res, 'admin_logged_in', 'admin logged in successfully', user);
            } else {

                let insertObject = {
                    first_name: data.first_name,
                    email: data.email,
                    username: data.first_name,
                    role: 2,
                }
                data.last_name ? insertObject.last_name = data.last_name : null;
                data.gender ? insertObject.gender = data.gender : null;
                data.bio ? insertObject.bio = data.bio : null;
                data.dob ? insertObject.dob = data.dob : null;
                data.website ? insertObject.website = data.website : null;
                data.phone ? insertObject.phone = data.phone : null;
                data.profile_pic ? insertObject.profile_pic = data.profile_pic : null;
                data.ip ? insertObject.ip = data.ip : null;

                let newUser = await User.create(insertObject);
                if (newUser) {

                    let token = await Helper.generateToken({ email: newUser?.email, id: newUser.id }, process.env.JWT_SECRET_REF, { expiresIn: process.env.JWT_EXPIRES });

                    newUser.datValues.accessToken = token

                    return await Helper.successResponseWithData(res, 'admin_register_success', 'admin registered successfully', newUser);
                } else {
                    return await Helper.ErrorResponse(res, 'admin_register_failed', 'admin registration failed');
                }
            }

        } catch (error) {

            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },

     /**
    * Developer => Anshuman
    * Function to blockUser
    * 
    */
    blockUser: async (req, res) => {
        try {

            let current_user_id = req.AuthUser.id;
            let block_user_id = req.body.user_id;

            if (!block_user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User id is required')
            }
            if (current_user_id == block_user_id) {
                return await Helper.ErrorResponse(res, 'self_blocking', 'Self blocking is not allowed')
            }

            let tobeBlockedUser = await User.findOne({ where: { id: block_user_id } });
            if (tobeBlockedUser != null && Object.keys(tobeBlockedUser)?.length > 0) {
                if (tobeBlockedUser?.is_block) {
                    return await Helper.ErrorResponse(res, 'user_already_blocked', 'This user is already blocked')
                }

                // updating user now
                tobeBlockedUser.set({
                    is_block: true
                })

                if (await tobeBlockedUser.save()) {
                    return await Helper.successResponseWithData(res, 'user_block_success', 'User blocked successfully', tobeBlockedUser);
                } else {
                    return await Helper.ErrorResponse(res, 'user_block_failed', 'User could not be blocked')

                }

            } else {
                return await Helper.ErrorResponse(res, 'user_block_unavailbe', 'User to be blocked is not found');
            }

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);

        }
    },

     /**
    * Developer => Anshuman
    * Function to unblockUser
    * 
    */
    unblockUser: async (req, res) => {
        try {

            let current_user_id = req.AuthUser.id;
            let unblock_user_id = req.body.user_id;

            if (!unblock_user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User id to be unblocked is required')
            }
            if (current_user_id == unblock_user_id) {
                return await Helper.ErrorResponse(res, 'self_unblocking', 'Self unblocking is not allowed')
            }

            let tobeBlockedUser = await User.findOne({ where: { id: unblock_user_id } });
            if (tobeBlockedUser != null && Object.keys(tobeBlockedUser)?.length > 0) {
                if (!tobeBlockedUser?.is_block) {
                    return await Helper.ErrorResponse(res, 'user_already_unblocked', 'This user is already unblocked')
                }

                // updating user now
                tobeBlockedUser.set({
                    is_block: true
                })

                if (await tobeBlockedUser.save()) {
                    return await Helper.successResponseWithData(res, 'user_unblock_success', 'User unblocked successfully', tobeBlockedUser);
                } else {
                    return await Helper.ErrorResponse(res, 'user_block_failed', 'User could not be unblocked')

                }

            } else {
                return await Helper.ErrorResponse(res, 'user_block_unavailbe', 'User to be blocked is not found');
            }

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);
        }
    },

     /**
    * Developer => Anshuman
    * Function to updateUser
    * 
    */
    updateUser: async (req, res) => {
        try {
            let user;

            let data = req.body;

            if (!data.user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'user id is required to update the user');
            }
            // let data = await User.findAll();
            let v = await new Validator(req.body, {
                // phone_code: "required",

            }, { /** "first_name.required": customMessage.validationRule.FIRST_NAME, **/ }
            );

            let checks = await v.check();
            if (!checks) {
                return await Helper.ErrorResponse(res, STATUSCODE.HTTP_SUCCESS, 'Validation error', v.errors)

            } else {

                let checkUserExistORNot = await User.findOne({ where: { id: data.user_id } });

                if (!checkUserExistORNot?.id) {
                    return await Helper.ErrorResponse(res, 'user_not_found', 'User is not found')
                } else {

                    let updateObj = {
                        first_name: req.body.first_name,
                    }

                    if (req.body.last_name) {
                        updateObj.last_name = req.body.last_name
                    }
                    if (req.body.gender) {
                        updateObj.gender = req.body.gender
                    }
                    if (req.body.bio) {
                        updateObj.bio = req.body.bio
                    }
                    if (req.body.dob) {
                        updateObj.dob = req.body.dob
                    }
                    if (req.body.phone) {
                        updateObj.phone = req.body.phone
                    }
                    if (req.body.phone_code) {
                        updateObj.phone_code = req.body.phone_code
                    }
                    if (req.body.profile_pic) {
                        updateObj.profile_pic = req.body.profile_pic
                    }
                    if (req.body.website) {
                        updateObj.website = req.body.website
                    }

                    checkUserExistORNot.set(updateObj);

                    if (await checkUserExistORNot.save()) {

                        return Helper.successResponseWithData(res, 'user_updated', 'User updated successfully', checkUserExistORNot)
                    }

                }
            }
            // return res.json({ status: true, data: { id: user?.id }, message: SUCCESSMESSAGE.REGISTRATION_SUCCESS })
        } catch (error) {
            return await Helper.ErrorResponse(res, "internal_server_error", error.message);
        }
    },

     /**
    * Developer => Anshuman
    * Function to verifyUser
    * 
    */
    verifyUser: async (req, res) => {
        try {

            let current_user_id = req.AuthUser.id;
            let verify_user_id = req.body.user_id;

            if (!verify_user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User id to be verified is required')
            }
            if (current_user_id == verify_user_id) {
                return await Helper.ErrorResponse(res, 'self_verification', 'Self verification is not allowed')
            }

            let tobeVerifiedUser = await User.findOne({ where: { id: verify_user_id } });
            if (tobeVerifiedUser != null && Object.keys(tobeVerifiedUser)?.length > 0) {
                if (tobeVerifiedUser?.verified) {
                    return await Helper.ErrorResponse(res, 'user_already_verified', 'This user is already verified')
                }
                // updating user now
                tobeVerifiedUser.set({
                    verified: '1'
                })

                if (await tobeVerifiedUser.save()) {

                    return await Helper.successResponseWithData(res, 'user_verify_success', 'User blocked successfully', tobeVerifiedUser);
                } else {
                    return await Helper.ErrorResponse(res, 'user_verify_failed', 'User could not be verified')

                }

            } else {
                return await Helper.ErrorResponse(res, 'user_unavailbe', 'User to be verify is not found');
            }

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);

        }
    },

     /**
    * Developer => Anshuman
    * Function to users
    * 
    */
    users: async (req, res) => {
        try {

            let users = await User.findAll({
                attributes: ['first_name', 'last_name', 'email', 'username']
            });
            if (!users) {
                return await Helper.ErrorResponse(res, 'user_unavailbe', 'No users are found');
            } else {
                return await Helper.successResponseWithData(res, 'user_retrieved', 'User retrieved successfully', users);
            }

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);

        }
    },

     /**
    * Developer => Anshuman
    * Function to viewUserById
    * 
    */
    viewUserById: async (req, res) => {
        try {

            let user_id = req.body.user_id;

            if (!user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User id is required');
            }

            let users = await User.findOne();
            if (!users) {
                return await Helper.ErrorResponse(res, 'user_unavailbe', 'No users are found');
            } else {
                return await Helper.successResponseWithData(res, 'user_retrieved', 'User retrieved successfully', users);
            }

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message);

        }
    },




}

module.exports = AdminController