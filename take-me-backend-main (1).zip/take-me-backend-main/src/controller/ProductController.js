const { Validator } = require("node-input-validator");
const db = require('../../models');
const { Product, User, Category } = db;
const Cryptr = require("cryptr");
const { STATUSCODE, SUCCESSMESSAGE, CUSTOM_MESSAGE } = require('../utils/constant')
const Helper = require("../utils/helper");
const moment = require('moment');

require("dotenv").config();

var ProductController = {
    fetchProducts: async (req, res) => {

        let data = req.body;

        try {
            let products = await Product.findAll({
                // attributes: ['category_id', 'user_id', 'title', 'description', 'size', 'price', 'sale_price', 'promote', 'status', 'view', 'order_no'],
                include: [{
                    model: Category,
                    as: 'categoryDetail',
                    required: false,
                    // attributes: ['title', 'status']
                }, {
                    model: User,
                    as: 'userDetail',
                    required: false,
                    // attributes: ['first_name', 'last_name', 'email', 'status', 'phone', 'profile_pic']
                }],
                limit: data?.limit || 10,
                offset: data?.offset || 0,
                subQuery: false
            })

            if (!products) {
                return await Helper.ErrorResponse(res, 'product_fetch_error', 'Products could not be fetched');
            }
            return await Helper.successResponseWithData(res, 'products_fetched_success', 'Proudcts retrieved successfully', products)
        } catch (error) {

        }
    },
    fetchProductsByUserId: async (req, res) => {

        try {

            let data = req.body;
            let user_id = req.AuthUser.id;
            if (data.user_id) {
                user_id = data.user_id
            }

            if (!user_id) {
                return await Helper.ErrorResponse(res, 'user_id_req', 'User id is required')
            }


            let products = await Product.findAll({
                // attributes: ['category_id', 'user_id', 'title', 'description', 'size', 'price', 'sale_price', 'promote', 'status', 'view', 'order_no'],
                include: [{
                    model: Category,
                    as: 'categoryDetail',
                    required: false,
                    // attributes: ['title', 'status']
                }, {
                    model: User,
                    as: 'userDetail',
                    required: false,
                    // attributes: ['first_name', 'last_name', 'email', 'status', 'phone', 'profile_pic']
                }],
                where: { user_id: user_id },
                limit: data?.limit || 10,
                offset: data?.offset || 0,
                subQuery: false
            })

            if (!products) {
                return await Helper.ErrorResponse(res, 'product_fetch_error', 'Products could not be fetched');
            }
            return await Helper.successResponseWithData(res, 'products_fetched_success', 'Proudcts retrieved successfully', products)
        } catch (error) {

        }
    },

    fetchProductById: async (req, res) => {

        try {
            let product_id = req.body.product_id;
            if (!product_id) {
                return await Helper.ErrorResponse(res, 'product_id_error', 'Product id is rquired');
            }
            let products = await Product.findAll({
                attributes: ['category_id', 'user_id', 'title', 'description', 'size', 'price', 'sale_price', 'promote', 'status', 'view', 'order_no'],
                where: {
                    id: product_id
                },
                include: [{
                    model: Category,
                    as: 'categoryDetail',
                    required: false,
                    attributes: ['title', 'status']

                }, {
                    model: User,
                    as: 'userDetail',
                    required: false,
                    attributes: ['first_name', 'last_name', 'email', 'status', 'phone', 'profile_pic','username']
                }]
            })
            if (!products) {
                return await Helper.ErrorResponse(res, 'product_fetch_error', 'Products could not be fetched');
            }
            return await Helper.successResponseWithData(res, 'products_fetched_success', 'Proudcts retrieved successfully', products)
        } catch (error) {

        }
    },

    createProduct: async (req, res) => {
        try {
            let data = req.body;
            let user_id = req.AuthUser.id
            let insertObject = {};

            if (!data.category_id) {
                return await Helper.ErrorResponse(res, 'category_id_error', 'Category id is required.')
            }
            if (!data.title) {
                return await Helper.ErrorResponse(res, 'title_error', 'Product title is required.')
            }
            if (!data.size) {
                return await Helper.ErrorResponse(res, 'size_error', 'Product size is required.')
            }

            insertObject = {
                category_id: data.category_id,
                user_id: user_id,
                title: data.title,
                size: data.size,
            }
            data.description ? insertObject.description = data.description : null;
            data.price ? insertObject.price = data.price : null;
            data.sale_price ? insertObject.sale_price = data.sale_price : null;
            data.promote ? insertObject.promote = data.promote : null;
            data.view ? insertObject.view = data.view : null;
            data.order_no ? insertObject.order_no = data.order_no : null;

            let product = await Product.create(insertObject);
            if (!product) {
                return await Helper.ErrorResponse(res, 'product_add_error', 'Product could not be added');
            }

            return await Helper.successResponseWithData(res, 'product_add_success', 'Product added successfully', product);

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message)
        }
    },

    updateProduct: async (req, res) => {
        try {
            let data = req.body;
            let user_id = req.AuthUser.id
            let insertObject = {};

            if (!data.product_id) {
                return await Helper.ErrorResponse(res, 'product_id_error', 'Product id is required.')
            }
            if (!data.category_id) {
                return await Helper.ErrorResponse(res, 'category_id_error', 'Category id is required.')
            }
            if (!data.title) {
                return await Helper.ErrorResponse(res, 'title_error', 'Product title is required.')
            }
            if (!data.size) {
                return await Helper.ErrorResponse(res, 'size_error', 'Product size is required.')
            }
            let products = await Product.findOne({ where: { id: data.product_id } })

            if (!products) {
                return await Helper.ErrorResponse(res, 'product_unavailabe', 'Product not found is required.')
            }

            updateObject = {
                category_id: data.category_id,
                user_id: user_id,
                title: data.title,
                size: data.size,
            }
            data.description ? insertObject.description = data.description : null;
            data.price ? insertObject.price = data.price : null;
            data.sale_price ? insertObject.sale_price = data.sale_price : null;
            data.promote ? insertObject.promote = data.promote : null;
            data.view ? insertObject.view = data.view : null;
            data.order_no ? insertObject.order_no = data.order_no : null;

            products.set(updateObject);

            if (await products.save()) {
                return await Helper.successResponseWithData(res, 'product_update_success', 'Product updated successfully', products);

            } else {
                return await Helper.ErrorResponse(res, 'product_add_error', 'Product is not be updated');
            }
        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message)
        }
    },

    deleteProduct: async (req, res) => {
        try {
            let data = req.body;
            let user_id = req.AuthUser.id

            if (!data.product_id) {
                return await Helper.ErrorResponse(res, 'product_id_error', 'Product id is required.')
            }

            let products = await Product.findOne({ where: { id: data.product_id, user_id: user_id } })
            if (!products) {
                return await Helper.ErrorResponse(res, 'product_unavailabe', 'Product not found is required.')
            }
            let deletedProduct = await Product.destroy({ where: { id: data.product_id, user_id: user_id } });

            if (!deletedProduct) {
                return await Helper.ErrorResponse(res, 'product_delete_error', 'Product could not be deleted');
            }

            return await Helper.successResponseWithData(res, 'product_delete_success', 'Product deleted successfully', deletedProduct);

        } catch (error) {
            return await Helper.ErrorResponse(res, 'internal_server_error', error.message)
        }
    }
}


module.exports = ProductController;