// require("dotenv/config");
require('dotenv').config()
const jsonwebtoken = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { User, Notification } = require("../../models");
const jwt = require("jsonwebtoken");
const nodemailer = require('nodemailer');
const request = require("request");
const { Op } = require("sequelize");
const fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');
const ffprobePath = require('ffprobe-static').path;
ffmpeg.setFfprobePath(ffprobePath)
// ffmpeg.setFfprobePath('../../../../../../Downloads/ffmpeg-2024-03-04-git-e30369bc1c-full_build/ffmpeg-2024-03-04-git-e30369bc1c-full_build/bin');
const awsService = require('../../config/awsSerive')
const path = require('path')
const util = require('util')
const exec = util.promisify(require('child_process').exec);
const db = require('../../models');
const { BlockUser} = db;

var Helper = {
    generateToken: async (data, secret_key, expires) => {
        const token = await jwt.sign(data, secret_key, expires);
        return token;
    },
    passwordHashing: async (pawd, salt) => {
        const password = await bcrypt.hash(pawd, salt);
        return password;
    },
    comparePassword: async (password, hash) => {
        try {
            // Compare password
            return await bcrypt.compare(password, hash)
        } catch (error) {
            console.log(error)
        }
        // Return false if error
        return false
    },
    ErrorResponseWithStatusCode: async (res, key = '', msg, statusCode = '', data = '') => {
        if (statusCode) {
            var data = {
                status: statusCode || true,
                message: msg,
                data: []
            };
            return await res.status(statusCode).json(data);
        }
        var data = {
            status: true,
            code: key,
            message: msg,
            data: []
        };
        return await res.status(200).json(data);
    },
    ErrorResponse: async (res, key = '', msg, data = '') => {
        if (key) {
            var data = {
                status: false,
                code: key,
                message: msg,
                data: []
            };
        }
        var data = {
            status: true,
            code: key,
            message: msg,
            data: []
        };
        return await res.status(200).json(data);
    },
    checkUserExistOrNot: async (userId) => {
        const getUser = await User.findOne({ where: { id: userId } });
        return getUser;

    },
    getDynamicPagination: async (model = '', where = '', attributes = '', order = '', page, pageSize = '') => {
        // if(!model){return await this.res.send("model_must_define","model must be defined")}
        const limit = pageSize; // number of records per page
        const offset = (page - 1) * pageSize;

        let result = await model.findAndCountAll({
            where: where,
            attributes: attributes,
            orderby: order,
            limit: limit,
            offset: offset,
        });
        return result;
    },
    bulkInsert: async (model,payload) => {
        try {
            if(!payload instanceof Array){return await res.send('array pass')}
            let bulkCreate=await model.bulkCreate(payload);
            return bulkCreate;
        } catch (error) {
            console.log("_________________________________________error is here",error);
        }
    },
    checkEntityExistsOrNot: async (model, value) => {
        let result = await model.findOne({ where: value });
        return result;
    },
    createRandom: async (type, len = '') => {
        var result = '';
        var length = len != '' ? len : 4,
            characters = '1234567890';
        if (type == 'letterAndDigit') {
            characters = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        }
        let charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    },
    emailBody: async (email, subject, html) => {
        let emailBody = {
            to: email,
            subject: subject,
            html: html // html body
        }
        return emailBody;
    },
    sendMail: async (emailBody) => {
        try {
            console.log(process.env)
            let transporter = nodemailer.createTransport({
                port: 465,
                host: "smtp.gmail.com",
                auth: {
                  user: "infotakeme19@gmail.com",
                  pass: "gbdechcuuloydkxo", // generated from the App Passwords
                },
                secure: true,

            });

            let mailOptions = {
                from: process.env.MAIL_FROM_ADDRESS, // sender address
                to: emailBody.to, // list of receivers
                subject: emailBody.subject, // Subject line
                html: emailBody.html,// html body
            };

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.log(error)
                }
                console.log(`response is generated ${info}`)
            });
        } catch (error) {
            console.log(error);
        }
    },
    SuccessResponse: (res, key, message) => {
        return res.status(200).json({
            status: true,
            code: key,
            message: message,
        })
    },
    successResponseWithData: async (res, key, message, data) => {
        return await res.status(200).json({
            status: true,
            code: key,
            message: message,
            data: data,
        })
    },
    sendPushNotification: async (registeration_device_token, title, message, payload = '', notification_type = '') => {
        try {
            var options = {
                'method': 'POST',
                'url': process.env.PUSH_URL,
                'headers': {
                    'Authorization': process.env.PUSH_AUTH_TOKEN,
                    'Content-Type': process.env.PUSH_CONTENT_TYPE
                },
                body: JSON.stringify({
                    "to": `${registeration_device_token}`,
                    "notification": {
                        title: title,
                        body: message,
                        sound: 'default',
                        badge: 1
                    },
                    "data": {
                        "payload": payload,
                        "notification_type": notification_type
                    },
                    "notification_type": notification_type,
                    "priority": "high"
                })

            };

            request(options, function (error, response) {
                if (error) {
                    console.log("_____________________________________________", error)
                    throw new Error(error);
                }
                console.log("====>>>>>S>F>SF>", response.body);
            });

        } catch (error) {
            console.log("error is here ===>>>>>", error);
        }
    },

    // This is an independent function that helps and manage sending push notifications to a specific user 
    sendPushNotification2: async (req, user_id, title, message, payload = '', notification_type = '') => {
        try {


            let responseObject = { success: 0, failure: 1, results: null };
            let currentUserId = req.AuthUser.id;

            if (!user_id) {
                console.log("user_id missing")
                return responseObject;
            }
            let userDetails = await User.findOne({
                where: { id: user_id }
            });

            console.log("check detials",userDetails.dataValues.device_token)
            let registeration_device_token

            if (userDetails && Object.keys(userDetails)?.length > 0) {
                // trim device toke for whitespaces
                if(userDetails.dataValues.device_token != null){
                  registeration_device_token = userDetails.dataValues.device_token
                }
                else{
                    // registeration_device_token = 'cXSRNFeb4kM3vr8b4qAMQN:APA91bGUVGCt786nqUwoCiwzRC3b3iWqzQg9Hx4KN-rQvRHU_88M2G-l2yRtubqeqxxqKJiholGlGepXyCZAqntJhdsHRLPB20iAd8Ej-Tzfbf1AwQBYyRtfzyfchJel9JdWI7cwMmND';
                }
                // userDetails.device_token != null ? userDetails.device_token.replaceAll(" ", "") : '';

                if (!userDetails?.is_notification && userDetails.id == currentUserId && userDetails?.is_block) {

                    console.log("user blocked or notification not enabled")
                    return responseObject;
                }
                if (registeration_device_token?.length < 60) {

                    console.log("device token issue")
                    return responseObject
                }

                var options = {
                    'method': 'POST',
                    'url': process.env.PUSH_URL,
                    'headers': {
                        'Authorization': process.env.PUSH_AUTH_TOKEN,
                        'Content-Type': process.env.PUSH_CONTENT_TYPE
                    },
                    body: JSON.stringify({
                        "to": `${registeration_device_token}`,
                        "notification": {
                            title: title,
                            body: message,
                            sound: 'default',
                            badge: 1
                        },
                        data: {
                            title: title,
                            body: message,
                            payload: payload,
                            "notification_type": notification_type
                        },
                        "notification_type": notification_type,
                        "priority": "high"
                    })

                };

                request(options, async function (error, response) {
                
                    if (error) {
                        console.log("_____________________________________________", error)
                        throw new Error(error);
                    }
                    console.log("notification reponse===========================================================++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", response.body);
                    console.log("check options===============================================++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++",options.body)

                    if (response.body.success == "1") {
                        console.log("hii")

                        let insertObject = {
                            sender_id: currentUserId,
                            receiver_id: user_id,
                            title: title,
                            type: notification_type,
                        }

                        await Notification.create(insertObject);
                        return response.body
                    } else {
                        console.log("bie notificati===============================================++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++on")
                        return responseObject;
                    }

                });
                // try {
                //     const response = await new Promise((resolve, reject) => {
                //         request(options, (error, response) => {
                //             if (error) {
                //                 console.log("Error occurred:", error);
                //                 reject(error); // Reject the promise with the error
                //             } else {
                //                 resolve(response); // Resolve the promise with the response
                //             }
                //         });
                //     });
                
                //     console.log("Notification response", response.body);
                
                //     if (response.body.success === 1) {
                //         console.log("Notification sent successfully");
                
                //         let insertObject = {
                //             sender_id: currentUserId,
                //             receiver_id: user_id,
                //             title: title,
                //             type: notification_type,
                //         };
                
                //         await Notification.create(insertObject);
                //         return response.body;
                //     } else {
                //         console.log("Failed to send notification",responseObject);
                //         return responseObject;
                //     }
                // } catch (error) {
                //     console.log("Error:", error);
                //     return responseObject;
                // }
                
                

            } else {

                console.log("user missing")
                return responseObject;
            }


        } catch (error) {
            console.log("error is here ===>>>>>", error);
        }
    },
    //clear string is here
    cleanString: async (string) => {
        return string?.replace(['<', '>', '{', '}', '[', ']', '`'], '');
    },
    getPagination: async (res, array, limit = '', offset = '', orderby = '', skip = '') => {

        console.log("array", array)
        limit == '' ? limit = 10 : limit = limit
        offset = '' ? offset = 0 : offset = offset

        let startingPos = offset != 0 ? offset * limit : 0;
        let lastPos = startingPos + limit;
        let finalArray = [...array[parseInt(startingPos)], ...array[parseInt(lastPos)]];



    },

    // async convertVideoToAudio(originalVideoFilePath, userId) {
    //     const fileName = `${Date.now()}${userId}`;
    //     const folder = 'Audio/';
    //     const mp3FilePath = `${folder}${fileName}.mp3`;

    //     // Ensure the folder exists
    //     if (!fs.existsSync(folder)) {
    //         fs.mkdirSync(folder, { recursive: true });
    //     }

    //     const { name, ext } = path.parse(mp3FilePath);
    //     let keyPrefix = 'Audio/'; // Adjust keyPrefix to be relative to the folder
    //     let extension = ext

    //     ffmpeg()

    //         // Input file
    //         .input(originalVideoFilePath)

    //         // Audio bit rate
    //         .outputOptions('-ab', '192k')

    //         // Output file
    //         .saveToFile(mp3FilePath)

    //         // Log the percentage of work completed
    //         .on('progress', (progress) => {
    //             if (progress.percent) {
    //                 console.log(`Processing: ${Math.floor(progress.percent)}% done`);
    //             }
    //         })

    //         // The callback that is run when FFmpeg is finished
    //         .on('end', async() => {
    //             console.log('FFmpeg has finished.');
    //             try {
    //                 const uploadVideoAws = await awsService.uploadToS3(process.env.AWS_BUCKET, `${keyPrefix}${fileName}`, mp3FilePath, extension);
        
    //                 // Log success message if upload is successful
    //                 console.log('Video successfully uploaded to AWS S3:', uploadVideoAws);
                    
    //                 // Delete the local file after upload
    //                 fs.unlinkSync(mp3FilePath);
    //             } catch (error) {
    //                 console.error('Error uploading video to AWS S3:', error);
    //             }
        
    //             // Delete the local file after upload
    //             // fs.unlinkSync(mp3FilePath);
    //         })
            

    //         // The callback that is run when FFmpeg encountered an error
    //         .on('error', (error) => {
    //             console.error(error);
    //         });
     
    // }

    // async  getAudioDuration(audioFilePath) {
    //     try {
    //         const { stdout, stderr } = await exec(`ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 ${audioFilePath}`);
    //         if (stderr) {
    //             throw new Error(stderr);
    //         }
    //         const durationInSeconds = parseFloat(stdout);
    //         return durationInSeconds;
    //     } catch (error) {
    //         console.error('Error getting audio duration:', error);
    //         throw error;
    //     }
    // },

    async  getAudioDuration(mp3FilePath) {
        return new Promise((resolve, reject) => {
            ffmpeg(mp3FilePath)
                .setFfprobePath(ffprobePath)
                .ffprobe((err, metadata) => {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(metadata.format.duration);
                    }
                });
        });
    },
    async convertVideoToAudio(originalVideoFilePath, userId)  {
        return new Promise((resolve, reject) => {
            const fileName = `${Date.now()}${userId}`;
            const folder = 'Audio/';
            const mp3FilePath = `${folder}${fileName}.mp3`;
    
            // Ensure the folder exists
            if (!fs.existsSync(folder)) {
                fs.mkdirSync(folder, { recursive: true });
            }
    
            const { name, ext } = path.parse(mp3FilePath);
            let keyPrefix = 'Audio/'; // Adjust keyPrefix to be relative to the folder
            let extension = ext;
    
            ffmpeg()
                // Input file
                .input(originalVideoFilePath)
                // Audio bit rate
                .outputOptions('-ab', '192k')
                // Output file
                .saveToFile(mp3FilePath)
                // Log the percentage of work completed
                .on('progress', (progress) => {
                    if (progress.percent) {
                        console.log(`Processing: ${Math.floor(progress.percent)}% done`);
                    }
                })
                // The callback that is run when FFmpeg is finished
                .on('end', async () => {
                    console.log('FFmpeg has finished.');
                    // Get audio duration
                    
                    const duration = await this.getAudioDuration(mp3FilePath);
                    console.log('Audio duration:', duration);
                    try {
                        const uploadVideoAws = await awsService.uploadToS3(process.env.AWS_BUCKET, `${keyPrefix}${fileName}`, mp3FilePath, extension);
                        // Log success message if upload is successful
                        console.log('Video successfully uploaded to AWS S3:', uploadVideoAws);
                        // Delete the local file after upload
                        fs.unlinkSync(mp3FilePath);
                        // resolve(mp3FilePath); // Resolve the promise with the path to the uploaded audio file
                        resolve({ path: mp3FilePath, duration: duration }); 
                    } catch (error) {
                        console.error('Error uploading video to AWS S3:', error);
                        reject(error); // Reject the promise if there's an error
                    }
                })
                // The callback that is run when FFmpeg encountered an error
                .on('error', (error) => {
                    console.error(error);
                    reject(error); // Reject the promise if FFmpeg encounters an error
                });
        });
    },

    /** 
     * This function is used to check user's blocked 
     * @developer   : Deepmala
     */
    isUserReportedOrBlocked: async  (currentUser, other_user_id) => {
        let isBlocked  = [];
        let blockedUsers = await BlockUser.findOne({where: {user_id: currentUser, block_user_id: other_user_id}});
        console.log('blockedd=================',blockedUsers)
        if(blockedUsers != null){
            return 'YOU_BLOCKED_USER';
        } else {
            return true;
        }
    },

    /**
     * This function is used to check user's blocked by
     * @developer   : Deepmala
     */
    isUserReportedOrBlockedBy: async (currentUser, other_user_id) => {
        let isblockedby = await BlockUser.findOne({where: {user_id: other_user_id, block_user_id: currentUser }});
        console.log('blockedd==byyyyyyy===============',isblockedby)
        if( isblockedby != null)
        {
            return 'BLOCKED_USER_BY';
        } else {
            return true;
        }
    },
    /**
     * This function is used to get blocked users
     * @developer   : Deepmala
     */
    getAllBlockedUser: async (user_id) => {
        if (!user_id) { return ({ message: "user_id must be defined" }) }
        let exeCommand = await BlockUser.findAll({where: {user_id: user_id}});
        let unblockUsers = [];
       console.log('=++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++Exe======================================================',exeCommand.length);
        for (var i = 0; i < exeCommand.length; i++) {
            let unBlockUsers = await User.findOne({where: {id :exeCommand[i].block_user_id }});
            unblockUsers.push(unBlockUsers)
        }
        console.log("unb=============+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++==lockUsers",unblockUsers.length);
        return unblockUsers;//.flat();
    },
}

/**
 * This function is using to remove Duplicates 
 * @developer   : Deepmala
 * @modified    :
 */
Helper.removeDuplicatesItem = async(arr)=> {
    let unique = [];
    let data = [];
    arr.forEach(element => {
        if (!unique.includes(element.toString())) {
            unique.push(element.toString());
            data.push(element)
        }
    });
    return data;
}

/**
     * This function is used to remove blocked users
     * @developer   : Deepmala
     */
Helper.removeBlockUsers = async (users, currentUser, type = '', uid = '', userId) => {
console.log('userslslsllsl lenghy=================',users.length)
    console.log('all users===',users[0].user_id)
    console.log('resjsjjsjs=========currentUser=====',currentUser)
    var u_uuid = currentUser;
    if (users) {
        for (var i = 0; i < users.length; i++) {
            let blocked_users;
            if (type == 'raw') {
                blocked_users = await Helper.getAllBlockedUser(users[i]);
            } else {
                blocked_users = await Helper.getAllBlockedUser(users[i].user_id);
            }
            let check_users = blocked_users.some(function (block) {
                // return u_uuid.toString() === block.user_id.toString()
                return u_uuid === block.id

            });
            //console.log(check_users);
            console.log('userslslsllsl lenghy========check_users====0000000000000000000000000000000000000000000000000=====',check_users.length)

            if (check_users) {
                delete users[i];
            }
        }
    }

    users = users.filter(element => {
        return element !== null;
    });
    console.log('userslslsllsl lenghy============0000000000000000000000000000000000011111111111111111111111111111111111100000000000000=====',users.length)

    // users= await Helper.removeDuplicatesItem(users);

    return users;
}

module.exports = Helper;