module.exports = Object.freeze({
  "type": "service_account",
  "project_id": "laravelfirebase-62f7c",
  "private_key_id": "3b3ca9aeb50ea0139970e177130303609a536047",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCU3EES/kdwtCfi\n5QeqNZl8qc/2WZiFKvC2apcu5zH8sOfi57Jcc+jUo/1sOZcwzzCsTt36bQZ3dT5D\nKV3CAHxxJg2VH7kiqe4orDQdSflLVaGEwlc6oXV+q+4laVJ1R4WwLGNlS33EYXJr\nUstALp3RFd9f6GyhDaS7mo5XMQtGZFcX13nsToXxjW0EMhiJNNwFg+8tSrizLNes\nXn3DYc7xC52dc6h3iQTC/fG3RSaYQzVTUSSzFsBb+L4nrTccbUGszTyFcze/3p0d\ndr5HZyn+pNZ81pTKsFp0UIgqVUZONVncyKVOj03S1MLwHecZR1U+Eebr/fWEfvJi\nYydS7sJfAgMBAAECggEAQHvW7qja/p30B0xKUTfNyNxwu1kdglZTFto+qnE5TKq/\nkKHouDb3vaFaRtb9wQWHoqS5cOFoozfVJFfXhxIZ1hPzX01yL+tnwROzsZpZVQJ/\nqNhc3AeUM667x1YEA8zbQzE/T2Jv1TGXVJl1dVScRbYRYOT4pZ2Y5jGyBmA276Mf\nm7W9qTVcixKDAD4FZS2Bn+UaE7Ku/McmJGKVizcMYLpTsYag0lUMD/QR0EQdrli7\ndG0f1GoyEiHc+5AMSJ6Tk9vv5WurmK56ujKY2sHvcoedgHV8YKXO31KfFi3SyoG2\n7ty30et70OrTC/mttzD11Zx6T37E1iJrspOnUM1+uQKBgQDEMJ1Rok51Rwkkf9HZ\n5A8EcE62LrMVIjdaTqXRhRt2yLHG2Ss8XVNBRjuRtQNCOYmQ82nYvhZ/fyXMq47t\naJoLzf9D3QY/F6VtR8Ke4aQJDQFgXbxxQWFQbFADmzWWKxWgnrRXUMeH+uwtuFrG\n5aVxAr+bT5+xf3fTS+Ze3FSCeQKBgQDCPd4uTdwIovyXzzmPCcGMM98xNIuz5INb\nYjbq1cDIM3jZvUKLVs3B9qDlPPdHJaw4sRK1cUPqay2V2bpUybBkdHP4fgw22gID\nvO4JWxHIAWMKarH65xVuZNmU14HlonMnPst6dHlRtFaKprXi8Wp4Yfw/UgA4VXzo\nkYyrD/j1lwKBgQCgKxBElT14gYX1RmUMfiPEe+vG0Flj54tJLuwxIXpKf46jyKiD\nn61YnP4E9sKyTkcBD7haOtYjQKqbbXRCXiNlf8fmn4t59tQXY36AN7azrOpywhQW\nYkoQXlz0lMIq1wHRH8AbiNddLH2k1d1GhDWNDbFgGqFFR8uLtWteBoL4AQKBgF3F\nLDtCTxTEShina2wIE62xZPAGI+MmT9uP4F8h7b04TAEhgrxtnUsj2qyP7/gi0a9U\nnGmHUngaYZlT0MYZz9PO/CVcBF1+hTZ0wJ03n6/kK4Hd3Cn54Li4aumV2BmZgOnT\nQLvO+rpcyuKIdIoobXPMKdAPsBeB/Zjwmu4B+fflAoGANChlCiEDngBOxNqHU1L/\nZy6mFXxbb0izTSNn5pYDlBwUosy91pvq2sOAxVos4MGd7rMmvZD+gBOpEvuczWRw\n+MyLTB+48hV0cZCDmqqH1J+5NsMldHN1Zqtv+sjuZDwC1lK6pvzGKITntLZwswwO\nqAD1a3OBGIxxcLwHGLjX8Xk=\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-5ekys@laravelfirebase-62f7c.iam.gserviceaccount.com",
  "client_id": "110800496069254348431",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-5ekys%40laravelfirebase-62f7c.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
});
