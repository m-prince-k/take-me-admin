require("dotenv").config();
var admin = require("firebase-admin");
var serviceAccount=require('../firebase-admin-service-provider.json');

admin.initializeApp({
    credential:admin.credential.cert(serviceAccount),
    databaseURL:process.env.APP_URL
});
module.exports= admin;