'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('coin_plans', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      user_id: {
        type: Sequelize.UUID,
        allowNull:false,   
      },
      appstore_product_id: {
        type: Sequelize.STRING,
        allowNull:true
      },
      coin_amount: {
        type: Sequelize.FLOAT,
        allowNull:true
      },
      playstore_product_id: {
        type: Sequelize.STRING,
        allowNull:true
      },
      price: {
        type: Sequelize.FLOAT,
        allowNull:true
      },
      status: {
        type: Sequelize.BOOLEAN,
        defaultValue:false
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('coin_plans');
  }
};