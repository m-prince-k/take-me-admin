'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('posts', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      user_id: {
        allowNull: false,
        type: Sequelize.UUID
      },
      description: {
        type:Sequelize.STRING
      },
      video: {
        type:Sequelize.STRING,
        allowNull:true
      },
      thumbnail: {
        type:Sequelize.STRING,
        allowNull:true
      },
      gif: {
        type:Sequelize.STRING,
        allowNull:true
      },
      view: {
        type:Sequelize.INTEGER,
        defaultValue:0,
        allowNull:true
      },
      section: {
        type:Sequelize.STRING,
        allowNull:true
      },
      sound_id: {
        type:Sequelize.UUID,
        allowNull:true,
      },
      privacy_type: {
        type:Sequelize.STRING,
        allowNull:true,
        comment:['public and private']
      },
      allow_comments: {
        type:Sequelize.STRING,
        allowNull:true,
        defaultValue:true,
        comment:['true=allow and false=not allowed']
      },
      allow_duet: {
        type:Sequelize.INTEGER,
        defaultValue:0,
        allowNull:true
      },
      block: {
        type:Sequelize.INTEGER,
        defaultValue:0,
        allowNull:true
      },
      duet_video_id: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      old_video_id: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      duration: {
        type:Sequelize.FLOAT,
        allowNull:true
      },
      promote: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      pin_comment_id: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      pin: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      repost_user_id: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      repost_video_id: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      quality_check: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      viral: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      story: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      country_id: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      city: {
        type:Sequelize.STRING,
        allowNull:true
      },
      state: {
        type:Sequelize.STRING,
        allowNull:true
      },
      country:{
        type:Sequelize.STRING,
        allowNull:true
      },
      region:{
        type:Sequelize.STRING,
        allowNull:true
      },
      location_string:{
        type:Sequelize.STRING,
        allowNull:true
      },
      share:{
        type:Sequelize.INTEGER,
        allowNull:true
      },
      video_with_watermark:{
        type:Sequelize.STRING,
        allowNull:true
      },
      lat:{
        type:Sequelize.STRING,
        allowNull:true
      },
      long:{
        type:Sequelize.STRING,
        allowNull:true
      },
      product:{
        type:Sequelize.INTEGER,
        allowNull:true
      },
      height:{
        type:Sequelize.STRING,
        allowNull:true
      },
      width:{
        type:Sequelize.STRING,
        allowNull:true
      },
      video_language:{
        type:Sequelize.STRING,
        allowNull:true
      },
      repost:{
        type:Sequelize.BOOLEAN,
        allowNull:true,
        defaultValue:false
      },
      status:{
        type:Sequelize.BOOLEAN,
        defaultValue:false
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('posts');
  }
};