'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('sounds', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      audio: {
        type:Sequelize.STRING,
        allowNull:true
      },
      duration: {
        type:Sequelize.STRING,
        allowNull:true
      },
      name: {
        type:Sequelize.STRING,
        allowNull:true
      },
      description: {
        type:Sequelize.TEXT,
        allowNull:true
      },
      thumbnail: {
        type:Sequelize.STRING,
        allowNull:true
      },
      sound_section_id: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      uploaded_by: {
        type:Sequelize.STRING,
        allowNull:true
      },
      publish: {
        type:Sequelize.INTEGER,
        allowNull:true
      },
      status:{
        type:Sequelize.BOOLEAN,
        defaultValue:false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('sounds');
  }
};