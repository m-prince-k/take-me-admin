'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('users', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      first_name: {
        type: Sequelize.STRING,
        allowNull: true
      },
      last_name: {
        type: Sequelize.STRING,
        allowNull: true
      },
      email: {
        type: Sequelize.STRING,
        allowNull: false
      },
      gender: {
        type: Sequelize.STRING,
        allowNull: true
      },
      bio: {
        type: Sequelize.STRING,
        allowNull: true
      },
      dob: {
        type: Sequelize.STRING,
        allowNull: true
      },
      website: {
        type: Sequelize.STRING,
        allowNull: true
      },
      social_id: {
        type: Sequelize.STRING,
        allowNull: true
      },
      email: {
        type: Sequelize.STRING,
        allowNull: true
      },
      phone: {
        type: Sequelize.STRING,
        allowNull: true
      },
      phone_code: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      profile_pic: {
        type: Sequelize.STRING,
        allowNull: true
      },
      fb_url: {
        type: Sequelize.STRING,
        allowNull: true
      },
      insta_url: {
        type: Sequelize.STRING,
        allowNull: true
      },
      twitter_url: {
        type: Sequelize.STRING,
        allowNull: true
      },
      youtube_url: {
        type: Sequelize.STRING,
        allowNull: true
      },
      role: {
        type: Sequelize.INTEGER,
        allowNull: true,
        comment: ['0 => for user, 1 => admin']
      },
      refferer_id: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      username: {
        type: Sequelize.STRING,
        allowNull: true
      },
      social: {
        type: Sequelize.STRING,
        allowNull: true
      },
      device: {
        type: Sequelize.STRING,
        allowNull: true
      },
      device_token: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      is_block: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        comment: ['0-unblock,1 => unblock']
      },
      room_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      is_premium_user: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        comment: ['0-premium user,1 => un premium user']
      },
      show_following_list: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        comment: ['0-enabled,1 => disabled']
      },
      show_liked_videos: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        comment: ['0-enabled,1 => disabled']
      },
      tencent_password: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      is_show_dob: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        comment: ['0-enabled dob,1 => disabled user']
      },
      is_deleted: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        comment: ['0 => undeleted,1 => deleted']
      },
      is_sponsored: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        comment: ['0 => undeleted,1 => deleted']
      },
      verified: {
        type: Sequelize.INTEGER,
        allowNull: true,
        comment: ['0 => unverified,1 => verified']
      },
      is_notification: {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
        comment: ['0 => enabled,1 => disabled']
      },
      call_status: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        comment: ['0 => enabled,1 => disabled']
      },
      livestream_eligible: {
        type: Sequelize.BOOLEAN,
        allowNull: true,
        comment: ['0 => unlivestream,1 => enabled live stream']
      },
      max_upload_daily: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      version: {
        type: Sequelize.STRING,
        allowNull: true
      },
      status: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      ip: {
        type: Sequelize.STRING,
        allowNull: true
      },
      videos_download: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      video_comment: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      liked_videos: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      duet: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      direct_message: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      video_updates: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      new_followers: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      mentions: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      likes: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      direct_messages: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      comments: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      wallet: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      online: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      long: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      lat: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      country: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      city: {
        type: Sequelize.STRING,
        defaultValue: false
      },
      active: {
        type: Sequelize.STRING,
        defaultValue: false
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('users');
  }
};