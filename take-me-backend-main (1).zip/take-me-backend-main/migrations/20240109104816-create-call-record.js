'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('call_records', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      action: {
        type: Sequelize.STRING,
        allowNull:true
      },
      duration: {
        type: Sequelize.STRING,
        allowNull:true
      },
      from_user_id: {
        type: Sequelize.UUID,
        allowNull:false
      },
      to_user_id: {
        type: Sequelize.UUID,
        allowNull:false
      },
      type: {
        type: Sequelize.STRING,
        allowNull:true
      },
      status: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('call_records');
  }
};