'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('push_notifications', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        allowNull: false,
        primaryKey: true
      },
      likes: {
        type: Sequelize.INTEGER,
        defaultValue:1
      },
      comments: {
        type: Sequelize.INTEGER,
        defaultValue:1
      },
      new_followers: {
        type: Sequelize.INTEGER,
        defaultValue:1
      },
      mentions: {
        type: Sequelize.INTEGER,
        defaultValue:1
      },
      direct_messages: {
        type: Sequelize.INTEGER,
        defaultValue:1
      },
      video_updated: {
        type: Sequelize.INTEGER,
        defaultValue:1
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('push_notifications');
  }
};