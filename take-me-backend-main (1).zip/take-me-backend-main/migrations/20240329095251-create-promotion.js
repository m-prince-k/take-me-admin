'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('promotions', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true,
      },
      user_id: {
        type: Sequelize.UUID,
        allowNull: false,
      },
      post_id: {
        type: Sequelize.UUID,
        allowNull: false,
      },
      website_url: {
        type: Sequelize.STRING,
        defaultValue:false
      },
      start_datetime: {
        type: Sequelize.DATE,
        defaultValue: null
      },
      end_datetime: {
        type: Sequelize.DATE,
        defaultValue:null
      },
      coin: {
        type: Sequelize.INTEGER,
        defaultValue:0
      },
      active: {
        type: Sequelize.INTEGER,
        defaultValue:0
      },
      destination: {
        type: Sequelize.STRING,
        defaultValue:false
      },
      action_button: {
        type: Sequelize.STRING,
        defaultValue:false
      },
      destination_tap: {
        type: Sequelize.INTEGER,
        defaultValue:0
      },
      followers: {
        type: Sequelize.INTEGER,
        defaultValue:0
      },
      reach: {
        type: Sequelize.INTEGER,
        defaultValue:0
      },
      total_reach: {
        type: Sequelize.INTEGER,
        defaultValue:0
      },
      clicks: {
        type: Sequelize.INTEGER,
        defaultValue:0
      },
      audience_id: {
        type: Sequelize.UUID,
        allowNull: false,
      },
      payment_card_id: {
        type: Sequelize.INTEGER,
        defaultValue:0
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('promotions');
  }
};
