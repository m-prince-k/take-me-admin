require("dotenv").config();
var AWS = require('aws-sdk');
var fs = require('fs');
var path = require('path');


var s3 = new AWS.S3({
    accessKeyId: process.env.AWS_CLIENT_ACCESS_KEY,
    secretAccessKey:process.env.AWS_cLIENT_ACCESS_SECRET 
});


function uploadToS3(bucketName, keyPrefix, filePath, extension) {
    const fileName = path.basename(filePath);
    const fileStream = fs.createReadStream(filePath);
    const keyName = path.join(keyPrefix, fileName);

    return new Promise((resolve, reject) => {
        fileStream.once('error', reject);

        s3.upload({
            Body: fileStream,
            ContentType: `audio/${extension}`,
            Bucket: bucketName,
            Key: filePath
        }).promise()
        .then(data => {
            console.log("Upload successful:", data.Location);
            resolve(data.Location); // Return the URL of the uploaded file
        })
        .catch(error => {
            console.error("Upload failed:", error);
            reject(error);
        });
    });
}


module.exports={
    uploadToS3
};
