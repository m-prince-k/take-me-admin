'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class gifts extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  gifts.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    title: {
      type:DataTypes.STRING
    },
    image: {
      type:DataTypes.STRING
    },
    coin: {
      type:DataTypes.STRING
    },
    type: {
      type:DataTypes.STRING
    },
    time: {
      type:DataTypes.STRING
    },
    sound: {
      type:DataTypes.STRING
    },
    icon: {
      type:DataTypes.STRING
    },
    position: {
      type:DataTypes.STRING
    },
    featured : {
      type:DataTypes.STRING
    },
  }, {
    sequelize,
    modelName: 'gift',
    timestamps:true
  });
  return gifts;
};