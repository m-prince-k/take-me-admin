'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class PrivacySetting extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      PrivacySetting.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
    }
  }
  PrivacySetting.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    videos_download:{
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue:0
    },
    direct_message: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue:0
    },
    duet:{
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue:0
    },
    liked_videos: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue:0
    },
    direct_messages: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue:0
    },
    video_comment: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue:0
    },
  }, {
    sequelize,
    modelName: 'PrivacySetting',
    // tableName: 'PrivacySettings',
    // timestamps: true
  });
  return PrivacySetting;
};
