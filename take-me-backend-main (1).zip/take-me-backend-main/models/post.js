'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Post extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Post.hasMany(models.HashTagPost,{foreignKey:'post_id',as:'hashTags',onDelete:'CASCADE'});
      
      Post.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
      Post.hasMany(models.PostLike,{foreignKey:'post_id',as:'likePost',onDelete:'CASCADE'});
      Post.hasMany(models.PostComment,{foreignKey:'post_id',as:'comment',onDelete:'CASCADE'});
      //Post.hasMany(models.Repost,{foreignKey:'post_id',as:'repost_posts',onDelete:'CASCADE'});
      Post.belongsTo(models.Sound, { foreignKey: 'sound_id', as: 'sound' });
      Post.hasMany(models.TransactionHistory, { foreignKey: 'post_id', as: 'transaction_history' });
      // Post.belongsTo(models.NotificationMessages, { foreignKey: 'user_id', as: 'post' });
    }
  }
  Post.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    description: {
      type:DataTypes.STRING
    },
    video: {
      type:DataTypes.STRING,
      allowNull:true
    },
    thumbnail: {
      type:DataTypes.STRING,
      allowNull:true
    },
    gif: {
      type:DataTypes.STRING,
      allowNull:true
    },
    view: {
      type:DataTypes.INTEGER,
      defaultValue:0,
      allowNull:true
    },
    section: {
      type:DataTypes.STRING,
      allowNull:true
    },
    sound_id: {
      type:DataTypes.UUID,
      allowNull:true,
      references:{
        model:'sounds',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    privacy_type: {
      type:DataTypes.STRING,
      allowNull:true,
      comment:['public and private']
    },
    allow_comments: {
      type:DataTypes.STRING,
      allowNull:true,
      defaultValue:true,
      comment:['true=allow and false=not allowed']
    },
    allow_duet: {
      type:DataTypes.INTEGER,
      defaultValue:0,
      allowNull:true
    },
    block: {
      type:DataTypes.INTEGER,
      defaultValue:0,
      allowNull:true
    },
    duet_video_id: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    old_video_id: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    video_hls:{
      type:DataTypes.VIRTUAL,
      get() {
        const rawValue = this.getDataValue("old_video_id")
        return rawValue ? "https://vod.api.video/vod/"+rawValue+"/hls/manifest.m3u8" : ''
      }
    },
    duration: {
      type:DataTypes.FLOAT,
      allowNull:true
    },
    promote: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    pin_comment_id: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    pin: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    repost_user_id: {
      type:DataTypes.UUID,
      allowNull:true,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    repost_video_id: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    quality_check: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    viral: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    story: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    country_id: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    city: {
      type:DataTypes.STRING,
      allowNull:true
    },
    state: {
      type:DataTypes.STRING,
      allowNull:true
    },
    country:{
      type:DataTypes.STRING,
      allowNull:true
    },
    region:{
      type:DataTypes.STRING,
      allowNull:true
    },
    location_string:{
      type:DataTypes.STRING,
      allowNull:true
    },
    share:{
      type:DataTypes.INTEGER,
      allowNull:true
    },
    video_with_watermark:{
      type:DataTypes.STRING,
      allowNull:true
    },
    lat:{
      type:DataTypes.STRING,
      allowNull:true
    },
    long:{
      type:DataTypes.STRING,
      allowNull:true
    },
    product:{
      type:DataTypes.INTEGER,
      allowNull:true
    },
    height:{
      type:DataTypes.STRING,
      allowNull:true
    },
    width:{
      type:DataTypes.STRING,
      allowNull:true
    },
    video_language:{
      type:DataTypes.STRING,
      allowNull:true
    },
    repost:{
      type:DataTypes.BOOLEAN,
      defaultValue:false,
      allowNull:true
    },
    likes:{
      type:DataTypes.INTEGER,
      allowNull:true
    },
    comments:{
      type:DataTypes.INTEGER,
      allowNull:true
    },
    
    status:{
      type:DataTypes.BOOLEAN,
      defaultValue:true
    }
  }, {
    sequelize,
    modelName: 'Post',
    tableName:'posts',
    timestamps:true
  });
  return Post;
};