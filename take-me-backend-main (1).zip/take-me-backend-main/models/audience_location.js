'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class audience_location extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  audience_location.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    audience_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'audience',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    name: {
      type:DataTypes.STRING,
      defaultValue:false
    },
    city_id: {
      type:DataTypes.INTEGER,
      defaultValue:0
    },
    state_id: {
      type:DataTypes.INTEGER,
      defaultValue:0
    },
    country_id: {
      type:DataTypes.INTEGER,
      defaultValue:0
    }
  }, {
    sequelize,
    modelName: 'audience_location',
    timestamps:true
  });
  return audience_location;
};