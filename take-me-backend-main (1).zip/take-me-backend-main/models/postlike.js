'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class PostLike extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      PostLike.belongsTo(models.Post,{foreignKey:'post_id',as:'post'});
      PostLike.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
      
      PostLike.hasMany(models.HashTagPost,{foreignKey:'post_id',as:'hashTags',onDelete:'CASCADE'});
      PostLike.hasMany(models.PostLike,{foreignKey:'post_id',as:'likePost',onDelete:'CASCADE'});
      PostLike.hasMany(models.PostComment,{foreignKey:'post_id',as:'comment',onDelete:'CASCADE'});
    }
  }
  PostLike.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    post_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'posts',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'PostLike',
    tableName:'post_likes',
    timestamps:true
  });
  return PostLike;
};