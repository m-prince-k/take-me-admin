'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Follower extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Follower.belongsTo(models.User, { as: 'senderDetail', foreignKey: 'sender_id' });
      Follower.belongsTo(models.User, { as: 'receiverDetail', foreignKey: 'receiver_id' });
      //ReportUser.belongsTo(models.ReportReason,{as:'reportReason',foreignKey:'report_reason_id'})
    }
  }
  Follower.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    sender_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    receiver_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    notification: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
      comment: ['0 => disabled and 1 => enabled']
    },
    promotion_id: {
      type: DataTypes.UUID,
      allowNull: true
    },
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    }

  }, {
    sequelize,
    modelName: 'Follower',
    tableName: 'followers',
    timestamps: true
  });
  return Follower;
};