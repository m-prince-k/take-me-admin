'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class audience extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  audience.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    name: {
      type:DataTypes.STRING,
      defaultValue:true
    },
    country: {
      type:DataTypes.STRING,
      defaultValue:true
    },
    min_age: {
      type:DataTypes.INTEGER,
      defaultValue:true
    },
    max_age: {
      type:DataTypes.INTEGER,
      defaultValue:true
    },
    gender: {
      type:DataTypes.STRING,
      defaultValue:true
    }
  }, {
    sequelize,
    modelName: 'audience',
    timestamps:true
  });
  return audience;
};
