'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class PostCommentLike extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      PostCommentLike.belongsTo(models.User,{foreignKey:'user_id',as:'user'})
      PostCommentLike.belongsTo(models.PostComment,{foreignKey:'comment_id',as:'comment'})
    }
  }
  PostCommentLike.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    comment_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'postcomments',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'PostCommentLike',
    tableName:'post_comment_likes',
    timestamps:true
  });
  return PostCommentLike;
};