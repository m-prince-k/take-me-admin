'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class send_gift extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  send_gift.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    gift_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    receiver_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    sender_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    image: {
      type:DataTypes.STRING
    },
    coin: {
      type:DataTypes.STRING
    },
    gift: {
      type:DataTypes.STRING
    },
    title: {
      type:DataTypes.STRING
    },
  }, {
    sequelize,
    modelName: 'send_gift',
    timestamps:true
  });
  return send_gift;
};