'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class TransactionHistory extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here 
      TransactionHistory.belongsTo(models.Post,{foreignKey:'post_id',as:'post'});
      TransactionHistory.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
      // TransactionHistory.belongsToMany(models.User,{through:models.TransactionHistory,foreignKey:'user_id',otherKey:'user_id'})
    }
  }
  TransactionHistory.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    post_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'posts',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    type: {
      type:DataTypes.STRING
    },
    Remarks: {
      type:DataTypes.STRING
    },
    points: {
      type:DataTypes.INTEGER
    },
  }, {
    sequelize,
    modelName: 'TransactionHistory',
    tableName:'TransactionHistories',
    timestamps:true
  });
  return TransactionHistory;
};