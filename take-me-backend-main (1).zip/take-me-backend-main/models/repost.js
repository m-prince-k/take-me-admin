'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Repost extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Repost.belongsTo(models.User,{foreignKey:'user_id',as:'user',onDelete:'CASCADE'});
      Repost.belongsTo(models.Post,{foreignKey:'id',as:'post',onDelete:'CASCADE'});
    }
  }
  Repost.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    post_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'posts',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    count: {
      type:DataTypes.INTEGER,
      defaultValue:0
    },
    status:{
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'Repost',
    tableName:'re_posts',
    timestamps:true
  });
  return Repost;
};