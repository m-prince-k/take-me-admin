'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class HashTagFavourite extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      HashTagFavourite.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
      HashTagFavourite.belongsTo(models.HashTag,{foreignKey:'hashtag_id',as:'hashtags'});
    }
  }
  HashTagFavourite.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    hashtag_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'hashtags',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'HashTagFavourite',
    tableName:'hash_tag_favourites',
    timestamps:true
  });
  return HashTagFavourite;
};