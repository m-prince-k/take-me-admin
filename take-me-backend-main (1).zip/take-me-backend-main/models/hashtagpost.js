'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class HashTagPost extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      HashTagPost.belongsTo(models.HashTag,{foreignKey:'hashtag_id',as:'hashtag'});
      HashTagPost.belongsTo(models.Post,{foreignKey:'post_id',as:'posts'});
    }
  }
 //5df73ca6-779a-4ff7-b178-4f3e855ea4a6
 //ea3e3a50-ec82-4cb7-99d4-74bf3510d4af
  HashTagPost.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    hashtag_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'hashtags',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    post_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'posts',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'HashTagPost',
    tableName:'hashtags_posts',
    timestamps:true
  });
  return HashTagPost;
};