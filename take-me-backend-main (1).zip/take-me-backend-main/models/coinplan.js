'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class CoinPlan extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      CoinPlan.belongsTo(models.User, { as: 'userCoins', foreignKey: 'user_id' });
    }
  }
  CoinPlan.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull:false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    appstore_product_id: {
      type: DataTypes.STRING,
      allowNull:true
    },
    coin_amount: {
      type: DataTypes.FLOAT,
      allowNull:true
    },
    playstore_product_id: {
      type: DataTypes.STRING,
      allowNull:true
    },
    price: {
      type: DataTypes.FLOAT,
      allowNull:true
    },
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue:false
    },
  }, {
    sequelize,
    modelName: 'CoinPlan',
    tableName: 'coin_plans',
    timestamps: true
  });
  return CoinPlan;
};