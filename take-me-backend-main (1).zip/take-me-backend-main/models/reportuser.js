'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ReportUser extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      ReportUser.belongsTo(models.User,{as:'user',foreignKey:'user_id'});
      ReportUser.belongsTo(models.User,{as:'toReportUser',foreignKey:'report_user_id'});
      //ReportUser.belongsTo(models.ReportReason,{as:'reportReason',foreignKey:'report_reason_id'})
    }
  }
  ReportUser.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    report_reason_title: {
      type: DataTypes.STRING,
      allowNull: true
    },
    report_user_id: {
      type:DataTypes.UUID,
      allowNull:true,
      references:{
        model:'users',
        key:'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    report_reason_id: {
      type:DataTypes.UUID,
      allowNull:true,
      references:{
        model:'report_reasons',
        key:'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: null
    },
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    }
  }, {
    sequelize,
    modelName: 'ReportUser',
    tableName: 'report_users',
    timestamps: true,
  });
  return ReportUser;
};