'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class SoundFavourite extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      SoundFavourite.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
      SoundFavourite.belongsTo(models.Sound,{foreignKey:'sound_id',as:'sound'});
    }
  }
  SoundFavourite.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    sound_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'sounds',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'SoundFavourite',
    tableName:'sound_favourites',
    timestamps:true
  });
  return SoundFavourite;
};