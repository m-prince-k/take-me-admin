'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Sound extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Sound.hasMany(models.Post, { foreignKey: 'sound_id', as: 'posts' });
    }
  }
  Sound.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    audio: {
      type:DataTypes.STRING,
      allowNull:true
    },
    duration: {
      type:DataTypes.STRING,
      allowNull:true
    },
    name: {
      type:DataTypes.STRING,
      allowNull:true
    },
    description: {
      type:DataTypes.TEXT,
      allowNull:true
    },
    thumbnail: {
      type:DataTypes.STRING,
      allowNull:true
    },
    sound_section_id: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    uploaded_by: {
      type:DataTypes.STRING,
      allowNull:true
    },
    publish: {
      type:DataTypes.INTEGER,
      allowNull:true
    },
    status:{
      type:DataTypes.BOOLEAN,
      defaultValue:false,
    }
  }, {
    sequelize,
    modelName: 'Sound',
    tableName:'sounds',
    timestamps:true
  });
  return Sound;
};