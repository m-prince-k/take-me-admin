'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class HashTag extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      HashTag.hasMany(models.HashTagPost, { foreignKey: 'hashtag_id', as: 'hashtag', onDelete:'CASCADE'});
      HashTag.belongsToMany(models.Post,{through:models.HashTagPost,foreignKey:'hashtag_id',otherKey:'post_id'})
    }
  }
  HashTag.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type:DataTypes.STRING,
      get(){
        const rawValue = this.getDataValue("name");
        return rawValue ? rawValue : ''
      }
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    },
  }, {
    sequelize,
    modelName: 'HashTag',
    tableName:'hashtags',
    timestamps:true
  });
  return HashTag;
};