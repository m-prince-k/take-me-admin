'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserRefferal extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  UserRefferal.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'referrer_id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    referral_code: {
      type:DataTypes.STRING
    },
    referral_id: {
      type:DataTypes.STRING,
      allowNull:true
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'UserRefferal',
    tableName:'user_refferals',
    timestamps:true
  });
  return UserRefferal;
};