'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserLang extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

       UserLang.belongsTo(models.Language, {foreignKey:'language_id', as:'languages' });
       //UserLang.belongsTo(models.Language, { as: 'langs', foreignKey: 'language_id' });
    }
  }
  UserLang.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    language_id: {
      type: DataTypes.UUID,
      allowNull: false, 
      references: {
        model: 'languages',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    }
  }, {
    sequelize,
    modelName: 'UserLang',
    tableName: 'user_langs',
    timestamps: true
  });
  return UserLang;
};