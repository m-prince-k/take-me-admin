'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class promotion extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  promotion.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    post_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'posts',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    website_url: {
      type: DataTypes.STRING,
      allowNull: true
    },
    start_datetime:{
      type: DataTypes.DATE,
      allowNull: true  
    },
    end_datetime:{
      type: DataTypes.DATE,
      allowNull: true  
    },
    coin:{
      type:DataTypes.INTEGER,
      defaultValue:0
    } ,
    active: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    destination:{
      type: DataTypes.STRING,
      allowNull: true  
    },
    action_button:{
      type: DataTypes.STRING,
      allowNull: true  
    },
    destination_tap:{
      type:DataTypes.INTEGER,
      defaultValue:0
    } ,
    followers: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    reach:{
      type: DataTypes.INTEGER,
      allowNull: true  
    },
    total_reach:{
      type: DataTypes.INTEGER,
      allowNull: true  
    },
    clicks:{
      type:DataTypes.INTEGER,
      defaultValue:0
    } ,
    audience_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'audience',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    payment_card_id:{
      type: DataTypes.INTEGER,
      allowNull: true  
    }
  }, {
    sequelize,
    modelName: 'promotion',
    timestamps: true
  });
  return promotion;
};
