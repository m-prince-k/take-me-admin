'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      User.hasMany(models.UserLang, { foreignKey: 'user_id', as: 'userlangs', onDelete:'CASCADE'});
      User.hasMany(models.UserCategory, { foreignKey: 'user_id', as: 'usercategories', onDelete:'CASCADE' });
      User.hasMany(models.Post,{foreignKey:'user_id',as:'posts',onDelete:'CASCADE'});
      User.hasMany(models.CoinPlan, { foreignKey: 'user_id', as: 'userCoins',onDelete:'CASCADE' });
      User.hasMany(models.Repost, {foreignKey:'user_id', as:'rePostUser',onDelete:'CASCADE'});
      User.hasMany(models.PostCommentLike, {foreignKey:'user_id', as:'postcommentlike',onDelete:'CASCADE'});
      User.hasMany(models.NotificationMessages, {foreignKey:'sender_id', as:'notificationmessages',onDelete:'CASCADE'});
      User.hasMany(models.TransactionHistory, {foreignKey:'user_id', as:'transaction_history',onDelete:'CASCADE'});
      //User.hasMany(models.Topic, {foreignKey:'user_id', as:'topics',onDelete:'CASCADE'});
      // User.belongsTo(models.PrivacySetting, {foreignKey:'user_id', as:'PrivacySettings',onDelete:'CASCADE'});
    }
  }
  User.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    first_name: {
      type: DataTypes.STRING,
      allowNull: true,
      get() {
        const rawValue = this.getDataValue("first_name");
        return rawValue ? rawValue : ''
      }
    },
    last_name: {
      type: DataTypes.STRING,
      allowNull: true,
      get() {
        const rawValue = this.getDataValue("last_name");
        return rawValue ? rawValue : ''
      }
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    gender: {
      type: DataTypes.STRING,
      allowNull: true
    },
    bio: {
      type: DataTypes.STRING,
      allowNull: true
    },
    dob: {
      type: DataTypes.STRING,
      allowNull: true
    },
    website: {
      type: DataTypes.STRING,
      allowNull: true
    },
    social_id: {
      type: DataTypes.STRING,
      allowNull: true
    },
    email: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
    },
    phone: {
      type: DataTypes.STRING,
      allowNull: true
    },
    phone_code: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    referral_code: {
      type: DataTypes.TEXT,
      defaultValue:Date.now().toString(36),
    },
    
    profile_pic: {
      type: DataTypes.STRING,
      allowNull: true,
      get(req) {
        const rawValue = this.getDataValue("profile_pic");
        return rawValue ? rawValue : 'https://takemeapp.s3.ap-southeast-1.amazonaws.com/uploads/1707465528.jpg'
      }
    },
    fb_url: {
      type: DataTypes.STRING,
      allowNull: true
    },
    insta_url: {
      type: DataTypes.STRING,
      allowNull: true
    },
    twitter_url: {
      type: DataTypes.STRING,
      allowNull: true
    },
    youtube_url: {
      type: DataTypes.STRING,
      allowNull: true
    },
    role: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: ['0 => for user, 1 => admin']
    },
    refferer_id: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: ['put the id who will you want to use reffer code']
    },
    username: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
    },
    social: {
      type: DataTypes.STRING,
      allowNull: true
    },
    device: {
      type: DataTypes.STRING,
      allowNull: true
    },
    device_token: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    is_block: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: ['0-unblock,1 => unblock']
    },
    room_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    unique_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      unique: true,
    },
    is_premium_user: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: ['0-premium user,1 => un premium user']
    },
    show_following_list: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: ['0-enabled,1 => disabled']
    },
    show_liked_videos: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: ['0-enabled,1 => disabled']
    },
    tencent_password: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_show_dob: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: ['0-enabled dob,1 => disabled user']
    },
    is_deleted: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: ['0 => undeleted,1 => deleted']
    },
    is_sponsored: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: ['0 => undeleted,1 => deleted']
    },
    verified: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: ['0 => unverified,1 => verified']
    },
    is_notification: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
      comment: ['0 => enabled,1 => disabled']
    },
    call_status: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: ['0 => enabled,1 => disabled']
    },
    livestream_eligible: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      comment: ['0 => unlivestream,1 => enabled live stream']
    },
    max_upload_daily: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    version: {
      type: DataTypes.STRING,
      allowNull: true
    },
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    ip: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    videos_download: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    video_comment: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    liked_videos: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    duet: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    direct_message: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    video_updates: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    new_followers: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    mentions: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    likes: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    direct_messages: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    comments: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    wallet: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    online: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    long: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    lat: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    country: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    city: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    like_points: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    comments_points: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    share_points: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    referral_points: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    uploadPost_points: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    active: {
      type: DataTypes.STRING,
      defaultValue: false
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    sequelize,
    modelName: 'User',
    tableName: 'users',
    timestamps: true
  });
  return User;
};