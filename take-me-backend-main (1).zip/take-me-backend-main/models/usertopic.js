'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserTopic extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      UserTopic.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
    }
  }
  UserTopic.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    title: DataTypes.STRING,
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      onDelete: 'CASCADE',
      onUpdate: 'NO ACTION'
    },
    follow: DataTypes.STRING,
    image: { 
    type: DataTypes.STRING,
    allowNull: true,
    defaultValue:'https://takemeapp.s3.ap-southeast-1.amazonaws.com/uploads/1707465528.jpg'
  }
  }, {
    sequelize,
    modelName: 'UserTopic',
    tableName:'user_topics',
    timestamps:true
  });
  return UserTopic;
};