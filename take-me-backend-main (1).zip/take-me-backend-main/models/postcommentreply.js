'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class PostCommentReply extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      PostCommentReply.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
      PostCommentReply.belongsTo(models.Post,{foreignKey:'post_id',as:'post'});
      PostCommentReply.belongsTo(models.PostComment,{foreignKey:'comment_id',as:'postcomment'});
    }
  }
  PostCommentReply.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    post_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'posts',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    comment_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'postcomments',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    comment: {
      type:DataTypes.STRING,
      allowNull:true
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'PostCommentReply',
    tableName:'post_comment_replies',
    timestamps:true
  });
  return PostCommentReply;
};