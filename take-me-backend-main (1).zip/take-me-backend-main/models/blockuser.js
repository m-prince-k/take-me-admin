'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class BlockUser extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      BlockUser.belongsTo(models.User,{foreignKey:'user_id',as:'users'});
      BlockUser.belongsTo(models.User,{foreignKey:'block_user_id',as:'blocked_user'});
    }
  }
  BlockUser.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    block_user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'BlockUser',
    tableName:'block_users',
    timestamps:true
  });
  return BlockUser;
};