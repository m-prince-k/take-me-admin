'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class PushNotification extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    // static associate(models) {
    //   // define association here
    // }
  }
  PushNotification.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    likes: {
      type: DataTypes.INTEGER,
      defaultValue:1
    },
    comments: {
      type: DataTypes.INTEGER,
      defaultValue:1
    },
    new_followers: {
      type: DataTypes.INTEGER,
      defaultValue:1
    },
    mentions: {
      type: DataTypes.INTEGER,
      defaultValue:1
    },
    direct_messages: {
      type: DataTypes.INTEGER,
      defaultValue:1
    },
    video_updated: {
      type: DataTypes.INTEGER,
      defaultValue:1
    },
  }, {
    sequelize,
    modelName: 'PushNotification',
    tableName:'push_notifications',
    timestamps:true
  });
  return PushNotification;
};