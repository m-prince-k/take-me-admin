'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class PostComment extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      PostComment.belongsTo(models.User,{foreignKey:'user_id',as:'user'});
      PostComment.belongsTo(models.Post,{foreignKey:'post_id',as:'post'});
      PostComment.hasMany(models.PostCommentLike,{foreignKey:'id',as:'postCommentLike'});
      PostComment.hasMany(models.PostCommentReply,{foreignKey:'comment_id',as:'postCommentReply'});
    }
  }
  PostComment.init({
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    user_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'users',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    post_id: {
      type:DataTypes.UUID,
      allowNull:false,
      references:{
        model:'posts',
        key:'id'
      },
      onDelete:'CASCADE',
      onUpdate:'NO ACTION'
    },
    comment: {
      type:DataTypes.TEXT,
      allowNull:true
    },
    status: {
      type:DataTypes.BOOLEAN,
      defaultValue:false
    }
  }, {
    sequelize,
    modelName: 'PostComment',
    tableName:'post_comments',
    timestamps:true
  });
  return PostComment;
};